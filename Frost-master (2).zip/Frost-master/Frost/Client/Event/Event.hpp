#pragma once

class Event
{
public:
    bool mCancelled = false;

    [[nodiscard]] bool isCancelled() const
    { 
        return mCancelled; 
    }

    void setCancelled(bool cancelled) 
    {
        mCancelled = cancelled;
    }

    void cancel() 
    {
        setCancelled(true);
    }
};

#include "Events/ActorModelEvent.hpp"
#include "Events/BaseTickEvent.hpp"
#include "Events/BobHurtEvent.hpp"
#include "Events/ContainerTickEvent.hpp"
#include "Events/HoverTextRenderEvent.hpp"
#include "Events/ImRenderEvent.hpp"
#include "Events/InterpolationEvent.hpp"
#include "Events/KeyboardEvent.hpp"
#include "Events/LevelRendererEvent.hpp"
#include "Events/MouseEvent.hpp"
#include "Events/MouseScrollEvent.hpp"
#include "Events/PacketEvent.hpp"
#include "Events/PacketReceiveEvent.hpp"
#include "Events/RenderContextEvent.hpp"
#include "Events/RenderEntitiesEvent.hpp"
#include "Events/RunUpdateCycleEvent.hpp"
#include "Events/SwingDurationEvent.hpp"

namespace EventManager
{
    template<typename EventT>
    void registerEvent(EventT* event)
    {
        for (const auto& mod : ModuleHandler::getInstance().getModules())
        {
            if (MainClient::g_isRunning && (mod->isEnabled() || mod->mCallEventsWhenDisabled))
            {
                mod->onEvent(event);
            }
        }
    }
}