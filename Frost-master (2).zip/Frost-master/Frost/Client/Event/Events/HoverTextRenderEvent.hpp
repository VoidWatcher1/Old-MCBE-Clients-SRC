#pragma once

#include "Memory/SDK/Render/Controls/HoverRenderer.hpp"

class HoverTextRenderEvent : public Event
{
public:
    explicit HoverTextRenderEvent(HoverTextRenderer* renderer)
        : mRenderer(renderer) {
    }

    HoverTextRenderer* mRenderer;
};