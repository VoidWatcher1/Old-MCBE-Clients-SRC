#pragma once

class LevelRendererEvent : public Event
{
public:
    explicit LevelRendererEvent() {}
};