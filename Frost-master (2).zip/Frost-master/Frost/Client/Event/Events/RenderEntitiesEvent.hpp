#pragma once

class RenderEntitiesEvent : public Event
{
public:
    explicit RenderEntitiesEvent() {}
};

class AfterRenderEntitiesEvent : public Event
{
public:
    explicit AfterRenderEntitiesEvent() {}
};