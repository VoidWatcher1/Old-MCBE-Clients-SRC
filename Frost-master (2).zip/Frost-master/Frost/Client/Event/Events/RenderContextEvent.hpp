#pragma once

class RenderContextEvent : public Event
{
public:
	explicit RenderContextEvent() {}
};