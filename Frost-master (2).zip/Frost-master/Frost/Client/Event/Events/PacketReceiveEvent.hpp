#pragma once

class PacketReceiveEvent : public Event {
public:
    explicit PacketReceiveEvent(std::shared_ptr<class Packet> packet, NetworkIdentifier* networkIdentifier, NetEventCallback* netEventCallback)
        : mPacket(packet), mNetworkIdentifier(networkIdentifier), mNetEventCallback(netEventCallback) {}

    std::shared_ptr<class Packet> mPacket;
    NetworkIdentifier* mNetworkIdentifier;
    NetEventCallback* mNetEventCallback;
};