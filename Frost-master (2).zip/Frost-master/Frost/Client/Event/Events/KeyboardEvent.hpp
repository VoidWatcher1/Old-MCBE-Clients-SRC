#pragma once

class KeyboardEvent : public Event {
public:
    explicit KeyboardEvent(int keyCode, int state)
        : mKeyCode(keyCode), mState(state) {}

    int mKeyCode;
    int mState;
};