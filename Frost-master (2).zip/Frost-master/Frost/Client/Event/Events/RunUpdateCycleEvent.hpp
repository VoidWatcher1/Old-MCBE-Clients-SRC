#pragma once

class RunUpdateCycleEvent : public Event
{
public:
	explicit RunUpdateCycleEvent() {}

	bool mApplied = false;
};