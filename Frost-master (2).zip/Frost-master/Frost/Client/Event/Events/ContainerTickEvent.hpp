#pragma once

class ContainerTickEvent : public Event
{
public:
    explicit ContainerTickEvent(ContainerScreenController* controller)
        : mController(controller) {}

    ContainerScreenController* mController;
};