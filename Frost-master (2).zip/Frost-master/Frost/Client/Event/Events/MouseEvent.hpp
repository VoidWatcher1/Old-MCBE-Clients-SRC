#pragma once

class MouseEvent : public Event
{
public:
    explicit MouseEvent(int key, bool held)
        : mKey(key), mHeld(held) {}

    int mKey;
    bool mHeld;
};