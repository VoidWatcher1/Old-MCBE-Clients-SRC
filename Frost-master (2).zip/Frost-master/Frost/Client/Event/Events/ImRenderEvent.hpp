#pragma once

class ImRenderEvent : public Event
{
public:
    explicit ImRenderEvent() {}
};