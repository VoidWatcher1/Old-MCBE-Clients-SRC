#pragma once

class ActorModelEvent : public Event
{
public:
	explicit ActorModelEvent(RenderParams* renderParams, std::string name, BoneType boneType, ActorPartModel* modelPart, std::unordered_map<::SkeletalHierarchyIndex, std::vector<class BoneOrientation>>& destBoneOrientationsMap)
		: mRenderParams(renderParams), mName(name), mBoneType(boneType), mActorPartModel(modelPart), mDestBoneOrientationsMap(destBoneOrientationsMap) {
	}

	RenderParams* mRenderParams;
	std::string mName;
	BoneType mBoneType;
	ActorPartModel* mActorPartModel;
	std::unordered_map<::SkeletalHierarchyIndex, std::vector<class BoneOrientation>>& mDestBoneOrientationsMap;
};