#pragma once

class PacketEvent : public Event
{
public:
    explicit PacketEvent(LoopbackPacketSender* sender, Packet* packet)
        : mSender(sender), mPacket(packet) {}

    LoopbackPacketSender* mSender;
    Packet* mPacket;
};