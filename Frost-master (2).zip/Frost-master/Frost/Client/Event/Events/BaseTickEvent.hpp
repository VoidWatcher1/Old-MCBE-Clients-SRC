#pragma once

class BaseTickEvent : public Event
{
public:
    explicit BaseTickEvent(Actor* actor)
        : mActor(actor) {}

    Actor* mActor;
};