#pragma once

class BobHurtEvent : public Event {
public:
    explicit BobHurtEvent(glm::mat4* matrix)
        : mMatrix(matrix) {}

    glm::mat4* mMatrix;
};