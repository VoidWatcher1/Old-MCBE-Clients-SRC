#pragma once

class MouseScrollEvent : public Event
{
public:
    explicit MouseScrollEvent(bool direction)
        : mMouseDirection(direction) {}

    bool mMouseDirection;
};