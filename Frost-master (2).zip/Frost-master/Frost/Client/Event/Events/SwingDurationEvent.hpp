#pragma once

class SwingDurationEvent : public Event
{
public:
	explicit SwingDurationEvent(Mob* actor, int swing_duration)
		: mActor(actor), mSwingDuration(swing_duration) {
	}

	Mob* mActor;
	int mSwingDuration;
};