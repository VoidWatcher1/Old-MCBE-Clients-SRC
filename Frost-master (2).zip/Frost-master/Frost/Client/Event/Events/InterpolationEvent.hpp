#pragma once

class InterpolatedHeadYawEvent : public Event
{
public:
	explicit InterpolatedHeadYawEvent(Actor* actor, float headYaw)
		: mActor(actor), mHeadYaw(headYaw) {}

	Actor* mActor;
	float mHeadYaw;
};

class InterpolatedBodyYawEvent : public Event
{
public:
	explicit InterpolatedBodyYawEvent(Actor* actor, float bodyYaw)
		: mActor(actor), mBodyYaw(bodyYaw) {}

	Actor* mActor;
	float mBodyYaw;
};