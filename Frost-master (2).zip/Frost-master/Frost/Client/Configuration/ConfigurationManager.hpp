#pragma once

class ConfigurationManager {
public:
    static ConfigurationManager& get() {
        static ConfigurationManager instance;
        return instance;
    }

    nlohmann::json getSettings(const std::vector<std::unique_ptr<Setting>>& _settings)
    {
        nlohmann::json arr = nlohmann::json::array();

        for (const auto& obj : _settings) {
            nlohmann::json obj_json = nlohmann::json::object();

            obj_json["name"] = obj->getName();
            obj_json["type"] = obj->getType();

            switch (obj->getType())
            {
            case SettingType::Bool:
                if (!obj->getBool())
                    break;

                obj_json["value"] = obj->getBool() ? 1 : 0;
                break;
            case SettingType::Enum:
                if (!obj->getEnumIndex())
                    break;

                obj_json["value"] = *obj->getEnumIndex();
                break;
            case SettingType::Slider:
                if (!obj->getFloat())
                    break;

                obj_json["value"] = obj->getFloat();
                break;
            }

            arr.push_back(obj_json);
        }

        return arr;
    }

    void setSettings(const std::vector<std::unique_ptr<Setting>>& _settings, nlohmann::json settings)
    {
        for (nlohmann::json::iterator it = settings.begin(); it != settings.end(); ++it)
        {
            nlohmann::json item = it.value();

            std::string itemname = item["name"].get<std::string>();

            for (const auto& setting : _settings)
            {
                if (setting && strcmp(setting->getName().c_str(), itemname.c_str()) == 0)
                {
                    if (!item.contains("value"))
                        return;

                    switch (setting->getType())
                    {
                    case SettingType::Bool:
                        setting->setBool(item["value"].get<bool>());
                        break;
                    case SettingType::Slider:
                        setting->setFloat(item["value"].get<float>());
                        break;

                    case SettingType::Enum:
                        int value = item["value"].get<int>();

                        if (value >= 0 && value < setting->getEnumValues().size())
                            *setting->getEnumIndex() = value;
                        break;
                    }
                }
            }
        }
    }

    void saveConfig(std::string config)
    {
        nlohmann::json top_config;

        nlohmann::json global_config;
        global_config["version"] = "V3";
        global_config["name"] = "Frost";
        global_config["owner"] = "StrafeIQ";
        top_config.push_back(global_config);

        for (const auto& mod : ModuleHandler::getInstance().getModules())
        {
            nlohmann::json mod_config;
            mod_config["name"] = mod->getName();
            mod_config["keybind"] = mod->getKeybind();
            mod_config["enabled"] = mod->isEnabled();
            mod_config["visible"] = mod->isVisible();
            mod_config["settings"] = getSettings(mod->getSettings());

            top_config.push_back(mod_config);
        }

        std::ofstream file(FileUtil::getClientPath() + "configurations\\" + config + ".json");
        if (file.is_open())
        {
            file << std::setw(4) << top_config;
            file.close();
        }

        ChatUtil::sendMessage(Util::combine("Successfully saved config ", TextFormat::getColorCode(TextFormat::Color::GRAY), config.c_str(), TextFormat::getStyleCode(TextFormat::Style::RESET), "."));
    }

    void loadConfig(std::string config)
    {
        std::ifstream file(FileUtil::getClientPath() + "configurations\\" + config + ".json");

        if (file.good())
        {
            nlohmann::json _config = nlohmann::json::parse(file);

            for (nlohmann::json::iterator it = _config.begin(); it != _config.end(); ++it)
            {
                nlohmann::json item = it.value();

                if (item.contains("version"))
                {
                    continue;
                }

                std::string itemname = item["name"].get<std::string>();

                for (const auto& mod : ModuleHandler::getInstance().getModules())
                {
                    if (strcmp(mod->getName().c_str(), itemname.c_str()) == 0)
                    {
                        mod->setKeybind(item["keybind"].get<int>());

                        if (item["enabled"].get<bool>() != mod->isEnabled()) {
                            mod->toggle();
                        }

                        mod->setVisible(item["visible"].get<bool>());

                        setSettings(mod->getSettings(), item["settings"]);
                    }
                }
            }
            ChatUtil::sendMessage(Util::combine("Successfully loaded configuration ", TextFormat::getColorCode(TextFormat::Color::GRAY), config.c_str(), TextFormat::getStyleCode(TextFormat::Style::RESET), "!"));
        }
        else
        {
            ChatUtil::sendMessage(Util::combine(TextFormat::getColorCode(TextFormat::Color::RED), "Could not load configuration ", TextFormat::getColorCode(TextFormat::Color::GRAY), config.c_str(), TextFormat::getColorCode(TextFormat::Color::RED), "!"));
        }
    }
};