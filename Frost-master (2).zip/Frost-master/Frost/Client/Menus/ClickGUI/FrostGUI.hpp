#pragma once

struct SearchCharAnim {
    char character;
    EasingUtil animation;
    bool entering = true; // true = typing in, false = deleting
};

std::vector<SearchCharAnim> animated_chars;

class FrostGUI { // credits to srxfiq
public:
    static std::vector<std::shared_ptr<Module>> getModulesInCategory(const std::string& category, const std::string& search_query_lower) {
        std::vector<std::shared_ptr<Module>> mods;

        // Filter modules based on category and search query
        std::copy_if(MainClient::mModules.begin(), MainClient::mModules.end(), std::back_inserter(mods),
            [category, search_query_lower](const std::shared_ptr<Module>& mod) {
                std::string mod_lower = mod->getName();
                std::transform(mod_lower.begin(), mod_lower.end(), mod_lower.begin(), [](unsigned char c) {
                    return std::tolower(c);
                    });

                return mod->getCategory() == category && mod_lower.find(search_query_lower) != std::string::npos;
            });

        return mods;
    }

    static bool isClickGUIEnabled()
    {
        std::string name = "clickgui";
        std::string nameLower(name);
        std::transform(nameLower.begin(), nameLower.end(), nameLower.begin(), ::tolower);

        auto it = std::find_if(MainClient::mModules.begin(), MainClient::mModules.end(), [&](const std::shared_ptr<Module>& m) {
            std::string moduleNameLower = m->getName();
            std::transform(moduleNameLower.begin(), moduleNameLower.end(), moduleNameLower.begin(), ::tolower);
            moduleNameLower.erase(std::remove(moduleNameLower.begin(), moduleNameLower.end(), ' '), moduleNameLower.end());
            return nameLower == moduleNameLower;
            });

        std::shared_ptr<Module> test = it != MainClient::mModules.end() ? *it : nullptr;

        return test == nullptr ? false : test->isEnabled();
    }

    static void renderTooltip(std::string& currentTooltip, float text_size, float animation, bool shouldRender) {
        if (!shouldRender || currentTooltip.empty())
            return;

        static std::string lastTooltip = "";
        static float ease = 1.0f;
        static float opacityEase = 0.0f;

        // Tooltip changed? Reset animation state
        if (currentTooltip != lastTooltip) {
            ease = 0.0f;
            opacityEase = 0.0f;
            lastTooltip = currentTooltip;
        }

        float dt = ImRenderUtil::getDeltaTime();
        bool isMouseHeld = ImGui::IsMouseDown(0) || ImGui::IsMouseDown(1);

        // Animate open/close state
        ease = MathUtil::animate(isMouseHeld ? 0.f : 1.f, ease, dt * 12.5f);
        opacityEase = MathUtil::animate(isMouseHeld ? 0.f : 1.f, opacityEase, dt * 8.f);

        // Tooltip layout
        const float padding = 4.0f;
        const float offsetX = 12.0f;
        const float scale = 0.8f;

        float textW = ImRenderUtil::getTextWidth(&currentTooltip, text_size * scale);
        float textH = ImRenderUtil::getTextHeight(text_size * scale);
        Vec2<float> mouse = ImRenderUtil::getMousePos();

        Vec4<float> rawRect(
            mouse.x + offsetX - padding,
            mouse.y - textH - padding,
            mouse.x + offsetX + textW + padding * 2,
            mouse.y + padding
        );

        Vec4<float> easedRect = rawRect.scaleToCenterX(ease);

        // Optional: Add opacity fade effect
        int alpha = static_cast<int>(std::clamp(opacityEase, 0.f, 1.f) * 255.f);
        Color bg_color = Color(20, 20, 20, alpha);
        Color text_color = Color(255, 255, 255, alpha);

        // Clip and render
        auto* draw = ImGui::GetBackgroundDrawList();
        draw->PushClipRect(
            ImVec2(easedRect.x, easedRect.y),
            ImVec2(easedRect.z, easedRect.w),
            true
        );

        ImRenderUtil::fillRectangle(easedRect, bg_color, animation, 0.f);
        ImRenderUtil::drawText(
            Vec2(rawRect.x + padding, rawRect.y + padding),
            &currentTooltip,
            text_color,
            text_size * scale,
            animation,
            true
        );

        draw->PopClipRect();
    }

    struct CategoryPosition 
    {
        Vec2<float> position = Vec2<float>();
        //std::atomic<bool> is_currently_dragging{ false };
        //std::atomic<bool> is_extended{ true };
        //std::atomic<bool> was_extended{ false };
        bool is_currently_dragging = false;
        bool is_extended = true;
        bool was_extended = false;
        float current_y_offset = 0;
        float scroll_ease = 0;
    };
    std::vector<CategoryPosition> category_positions;

    const float category_width = 193.f;
    const float category_height = 32.5f;

    const float category_gap = 40;

    Color module_background_color = Color(15, 15, 15);
    Color setting_background_color = Color(20, 20, 20);
    Color category_header_color = Color(20, 20, 20);

    void render(float animation, int& scrollDirection, std::string search_query, bool blur) {
        ImFontUtil::pushFont(ImFontUtil::Font::ProductSans);

        if (blur)
        {
			ImRenderUtil::addBlur<float>(Vec4<float>(0, 0, ImRenderUtil::getScreenSize().x, ImRenderUtil::getScreenSize().y), 6.f * animation, 0.f);
        }

        bool isEnabled = isClickGUIEnabled();
        std::string tooltip = "";

        float text_size = 1.f;
        float text_height = ImRenderUtil::getTextHeight(text_size);

        float x_pos = Instance::get<ClientInstance>()->getGuiData()->mWindowResolution.x;
        float y_pos = Instance::get<ClientInstance>()->getGuiData()->mWindowResolution.y;

        std::string search_query_lower = search_query;
        std::transform(search_query_lower.begin(), search_query_lower.end(), search_query_lower.begin(), [](unsigned char c) {
            return std::tolower(c);
            });

        std::string search_str = search_query.empty() ? "Press any key to search modules..." : search_query;
        std::string search_icon = "B";
        float search_text_size = 1.15f;

        // Measure widths
        ImFontUtil::pushFont(ImFontUtil::Font::ProductSansBold);
        float text_len = ImRenderUtil::getTextWidth(&search_str, search_text_size);
        ImFontUtil::popFont();

        ImFontUtil::pushFont(ImFontUtil::Font::TenacityIcons);
        float icon_len = ImRenderUtil::getTextWidth(&search_icon, search_text_size);
        ImFontUtil::popFont();

        float half_x_pos = x_pos / 2;
        float merged_len = (text_len + icon_len) / 2;

        static float icon_x = half_x_pos - merged_len;
        static float text_x = icon_x + icon_len + 15;

        icon_x = MathUtil::animate(half_x_pos - merged_len, icon_x, ImRenderUtil::getDeltaTime() * 15.f);
        text_x = MathUtil::animate(icon_x + icon_len + 15, text_x, ImRenderUtil::getDeltaTime() * 15.f);

        Vec2<float> icon_pos(icon_x, y_pos - 40);
        Vec2<float> text_pos(text_x, y_pos - 40);

        // === Draw icon ===
        ImFontUtil::pushFont(ImFontUtil::Font::TenacityIcons);
        ImRenderUtil::drawText(icon_pos, &search_icon, Color(255, 255, 255), search_text_size, 1.f, false);
        ImFontUtil::popFont();

        // === Draw animated search text ===
        float cursor_x = text_x;
        float spacing = 2.f;

        ImFontUtil::pushFont(ImFontUtil::Font::ProductSansBold);

        if (search_query.empty())
        {
            ImRenderUtil::drawText(text_pos, &search_str, Color(255, 255, 255), search_text_size, animation, false);
        }

        for (int i = 0; i < animated_chars.size(); ++i) {
            auto& anim = animated_chars[i];

            // Update animation
            if (anim.entering)
                anim.animation.increment(ImRenderUtil::getDeltaTime() * 15.f / 10.f);
            else
                anim.animation.decrement(ImRenderUtil::getDeltaTime() * 15.f / 10.f);

            float ease = anim.animation.easeOutExpo();

            if (anim.animation.isMax())
                ease = 1.f;

            // Remove finished out-animations
            if (!anim.entering) {
                animated_chars.erase(animated_chars.begin() + i);
                --i;
                continue;
            }

            std::string fallback = "Press any key to search modules...";
            std::string ch_str(1, search_query.empty() ? fallback[i] : search_query[i]);

            float char_width = ImRenderUtil::getTextWidth(&ch_str, search_text_size);
            Vec2<float> char_pos(cursor_x, y_pos - 40);

            ImScaleUtil::ImScaleStart();
            ImRotateUtil::startRotation();

            ImRenderUtil::drawText(char_pos, &ch_str, Color(255, 255, 255, static_cast<int>(ease * 255)), search_text_size * ease, 1.f, false);

            float rotate_amount = anim.entering ? (1.f - ease) * 1.0f : ease * 1.0f;
            ImRotateUtil::endRotation(rotate_amount);
            ImScaleUtil::ImScaleEnd(ease, ease);

            cursor_x += char_width + spacing;
        }

        ImFontUtil::popFont();

        if (category_positions.empty() && isEnabled)
        {
            float centerX = ImRenderUtil::getScreenSize().x / 2.f;
            float xPos = centerX - (MainClient::mCategories.size() * (category_width + category_gap) / 2);
            for (std::string& category : MainClient::mCategories)
            {
                CategoryPosition pos;
                pos.position.x = xPos;
                pos.position.y = category_gap * 2;
                xPos += category_width + category_gap;
                category_positions.push_back(pos);
            }
        }

        if (!category_positions.empty()) {
            for (size_t i = 0; i < MainClient::mCategories.size(); i++) {
                const float modules_width = category_width;
                const float modules_height = category_height;
                float module_index = -category_positions[i].current_y_offset;

                const auto& modules_in_category = getModulesInCategory(MainClient::mCategories[i], search_query_lower);

                Vec4<float> category_rect = Vec4<float>(category_positions[i].position.x, category_positions[i].position.y, category_positions[i].position.x + category_width, category_positions[i].position.y + category_height);

                float settings_height = 0;

                for (const auto& mod : modules_in_category) {
                    for (const auto& setting : mod->getSettings()) {
                        if (!setting->shouldRender())
                            continue;

                        switch (setting->getType())
                        {
                        case SettingType::Bool: {
                            settings_height = MathUtil::lerp(settings_height, settings_height + modules_height, mod->mClickGUIAnim);
                            break;
                        }
                        case SettingType::Enum: {
                            settings_height = MathUtil::lerp(settings_height, settings_height + modules_height, mod->mClickGUIAnim);
                            break;
                        }
                        case SettingType::Slider: {
                            settings_height = MathUtil::lerp(settings_height, settings_height + modules_height, mod->mClickGUIAnim);
                            break;
                        }
                        }
                    }
                }

                float category_window_height = category_height + modules_height * modules_in_category.size() + settings_height;
                Vec4<float> category_window = Vec4<float>(category_positions[i].position.x, category_positions[i].position.y, category_positions[i].position.x + category_width, category_positions[i].position.y + module_index + category_window_height);

                ImRenderUtil::fillRectangle(category_window, setting_background_color, animation, 0);

                auto first_category_gradient = ColorUtil::getClientColor(i / 30, 2.f);
                auto second_category_gradient = ColorUtil::getClientColor(i + 6, 2.f);

                // Scrolling handles
                if (ImRenderUtil::isMouseOver(category_window) && category_positions[i].is_extended) {
                    if (scrollDirection > 0) {
                        category_positions[i].scroll_ease += scrollDirection * category_height;
                        if (category_positions[i].scroll_ease > category_window_height - modules_height * 2)
                            category_positions[i].scroll_ease = category_window_height - modules_height * 2;
                    }
                    else if (scrollDirection < 0) {
                        category_positions[i].scroll_ease += scrollDirection * category_height;
                        if (category_positions[i].scroll_ease < 0)
                            category_positions[i].scroll_ease = 0;
                    }
                    scrollDirection = 0;
                }

                // Lerp the category extending
                if (!category_positions[i].is_extended) {
                    category_positions[i].scroll_ease = category_window_height - category_height;
                    category_positions[i].was_extended = false;
                }
                else if (!category_positions[i].was_extended) {
                    category_positions[i].scroll_ease = 0;
                    category_positions[i].was_extended = true;
                }

                // Lerp the scrolling cuz smooth
                category_positions[i].current_y_offset = MathUtil::animate(category_positions[i].scroll_ease, category_positions[i].current_y_offset, ImRenderUtil::getDeltaTime() * 10.5);

                for (const auto& mod : modules_in_category) 
                {
                    auto first_gradient = ColorUtil::getClientColor(module_index / 30.f, 2.f);
                    auto second_gradient = ColorUtil::getClientColor(module_index + 6.f, 2.f);

                    // If the mod belongs to the category
                    if (mod->getCategory() == MainClient::mCategories[i]) {
                        // Calculate the modules_rect pos
                        Vec4<float> modules_rect = Vec4<float>(category_positions[i].position.x, category_positions[i].position.y + category_height + module_index, category_positions[i].position.x + modules_width, category_positions[i].position.y + category_height + module_index + modules_height);

                        // Animate the setting animation percentage
                        float target_animation = mod->mSettingsExtended ? 1.f : 0.f;
                        mod->mClickGUIAnim = MathUtil::animate(target_animation, mod->mClickGUIAnim, ImRenderUtil::getDeltaTime() * 15.5);
                        mod->mClickGUIAnim = MathUtil::clamp(mod->mClickGUIAnim, 0.f, 1.f);

                        // Settings
                        if (mod->mClickGUIAnim > 0.001) {
                            for (const auto& setting : mod->getSettings()) {
                                if (!setting->shouldRender())
                                    continue;

                                switch (setting->getType()) {
                                case SettingType::Bool:
                                {
                                    module_index = MathUtil::lerp(module_index, module_index + modules_height, mod->mClickGUIAnim);

                                    first_gradient = ColorUtil::getClientColor(module_index / 30.f, 2.f);
                                    second_gradient = ColorUtil::getClientColor(module_index + 6.f, 2.f);

                                    auto setting_name = setting->getName();

                                    auto module_rect = Vec4<float>(modules_rect.x, category_positions[i].position.y + category_height + module_index, modules_rect.z, category_positions[i].position.y + category_height + module_index + modules_height);
                                    auto setting_rect = Vec4<float>(module_rect.z - 20.f, module_rect.y + 6.5f, module_rect.z, module_rect.w - 2.5f);
                                    auto setting_text_pos = Vec2<float>(module_rect.x + 6.f, (module_rect.y + module_rect.w) * 0.5f - text_height * 0.5f);

                                    ImRenderUtil::drawText(setting_text_pos, &setting_name, Color(255, 255, 255), text_size, mod->mClickGUIAnim * animation, false);

                                    if (ImRenderUtil::isMouseOver(setting_rect) && Util::mLeftClick)
                                    {
                                        setting->setBool(!setting->getBool());
                                        Util::mLeftClick = false;
                                    }

                                    float animation_speed = 10.0f;

                                    setting->ui_animations.bool_scale = MathUtil::animate(setting->getBool() ? 1 : 0, setting->ui_animations.bool_scale, ImRenderUtil::getDeltaTime() * animation_speed);

                                    float scaled_width = setting_rect.getWidth();
                                    float scaled_height = setting_rect.getHeight();

                                    auto center = Vec2<float>(setting_rect.x + setting_rect.getWidth() / 2.f, setting_rect.y + setting_rect.getHeight() / 2.f);
                                    auto scaled_rect = Vec4<float>(center.x - scaled_width / 2.f, center.y - scaled_height / 2.f, center.x + scaled_width / 2.f, center.y + scaled_height / 2.f);

                                    auto smooth_scaled_rect = Vec4<float>(scaled_rect.z - 19, scaled_rect.y + 5, scaled_rect.z - 5, scaled_rect.w - 5);//
                                    auto circleRect = Vec2<float>(smooth_scaled_rect.getCenter().x, smooth_scaled_rect.getCenter().y);

                                    ImRenderUtil::fillCircle(circleRect, 5.f * setting->ui_animations.bool_scale, ColorUtil::lerpColor(Color(15, 15, 15), second_gradient, setting->ui_animations.bool_scale), mod->mClickGUIAnim * animation);
                                    ImRenderUtil::fillShadowCircle(circleRect, 5.f * setting->ui_animations.bool_scale, ColorUtil::lerpColor(Color(15, 15, 15), second_gradient, setting->ui_animations.bool_scale), mod->mClickGUIAnim * animation);
                                    break;
                                }
                                case SettingType::Enum:
                                {
                                    module_index = MathUtil::lerp(module_index, module_index + modules_height, mod->mClickGUIAnim);

                                    first_gradient = ColorUtil::getClientColor(module_index / 30.f, 2.f);
                                    second_gradient = ColorUtil::getClientColor(module_index + 6.f, 2.f);

                                    std::vector<std::string> enum_values_list = setting->getEnumValues();
                                    int* current_index = setting->getEnumIndex();

                                    auto setting_name = setting->getName();
                                    auto enum_value_name = enum_values_list[*current_index];

                                    auto enum_value_width = ImRenderUtil::getTextWidth(&enum_value_name, text_size);

                                    auto module_rect = Vec4<float>(modules_rect.x, category_positions[i].position.y + category_height + module_index, modules_rect.z, category_positions[i].position.y + category_height + module_index + modules_height);
                                    auto setting_text_pos = Vec2<float>(module_rect.x + 6.f, (module_rect.y + module_rect.w) * 0.5f - text_height * 0.5f);
                                    auto enum_value_text_pos = Vec2<float>(module_rect.z - 6.f - enum_value_width, (module_rect.y + module_rect.w) * 0.5f - text_height * 0.5f);

                                    ImRenderUtil::drawText(setting_text_pos, &setting_name, Color(255, 255, 255), text_size, mod->mClickGUIAnim * animation, false);
                                    ImRenderUtil::drawText(enum_value_text_pos, &enum_value_name, Color(255, 255, 255), text_size, mod->mClickGUIAnim * animation, false);

                                    if (ImRenderUtil::isMouseOver(module_rect) && Util::mLeftClick)
                                    {
                                        setting->setEnum((*current_index + 1) % enum_values_list.size());
                                        Util::mLeftClick = false;
                                    }
                                    break;
                                }
                                case SettingType::Slider:
                                {
                                    module_index = MathUtil::lerp(module_index, module_index + modules_height, mod->mClickGUIAnim);

                                    first_gradient = ColorUtil::getClientColor(module_index / 30.f, 2.f);
                                    second_gradient = ColorUtil::getClientColor(module_index + 6.f, 2.f);

                                    auto value = setting->getFloat();
                                    auto min = setting->getMin();
                                    auto max = setting->getMax();
                                    auto round_value = 0.01f;
                                    auto slider_precision = setting->getSliderPrecision();

                                    if (slider_precision == static_cast<int>(SliderType::Int))
                                    {
                                        round_value = 1.f;
                                    }

                                    if (slider_precision == static_cast<int>(SliderType::Float))
                                    {
                                        round_value = 0.1f;
                                    }

                                    if (slider_precision == static_cast<int>(SliderType::DoubleFloat))
                                    {
                                        round_value = 0.01f;
                                    }

                                    if (slider_precision == static_cast<int>(SliderType::TripleFloat))
                                    {
                                        round_value = 0.001f;
                                    }

                                    auto formatFloat = [](float value, int precision) -> std::string {
                                        std::ostringstream stream;
                                        stream << std::fixed << std::setprecision(precision) << value;
                                        return stream.str();
                                        };

                                    auto setting_name = setting->getName();
                                    auto value_name = formatFloat(value, slider_precision);
                                    
                                    auto value_width = ImRenderUtil::getTextWidth(&value_name, text_size);

                                    auto module_rect = Vec4<float>(modules_rect.x, category_positions[i].position.y + category_height + module_index, modules_rect.z, category_positions[i].position.y + category_height + module_index + modules_height);
                                    auto setting_text_pos = Vec2<float>(module_rect.x + 6.f, (module_rect.y + module_rect.w) * 0.5f - text_height * 0.5f);
                                    auto value_text_pos = Vec2<float>(module_rect.z - 6.f - value_width, (module_rect.y + module_rect.w) * 0.5f - text_height * 0.5f);

                                    float slider_pos = (value - min) / (max - min) * (module_rect.z - module_rect.x);

                                    setting->ui_animations.slider_ease = MathUtil::animate(slider_pos, setting->ui_animations.slider_ease, ImRenderUtil::getDeltaTime() * 10);
                                    setting->ui_animations.slider_ease = std::clamp(setting->ui_animations.slider_ease, 0.f, module_rect.getWidth());

                                    if (ImRenderUtil::isMouseOver(module_rect) && isEnabled) 
                                    {
                                        if (Util::mLeftClick && Util::mLeftDown)
                                        {
                                            const float new_value = std::max(std::min((ImRenderUtil::getMousePos().x - module_rect.x) / (module_rect.z - module_rect.x) * (max - min) + min, max), min);
                                            setting->setFloat(new_value);
                                        }
                                    }

                                    auto slider_rect = Vec4<float>(module_rect.x, module_rect.y, module_rect.x + setting->ui_animations.slider_ease, module_rect.w);

                                    ImRenderUtil::fillGradientRectangle(slider_rect, first_gradient, second_gradient, mod->mClickGUIAnim * animation, mod->mClickGUIAnim * animation);

                                    ImRenderUtil::drawText(setting_text_pos, &setting_name, Color(255, 255, 255), text_size, mod->mClickGUIAnim* animation, false);
                                    ImRenderUtil::drawText(value_text_pos, &value_name, Color(255, 255, 255), text_size, mod->mClickGUIAnim* animation, false);
                                    break;
                                }
                                }
                            }
                        }

                        mod->mSettingsExtendAnimation = MathUtil::animate(settings_height, mod->mSettingsExtendAnimation, ImRenderUtil::getDeltaTime() * 10);

                        if (modules_rect.y > category_rect.y + 0.5f)
                        {
                            if (mod->mClickGUIScale <= 1) 
                            {
                                ImRenderUtil::fillRectangle(modules_rect, module_background_color, animation);
                            }

                            std::string module_name = mod->getName();

                            Vec2<float> center = Vec2<float>(modules_rect.x + modules_rect.getWidth() / 2.f, modules_rect.y + modules_rect.getHeight() / 2.f);

                            mod->mClickGUIScale = MathUtil::animate(mod->isEnabled() ? 1 : 0, mod->mClickGUIScale, ImRenderUtil::getDeltaTime() * 10);

                            float scaled_width = modules_rect.getWidth() * mod->mClickGUIScale;
                            float scaled_height = modules_rect.getHeight() * mod->mClickGUIScale;

                            Vec4<float> scaledRect(
                                center.x - scaled_width / 2.f,
                                center.y - scaled_height / 2.f,
                                center.x + scaled_width / 2.f,
                                center.y + scaled_height / 2.f
                            );

                            if (mod->mClickGUIScale > 0) {
                                ImRenderUtil::fillGradientRectangle(
                                    scaledRect,
                                    first_gradient, second_gradient,
                                    animation * mod->mClickGUIScale,
                                    animation * mod->mClickGUIScale
                                );
                            }

                            float clickgui_rect_center_x = modules_rect.x + ((modules_rect.z - modules_rect.x) - ImRenderUtil::getTextWidth(&module_name, text_size)) / 2;
                            float clickgui_rect_center_y = modules_rect.y + ((modules_rect.w - modules_rect.y) - text_height) / 2;

                            Vec2<float> modPosLerped = Vec2<float>(clickgui_rect_center_x, clickgui_rect_center_y);

                            ImRenderUtil::drawText(modPosLerped, &module_name, Color(255, 255, 255), text_size, animation, false);

                            if (ImRenderUtil::isMouseOver(modules_rect) && category_positions[i].is_extended && isEnabled)
                            {
                                if (ImRenderUtil::isMouseOver(category_window))
                                {
                                    tooltip = mod->getDescription();
                                }

                                if (Util::mLeftDown)
                                {
                                    mod->toggle();
                                    Util::mLeftDown = false;
                                    //particleMgr.addParticles(5, GuiInfo::MousePos.x, GuiInfo::MousePos.y, 80, 2.f);
                                }
                                else if (Util::mRightClick)
                                {
                                    mod->mSettingsExtended = !mod->mSettingsExtended;
                                    Util::mRightClick = false;
                                }
                            }
                        }
                        if (modules_rect.y > category_rect.y - modules_height) 
                        {
                            ImRenderUtil::fillGradientRectangle(Vec4<float>(modules_rect.x, modules_rect.w, modules_rect.z, modules_rect.w + 10.f * mod->mClickGUIAnim * animation), Color(0, 0, 0), Color(0, 0, 0), 0.f * animation, 0.35f * animation);
                        }
                        module_index += modules_height;
                    }
                }

                std::string catName = MainClient::mCategories[i];

                if (ImRenderUtil::isMouseOver(category_rect) && Util::mRightDown)
                {
                    //auto& toggle = category_positions[i].is_extended; // fetch_xor
                    //toggle.store(!toggle.load());
                    category_positions[i].is_extended = !category_positions[i].is_extended;
                }

                Vec4<float> lineRect(category_rect.x, category_rect.w, category_rect.z, category_rect.w + 1.f);
                ImRenderUtil::fillGradientRectangle(lineRect, first_category_gradient, second_category_gradient, animation, animation);

                ImRenderUtil::fillRectangle(category_rect, category_header_color, animation);

                ImFontUtil::pushFont(ImFontUtil::Font::ProductSansBold);

                // Calculate the centre of the rect
                float clickgui_rect_center_x = category_rect.x + ((category_rect.z - category_rect.x) - ImRenderUtil::getTextWidth(&catName, text_size * 1.15)) / 2;
                float clickgui_rect_center_y = category_rect.y + ((category_rect.w - category_rect.y) - text_height) / 2;

                // Draw the string
                ImRenderUtil::drawText(Vec2(clickgui_rect_center_x, clickgui_rect_center_y), &catName, Color(255, 255, 255), text_size * 1.14, animation, false);

#pragma region DraggingLogic
                static bool dragging = false;
                static Vec2<float> dragOffset;
                if (category_positions[i].is_currently_dragging)
                {
                    if (Util::mLeftClick)
                    {
                        if (!dragging)
                        {
                            dragOffset = Vec2<float>(ImRenderUtil::getMousePos().x - category_rect.x, ImRenderUtil::getMousePos().y - category_rect.y);
                            dragging = true;
                        }
                        Vec2<float> newPosition = Vec2<float>(ImRenderUtil::getMousePos().x - dragOffset.x, ImRenderUtil::getMousePos().y - dragOffset.y);
                        newPosition.x = std::clamp(newPosition.toFloat().x, 0.f, ImRenderUtil::getScreenSize().x - category_width);
                        newPosition.y = std::clamp(newPosition.toFloat().y, 0.f, ImRenderUtil::getScreenSize().y - category_height);
                        category_positions[i].position.x = newPosition.x;
                        category_positions[i].position.y = newPosition.y;
                    }
                    else
                    {
                        category_positions[i].is_currently_dragging = false;
                        dragging = false;
                    }
                }
                else if (ImRenderUtil::isMouseOver(category_rect) && Util::mLeftDown && isEnabled)
                {
                    Util::mLeftDown = false;
                    category_positions[i].is_currently_dragging = true;
                    dragOffset = Vec2<float>(ImRenderUtil::getMousePos().x - category_rect.x, ImRenderUtil::getMousePos().y - category_rect.y);
                }
#pragma endregion
                ImFontUtil::popFont();
            }

            renderTooltip(tooltip, text_size, animation, true);

            if (isEnabled) {
                Util::mLeftDown = false;
                Util::mRightDown = false;
                Util::mRightClick = false;
                Instance::get<ClientInstance>()->releaseMouse();
                scrollDirection = 0;
            }
        }
        ImFontUtil::popFont();
    }
};