#pragma once
#include "Utils/IRC/IRCUtil.hpp"

class IRCMessageCommand : public Command {
public:
	IRCMessageCommand() 
		: Command("ircmsg", "Message the IRC Channel.", { "dm", "imsg", "#" }) 
	{}

	void execute(std::vector<std::string> cmd) override {
		auto player = Instance::getLocalPlayer();
		if (!player) return;

		std::string message;

		for (size_t i = 1; i < cmd.size(); i++) {
			message += cmd[i];
			if (i < cmd.size() - 1) message += " ";
		}

		if (message.empty()) {
			ChatUtil::sendIRCMessage("Please enter a message to send, not a empty one.");
			return;
		}

		if (message.length() > 1000) {
			ChatUtil::sendIRCMessage("Please enter a message under 1000 chars");
			return;
		}

		std::string username = *player->getNametag();

		IRCUtil::sendIRCMessage(username, message);
		ChatUtil::sendIRCMessage(username + ": " + message);
		return;

	}
};