#pragma once

class ConfigurationCommand : public Command
{
public:

    ConfigurationCommand() 
        : Command("config", "Manage your configurations.", { "c", "configuration" })
    {}

    void execute(std::vector<std::string> cmd)
    {
        if (cmd.size() == 0)
            return;

        static std::string SavedConfig = "default";

        //.config save
        if (strcmp(cmd[0].c_str(), "save") == 0 || strcmp(cmd[0].c_str(), "s") == 0)
        {
            if (cmd.size() == 2)
            {
                SavedConfig = cmd[1];
                ConfigurationManager::get().saveConfig(cmd[1]);
            }
            else
            {
                ConfigurationManager::get().saveConfig(SavedConfig);
            }
        }

        //.config load
        if (strcmp(cmd[0].c_str(), "load") == 0 || strcmp(cmd[0].c_str(), "l") == 0)
        {
            if (cmd.size() == 2)
            {
                SavedConfig = cmd[1];
                ConfigurationManager::get().loadConfig(cmd[1]);
            }
        }

        return;
    }
};