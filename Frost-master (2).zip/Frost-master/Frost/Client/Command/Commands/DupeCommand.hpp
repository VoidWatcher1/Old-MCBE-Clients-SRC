#pragma once

class DupeCommand : public Command
{
public:
    DupeCommand() 
        : Command("dupe", "Dupes a item.", { "dupe" })
    {}

    void execute(std::vector<std::string> cmd) 
    {
        Player* mPlayer = Instance::getLocalPlayer();
        PlayerInventory* mSupplies = mPlayer->getSupplies();
        Inventory* mInv = mSupplies->getInventory();
        InventoryTransactionManager* mTransaction = mPlayer->getTransactionManager();

        int mSelectedSlot = mSupplies->mSelectedSlot;
        ItemStack* mItem = mInv->getItemStack(mSelectedSlot);

        int mCount = mItem->mCount;
        bool mOffhand = false;

        if (cmd.size() > 1)
            mItem->mCount = std::stoi((cmd.at(1)));
        if (cmd.size() > 2)
            mOffhand = cmd.at(2) == "true";

        if (!mOffhand)
        {
            Console::debug("Currently duping without offhand.");

            int mSlot = mInv->getFirstEmptySlot();

            //mTransaction->mCurrentTransaction->addAction(InventoryAction(0, mItem, nullptr, ContainerID::Inventory, InventorySourceType::NonImplemented));
            //mTransaction->mCurrentTransaction->addAction(InventoryAction(mSlot, nullptr, mItem));

            mInv->addItemToFirstEmptySlot(mItem);
        }

        ChatUtil::sendMessage("Successfully duplicated items!");

        return;
    }
};