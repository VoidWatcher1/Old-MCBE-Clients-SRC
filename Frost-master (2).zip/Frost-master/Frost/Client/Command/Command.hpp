#pragma once

class Command
{
public:
	Command(std::string commandName, std::string descr, std::vector<std::string> aliases = std::vector<std::string>())
		: mName(commandName), mDescription(descr), mAliases(aliases)
	{}

	virtual void execute(std::vector<std::string> cmd) { }

	const std::string& getName() const { return mName; }
	const std::string& getDescription() const { return mDescription; }
	const std::vector<std::string>& getAliases() const { return mAliases; }

protected:
	std::string mName;
	std::string mDescription;
	std::vector<std::string> mAliases;
};
