#pragma once

#include "Settings.hpp"

enum class SliderType
{
    Int = 0,
    Float = 1,
    DoubleFloat = 2,
    TripleFloat = 3
};

#define DEFINE_EVENT_HANDLER(eventType) \
    virtual void onEvent(eventType* event) {}

class Module
{
public:
    Module(const std::string& name, const std::string& category, const std::string& description,
        int32_t keybind = 0x7, bool enabled = false)
        : mName(name), mCategory(category), mDescription(description), mKeybind(keybind), mEnabled(enabled), mVisible(true)
    {
        addBool("Visible", "Draw in arraylist.", &mVisible);
    }

    virtual ~Module() = default;

    [[nodiscard]] const std::string& getName() const noexcept { return mName; }
    [[nodiscard]] const std::string& getDescription() const noexcept { return mDescription; }
    [[nodiscard]] const std::string& getCategory() const noexcept { return mCategory; }
    [[nodiscard]] int getKeybind() const noexcept { return mKeybind; }
    [[nodiscard]] bool isEnabled() const noexcept { return mEnabled; }
    [[nodiscard]] bool isVisible() const noexcept { return mVisible; }
    [[nodiscard]] const std::vector<std::unique_ptr<Setting>>& getSettings() const noexcept { return mSettings; }

    void setKeybind(int32_t keybind) noexcept { mKeybind = keybind; }
    void setEnabled(bool enabled) noexcept { mEnabled = enabled; }
    void setVisible(bool visible) noexcept { mVisible = visible; }

    void toggle()
    {
        mEnabled = !mEnabled;
        mEnabled ? onEnable() : onDisable();

        if (NotificationsManager::mShowOnToggle)
        {
            const auto mNotification = NotificationsUtil::Notification(mName + " was " + (mEnabled ? "enabled" : "disabled"), NotificationsUtil::Notification::Type::Info, 3);
            NotificationsManager::mNotifications.push_back(mNotification);
        }
    }

    void addSlider(const std::string& name, const std::string& description, float* value,
        float min, float max, SliderType type = SliderType::Float, std::function<bool()> visible = [] { return true; })
    {
        mSettings.emplace_back(std::make_unique<Setting>(name, description, value, min, max, static_cast<int>(type), visible));
    }

    void addBool(const std::string& name, const std::string& description, bool* state,
        std::function<bool()> visible = [] { return true; })
    {
        mSettings.emplace_back(std::make_unique<Setting>(name, description, state, visible));
    }

    void addEnum(const std::string& name, const std::string& description, std::vector<std::string> enums,
        int* currentIndex, std::function<bool()> visible = [] { return true; })
    {
        mSettings.emplace_back(std::make_unique<Setting>(name, description, std::move(enums), currentIndex, visible));
    }

    virtual std::string getModeName() const
    {
        for (const auto& setting : mSettings)
        {
            if (setting->getType() == SettingType::Enum && !setting->getEnumValues().empty())
            {
                return setting->getEnumValues().at(*setting->getEnumIndex());
            }
        }
        return {};
    }

    template<typename T>
    static T& get() {
        static T instance;
        return instance;
    }

    virtual void onEnable() {}
    virtual void onDisable() {}

    DEFINE_EVENT_HANDLER(ActorModelEvent)
    DEFINE_EVENT_HANDLER(AfterRenderEntitiesEvent)
    DEFINE_EVENT_HANDLER(BaseTickEvent)
    DEFINE_EVENT_HANDLER(BobHurtEvent)
    DEFINE_EVENT_HANDLER(ContainerTickEvent)
    DEFINE_EVENT_HANDLER(HoverTextRenderEvent)
    DEFINE_EVENT_HANDLER(ImRenderEvent)
    DEFINE_EVENT_HANDLER(InterpolatedBodyYawEvent)
    DEFINE_EVENT_HANDLER(InterpolatedHeadYawEvent)
    DEFINE_EVENT_HANDLER(KeyboardEvent)
    DEFINE_EVENT_HANDLER(LevelRendererEvent)
    DEFINE_EVENT_HANDLER(MouseEvent)
    DEFINE_EVENT_HANDLER(MouseScrollEvent)
    DEFINE_EVENT_HANDLER(PacketEvent)
    DEFINE_EVENT_HANDLER(PacketReceiveEvent)
    DEFINE_EVENT_HANDLER(RenderContextEvent)
    DEFINE_EVENT_HANDLER(RenderEntitiesEvent)
    DEFINE_EVENT_HANDLER(RunUpdateCycleEvent)
    DEFINE_EVENT_HANDLER(SwingDurationEvent)

    float mAnimationPercentage = 0.f;
    float mSmoothAnimationPercentage = 0.f;
    Vec2<float> mArrayListPos;
    bool mSettingsExtended = false;
    float mClickGUIAnim = 0.f;
    float mClickGUIScale = 0.f;
    float mSettingsExtendAnimation = 0.f;

    bool mToggleInGameOnly = true;
    bool mCallEventsWhenDisabled = false;
protected:
    std::vector<std::unique_ptr<Setting>> mSettings;
    std::string mName;
    std::string mDescription;
    std::string mCategory;
    int32_t mKeybind;
    bool mEnabled;
    bool mVisible;
};
