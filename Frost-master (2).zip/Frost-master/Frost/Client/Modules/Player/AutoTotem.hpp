#pragma once

#include <xstring>

class AutoTotem : public Module
{
public:
    AutoTotem() :
        Module("Auto Totem", "Player", "Automatically puts totems into your offhand.")
    {}

    void onEvent(BaseTickEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        ItemStack* offhandStack = player->getOffhandContainer()->getItemStack(1);
        if (offhandStack->mItem && offhandStack->getItem()->isTotem())
            return;

        for (int i = 0; i < 8; i++)
        {
            auto itemStack = player->getSupplies()->getInventory()->getItemStack(i);
            if (!itemStack->mItem) continue;
            if (itemStack->getItem()->isTotem())
            {
                Console::debug("Item is a totem yes we are doing transactions now");
                static ItemStack blankStack = ItemStack();

                Item* item = *itemStack->mItem;

                InventoryAction action = InventoryAction(i, itemStack, offhandStack);
                action.mSource.mType = InventorySourceType::ContainerInventory;
                action.mSource.mContainerId = ContainerID::Inventory;

                InventoryAction action2 = InventoryAction(0, offhandStack, itemStack);
                action2.mSource.mType = InventorySourceType::ContainerInventory;
                action2.mSource.mContainerId = ContainerID::Offhand;

                auto pkt = MinecraftPackets::createPacket<InventoryTransactionPacket>(PacketID::InventoryTransaction);

                auto cit = std::make_unique<ComplexInventoryTransaction>();
                cit->mData.addAction(action);
                cit->mData.addAction(action2);

                pkt->mTransaction = std::move(cit);
                Instance::get<ClientInstance>()->getLoopbackPacketSender()->sendToServer(pkt.get());
                break;
            }
        }
    }
};