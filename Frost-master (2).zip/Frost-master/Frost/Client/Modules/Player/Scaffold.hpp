#pragma once

class Scaffold : public Module
{
public:
    Scaffold() :
        Module("Scaffold", "Player", "Automatically places blocks below you.")
    {
        addEnum("Rotations", "The rotation mode", { "None", "Normal" }, &rotations);
        addEnum("Switch Mode", "How to hold the block", { "None", "Full", "Spoof", "Client Spoof" }, &holdStyle);
        addEnum("Tower Mode", "The tower mode", { "Vanilla", "Velocity", "Clip" }, &towerMode);
        addEnum("Placement", "The placement mode", { "Normal", "Legit" }, &placementMode);
        addEnum("Counter", "The style of displaying the block counter", { "None", "Simple", "Rise" }, &counterStyle);

        addBool("Inventory Slot", "Use the inventory slot", &invSlot);
        addBool("Keep Y", "Keeps your y level when placing blocks", &yLock);

        addSlider("Distance", "The place distance (how far to place blocks)", &rangeDistance, 3, 8);
        addSlider("Extend", "Distance your position to target block", &extend, 0, 10, SliderType::Int);

        addBool("Allow Delay", "Allow block placement delay", &allowDelay);
        addSlider("Delay", "Block placement delay in ms", &delayMS, 0, 300);
    }
private:
    enum class RotateMode {
        None,
        Normal
    };

    enum class SwitchMode {
        None,
        Full,
        Spoof,
        ClientSpoof
    };

    enum class TowerMode {
        Vanilla,
        Velocity,
        Clip
    };

    enum class PlacementMode {
        Normal,
        Legit
    };

    enum class CounterStyle {
        None,
        Simple,
        Rise
    };

    class RiseCounter {
    public:
        Vec4<float> mRectPos;
        float inScale;

    };

    RiseCounter riseCounter;


    //Settings
    int rotations = 0;
    int holdStyle = 0;
    int towerMode = 0;
    int placementMode = 0;
    int counterStyle = 2; // change to 0 later

    bool invSlot = true;
    bool yLock = true;

    float rangeDistance = 5.f;
    float extend = 0;

    bool allowDelay = false;
    float delayMS = 85;

    // Helpers
    int mPrevSlot = 0;
    int mBlockSlot = -1;
    float mLockedY = 0;
    bool mIsHoldingSpace = false;
    bool mFoundBlock = false;
    Vec3<float> mBlockPos;
    Vec3<float> mClickBlockPos;
    Vec3<float> mBlockBelow;

    // Delay helper
    std::chrono::steady_clock::time_point mLastPlaceTime = std::chrono::steady_clock::now();

private:
    bool canPlace(Vec3<float> pos)
    {
        return Instance::getBlockSource()->getBlock(pos.floor().toInt())->getLegacyBlock()->getBlockID() == 0;
    }

    bool tryFindingBlock()
    {
        PlayerInventory* mPlayerInventory = Instance::getLocalPlayer()->getSupplies();
        Inventory* mInventory = mPlayerInventory->getInventory();
        const int mPreviousSlot = mPlayerInventory->mSelectedSlot;
        const int mMaxSlots = invSlot ? 36 : 9;

        for (int i = 0; i < mMaxSlots; ++i)
        {
            ItemStack* stack = mInventory->getItemStack(i);

            if (stack != nullptr && stack->isBlockType() && !stack->getItem()->tryIsA("zzub_boombox"))
            {
                if (mPreviousSlot != i)
                {
                    if (holdStyle != static_cast<int>(SwitchMode::None))
                    {
                        mPlayerInventory->mSelectedSlot = i;
                    }

                    mBlockSlot = i;
                }
                return true;
            }
        }

        return false;
    }

    Vec3<float> getBlockBelow(Player* player)
    {
        Vec3<float> mBlockBelow = player->getAABBShapeComponent()->mMin;
        mBlockBelow.y -= 1.f;
        return mBlockBelow;
    }

    void adjustYCoordinate(const Vec3<float>& blockBelowReal)
    {
        if (floor(blockBelowReal.y) < floor(mLockedY))
        {
            mLockedY = blockBelowReal.y + Instance::getLocalPlayer()->getStateVectorComponent()->mVelocity.y;
        }
    }

    Vec3<float> getExtendedPosition(const Vec3<float>& velocity, Vec3<float>& blockBelow, float extendValue)
    {
        Vec3<float> mExtendedBlock = blockBelow;
        Vec3<float> mNormalizedVelocity = velocity.Normalize();
        mExtendedBlock.x += mNormalizedVelocity.x * extendValue;
        mExtendedBlock.z += mNormalizedVelocity.z * extendValue;
        return mExtendedBlock;
    }

    bool predictBlock(Vec3<float> blockBelow) {
        blockBelow = blockBelow.floor();

        auto blockSource = Instance::getBlockSource();
        if (!blockSource)
            return false;

        static std::vector<Vec3<int>> checkBlocks;
        if (checkBlocks.empty()) {
            for (int y = -rangeDistance; y < rangeDistance; y++) {
                for (int x = -rangeDistance; x < rangeDistance; x++) {
                    for (int z = -rangeDistance; z < rangeDistance; z++) {
                        checkBlocks.emplace_back(x, y, z);
                    }
                }
            }

            std::sort(checkBlocks.begin(), checkBlocks.end(), [](Vec3<int> first, Vec3<int> last) {
                return (first.x * first.x + first.y * first.y + first.z * first.z) <
                    (last.x * last.x + last.y * last.y + last.z * last.z);
                });
        }

        // Safe checklist (stack-based)
        static const std::vector<Vec3<int>> mChecklist = {
            { 0, -1, 0 },
            { 0,  1, 0 },
            { 0,  0, -1 },
            { 0,  0,  1 },
            { -1, 0, 0 },
            { 1,  0, 0 }
        };

        for (const Vec3<int>& blockOffset : checkBlocks) {
            Vec3<int> currentBlock = Vec3<int>(blockBelow.toInt()).add(blockOffset);
            mBlockPos = Vec3<float>(currentBlock.toInt().toFloat().add(Vec3<float>(0.5f, 0, 0.5f)));

            auto block = blockSource->getBlock(currentBlock);
            if (!block || !block->getLegacyBlock())
                continue;

            if (block->getLegacyBlock()->getBlockID() != 0)
                continue;

            Vec3<int> mBlock(currentBlock);

            bool mFoundCandidate = false;
            int faceIndex = 0;

            for (const Vec3<int>& offset : mChecklist) {
                Vec3<int> calc = mBlock - offset;

                auto neighbor = blockSource->getBlock(calc);
                if (neighbor && neighbor->getLegacyBlock()->getBlockID() != 0) {
                    mFoundCandidate = true;
                    mBlock = calc;
                    break;
                }
                ++faceIndex;
            }

            mClickBlockPos = mBlock.toFloat().add(Vec3<float>(0.5f, 0.f, 0.5f));

            if (mFoundCandidate) {
                auto player = Instance::getLocalPlayer();
                if (!player)
                    return false;

                if (placementMode == static_cast<int>(PlacementMode::Legit)) {
                    auto* hit = player->getLevel()->getHitResult();
                    hit->mFacing = faceIndex;
                    hit->mBlockPos = mBlockPos.toInt();
                    hit->mType = HitResultType::Tile;
                    hit->mPos = mBlockPos;
                }

                player->getGameMode()->buildBlock(mBlock, faceIndex, true);
                return true;
            }
        }

        return false;
    }
public:
    void onEnable()
    {
        auto lp = Instance::getLocalPlayer();
        if (!lp) return;

        Vec3<float> blockbelow = getBlockBelow(lp);

        mLockedY = blockbelow.y;
        mPrevSlot = lp->getSupplies()->mSelectedSlot;

        mBlockBelow = blockbelow;

        mLastPlaceTime = std::chrono::steady_clock::now();
    }

    void onDisable()
    {
        auto lp = Instance::getLocalPlayer();
        if (!lp) return;

        lp->getSupplies()->mSelectedSlot = mPrevSlot;
    }

    void onEvent(BaseTickEvent* event)
    {
        auto lp = Instance::getLocalPlayer();
        if (!lp) return;

        mFoundBlock = tryFindingBlock();
        if (!mFoundBlock) return;

        Vec3<float> velocity = lp->getStateVectorComponent()->mVelocity.Normalize();
        Vec3<float> blockBelow = getBlockBelow(lp);

        mBlockBelow = blockBelow;
        Vec3<float> yLockedBlockBelow = Vec3<float>(blockBelow.x, mLockedY, blockBelow.z);
        if (yLock) blockBelow = yLockedBlockBelow;

        if (yLock) {
            if (lp->isOnGround())
            {
                mLockedY = blockBelow.y;
            }

            adjustYCoordinate(getBlockBelow(lp));
            blockBelow = yLockedBlockBelow;
        }

        auto now = std::chrono::steady_clock::now();
        int delayMs = allowDelay ? delayMS : 0;

        bool canPlaceNow = true;

        if (delayMs > 0) {
            auto msSinceLast = std::chrono::duration_cast<std::chrono::milliseconds>(now - mLastPlaceTime).count();
            if (msSinceLast < delayMs)
            {
                // Not enough time has passed, skip block placement this tick
                canPlaceNow = false;
                //return;
            }
            else
            {
                // Update last place time
                mLastPlaceTime = now;
            }
        }

        if (canPlaceNow) {
            if (canPlace(blockBelow)) {
                if (predictBlock(blockBelow))
                {

                }
            }

            if (!mIsHoldingSpace) {
                for (int i = 1; i < extend; i++) {
                    Vec3<float> nextBlock = getExtendedPosition(velocity, blockBelow, i);
                    if (canPlace(nextBlock) && predictBlock(nextBlock)) {
                        break;
                    }
                }
            }
        }

        if (holdStyle == static_cast<int>(SwitchMode::Spoof))
        {
            lp->getSupplies()->mSelectedSlot = mPrevSlot;
        }

        if (holdStyle == static_cast<int>(SwitchMode::ClientSpoof))
        {
            PacketUtil::spoofSwitch(mBlockSlot);
            lp->getSupplies()->mSelectedSlot = mPrevSlot;
        }
    }

    void renderRiseBlockCounter()
    {
        auto lp = Instance::getLocalPlayer();
        if (!lp) return;

        static EasingUtil inEase;

        bool mShouldRender = this->isEnabled() && mFoundBlock && MotionUtil::isMoving();

        mShouldRender ? inEase.increment(ImRenderUtil::getDeltaTime() * 10.f / 10)
            : inEase.decrement(ImRenderUtil::getDeltaTime() * 2 * 10.f / 10);

        //float inScale = this->isEnabled() ? inEase.easeOutElastic() : inEase.easeOutBack();
        float inScale = inEase.easeOutExpo();

        if (inEase.isMax())
            inScale = 1;

        riseCounter.inScale = inScale;

        auto ci = Instance::get<ClientInstance>();
        auto guiData = ci->getGuiData();

        auto supplies = lp->getSupplies();
        auto inv = supplies->getInventory();

        float renderX = guiData->mWindowResolution.x / 2;
        float renderY = guiData->mWindowResolution.y / 2;

        Vec2<float> textPos(renderX, renderY + 110.f);

        int totalCount = 0;
        static int lastTotalCount = 0;

        const int mMaxSlots = invSlot ? 36 : 9;

        for (int i = 0; i < mMaxSlots; ++i)
        {
            ItemStack* stack = inv->getItemStack(i);

            if (stack != nullptr && stack->isBlockType() && !stack->getItem()->tryIsA("zzub_boombox"))
            {
                totalCount += stack->mCount;
            }
        }

        int diff = totalCount - lastTotalCount; // e.g., blocks used or gained this frame

        lastTotalCount = totalCount;

        std::string text = "Amount: ";
        std::string amount = std::to_string(totalCount);

        std::string displayText = text + amount;

        float textSize = 1.2f * inScale;

        Color textColor = Color(200, 200, 200);
        Color amountColor = Color(255, 255, 255);
        //Color amountColor = ColorUtil::getClientColor();

        float textWidth = ImRenderUtil::getTextWidth(&text, textSize);
        float displayTextWidth = ImRenderUtil::getTextWidth(&displayText, textSize);
        float displayTextHeight = ImRenderUtil::getTextHeight(textSize);

        textPos.x -= displayTextWidth / 2;
        textPos.x += 30;

        Vec2<float> totalTextPos(textPos.x + textWidth, textPos.y);

        Vec4<float> rectPos;
        rectPos.x = textPos.x - 36.f * textSize;
        rectPos.y = textPos.y - 7.5f * textSize;
        rectPos.z = textPos.x + displayTextWidth + 6.f * textSize;
        rectPos.w = textPos.y + displayTextHeight + 7.5f * textSize;

        riseCounter.mRectPos = Im3DUtil::scale(rectPos);

        //ImRenderUtil::fillRectangle(rectPos, Color(0, 0, 0), 0.6f);
        ImRenderUtil::fillShadowRectangle(rectPos, Color(0, 0, 0), 0.6f * inScale, 40, ImDrawFlags_ShadowCutOutShapeBackground, 15.f);

        ImRenderUtil::drawText(textPos, &text, textColor, textSize, inScale, true);
        ImRenderUtil::drawText(totalTextPos, &amount, amountColor, textSize, inScale, true);
    }

    void onEvent(ImRenderEvent* event)
    {
        if (counterStyle == static_cast<int>(CounterStyle::Rise))
        {
            renderRiseBlockCounter();
        }
    }

    void onEvent(RenderContextEvent* event)
    {
        auto lp = Instance::getLocalPlayer();
        if (!lp || !mFoundBlock) return;

        if (counterStyle == static_cast<int>(CounterStyle::Rise) && mBlockSlot != -1)
        {
            PlayerInventory* sup = lp->getSupplies();
            Inventory* inv = sup->getInventory();

            ItemStack* item = inv->getItemStack(mBlockSlot);

            Vec4<float> rectPos = riseCounter.mRectPos;
            float inScale = riseCounter.inScale;

            Vec2<float> itemPos(rectPos.x + 2.5f, rectPos.y + 2.f);

            RenderUtil::renderItem(item, itemPos, inScale, inScale);
        }
    }

    void onEvent(PacketEvent* event)
    {
        auto lp = Instance::getLocalPlayer();
        if (!lp) return;

        Vec3<float> localPos = lp->getPosition();

        if (event->mPacket->getID() == PacketID::PlayerAuthInput)
        {
            localPos = reinterpret_cast<PlayerAuthInputPacket*>(event->mPacket)->mPosition;
        }

        Vec2<float> mAngle = MathUtil::getRotations(localPos, mBlockPos);

        switch (rotations)
        {
        case 0: // None
            break;
        case 1: // Normal
            PacketUtil::setRotations(mAngle, event->mPacket);
            break;
        }
    }
};