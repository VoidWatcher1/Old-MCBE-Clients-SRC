#pragma once

class ChestStealer : public Module
{
public:
    ChestStealer() :
        Module("Chest Stealer", "Player", "Steal items out of chests.")
    {
        addSlider("SPS", "How many items are moved a second", &SPS, 1, 20, SliderType::Int);
    }

    float SPS = 10;

    bool IgnoreUseless = true;

    void onEvent(ContainerTickEvent* event)
    {
        Player* player(Instance::getLocalPlayer());
        ContainerScreenController* controller(event->mController);

        static std::atomic<bool> isStealing{ false };

        if (!controller)
            return;

        auto processItem = [&](int index) -> bool { // Process Item is in shift clicking them
            auto itemStack = player->getContainerManager()->getStack(index);
            if (itemStack && itemStack->mItem != nullptr) {
                controller->handleAutoPlace(Containers::Container, index);
                return true;
            }
            return false;
            };

        if (TimeUtil::hasTimeElapsed("ChestStealer", 1000 / SPS, true)) {
            for (int i = 0; i < 56; ++i) {
                if (processItem(i)) {
                    return;
                }
            }
        }

        //controller->closeContainer();
    }

    std::string getModeName() const override 
    {
        return "Delayed";
    }
};