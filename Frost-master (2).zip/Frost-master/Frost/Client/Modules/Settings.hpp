#pragma once

#include <string>
#include <vector>
#include <variant>
#include <functional>
#include <optional>
#include <memory>
#include <stdexcept>

enum class SettingType {
    Bool,
    Slider,
    Enum,
    Color,
    Button,
    TextBox
};

class Setting {
public:
    using Value = std::variant<bool*, float*, std::string*>;

    [[nodiscard]] const std::string& getName() const noexcept { return mName; }
    [[nodiscard]] const std::string& getDescription() const noexcept { return mDescription; }
    [[nodiscard]] SettingType getType() const noexcept { return mType; }

    [[nodiscard]] float getMin() const noexcept { return mMin; }
    [[nodiscard]] float getMax() const noexcept { return mMax; }
    [[nodiscard]] int getSliderPrecision() const noexcept { return mPrecision; }

    [[nodiscard]] const std::vector<std::string>& getEnumValues() const noexcept { return mEnumValues; }
    [[nodiscard]] int* getEnumIndex() const noexcept { return mEnumIndex.get(); }

    [[nodiscard]] bool shouldRender() const noexcept {
        return mRenderCondition ? mRenderCondition() : true;
    }

    void setBool(bool value) {
        if (auto val = std::get_if<bool*>(&mValue)) {
            **val = value;
        }
        else {
            throw std::runtime_error("Setting is not a bool");
        }
    }

    void setEnum(int value) {
        int* current_index = getEnumIndex();
        *current_index = value;
    }

    void setFloat(float value) {
        if (auto val = std::get_if<float*>(&mValue)) {
            **val = value;
        }
        else {
            throw std::runtime_error("Setting is not a float");
        }
    }

    // -- Value accessors --
    [[nodiscard]] bool getBool() const {
        if (auto val = std::get_if<bool*>(&mValue)) return **val;
        throw std::runtime_error("Setting is not a bool");
    }

    [[nodiscard]] float getFloat() const {
        if (auto val = std::get_if<float*>(&mValue)) return **val;
        throw std::runtime_error("Setting is not a float");
    }

    [[nodiscard]] const std::string& getText() const {
        if (auto val = std::get_if<std::string*>(&mValue)) return **val;
        throw std::runtime_error("Setting is not a string");
    }

    // -- Constructors --
    Setting(const std::string& name, const std::string& desc, bool* state,
        std::function<bool()> visible = [] { return true; })
        : mName(name), mDescription(desc), mType(SettingType::Bool), mValue(state), mRenderCondition(visible) {}

    Setting(const std::string& name, const std::string& desc, float* value,
        float min, float max, int precision = 1,
        std::function<bool()> visible = [] { return true; })
        : mName(name), mDescription(desc), mType(SettingType::Slider), mValue(value),
        mMin(min), mMax(max), mPrecision(precision), mRenderCondition(visible) {}

    Setting(const std::string& name, const std::string& desc, const std::vector<std::string>& enums,
        int* index, std::function<bool()> visible = [] { return true; })
        : mName(name), mDescription(desc), mType(SettingType::Enum), mEnumValues(enums),
        mEnumIndex(index), mRenderCondition(visible) {}

    Setting(const std::string& name, std::string* text,
        std::function<bool()> visible = [] { return true; })
        : mName(name), mType(SettingType::TextBox), mValue(text), mRenderCondition(visible) {}

    // UI Animation properties

    class UIAnimations
    {
    public:
        float slider_ease = 0.f;
        float bool_scale = 0.f;
        float enum_slide = 0.f;

        Vec2<float> mArrowRotation = Vec2<float>(0, 0);

        bool mIsDragging = false;
        bool mEnumExtended = false;
    };

    UIAnimations ui_animations;
private:
    std::string mName;
    std::string mDescription;
    SettingType mType;

    Value mValue;
    std::vector<std::string> mEnumValues;
    std::unique_ptr<int> mEnumIndex;

    float mMin = 0.f, mMax = 0.f;
    int mPrecision = 1;

    std::function<bool()> mRenderCondition;
};
