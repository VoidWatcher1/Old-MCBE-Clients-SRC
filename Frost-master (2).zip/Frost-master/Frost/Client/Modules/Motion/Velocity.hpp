#pragma once

class Velocity : public Module
{
public:
    enum class Mode
    {
        Full,
        Percent,
    };


    Velocity() :
        Module("Velocity", "Motion", "Allows you to modify your velocity from attacks, explosions, etc.")
    {
        addEnum("Mode", "The mode of the velocity.", { "Full", "Percent" }, &mode);
        addSlider("Horizontal", "The multiplier for the horizontal velocity.", &horizontal, -2, 2, SliderType::Float, [this] { return mode == static_cast<int>(Mode::Percent); });
        addSlider("Vertical", "The multiplier for the vertical velocity.", &vertical, -2, 2, SliderType::Float, [this] { return mode == static_cast<int>(Mode::Percent); });
    }

private:
    int mode = 0;

    float horizontal = 0.f;
    float vertical = 0.f;
public:
    void onEvent(PacketReceiveEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        if (event->mPacket->getID() == PacketID::SetActorMotion)
        {
            auto packet = std::reinterpret_pointer_cast<SetActorMotionPacket>(event->mPacket);

            if (packet->mRuntimeId == player->getRuntimeID())
            {
                if (mode == static_cast<int>(Mode::Full))
                {
                    event->setCancelled(true);
                }
                else
                {
                    Vec3<float> motion = packet->mMotion;
                    motion.x *= horizontal;
                    motion.z *= horizontal;
                    motion.y *= vertical;
                    packet->mMotion = motion;
                }
            }
        }
    }
};