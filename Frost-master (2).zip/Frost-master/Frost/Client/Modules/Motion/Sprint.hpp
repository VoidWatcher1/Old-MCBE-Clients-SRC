#pragma once

class Sprint : public Module
{
public:
    Sprint() :
        Module("Sprint", "Motion", "Sprint automatically.")
    {
        addEnum("Mode", "The mode of the sprint.", { "Normal" }, &mode);
    }

private:
    int mode = 0;

public:
    void onEvent(BaseTickEvent* baseTickEvent)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        const bool moving_forward = player->getMoveInputHandler()->mForward;
        const bool moving_backward = player->getMoveInputHandler()->mBackward;

        const bool is_currently_moving = MotionUtil::isMoving();

        player->setSprinting(true);
    }
};