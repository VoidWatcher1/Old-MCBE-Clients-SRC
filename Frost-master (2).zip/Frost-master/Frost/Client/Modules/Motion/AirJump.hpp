#pragma once

class AirJump : public Module
{
public:
    AirJump() :
        Module("Air Jump", "Motion", "Jumps even if you aren't touching the ground.")
    {

    }

    void onEvent(RenderContextEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        player->setIsOnGround(true);
    }

    void onDisable()
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        player->setIsOnGround(false);
    }
};