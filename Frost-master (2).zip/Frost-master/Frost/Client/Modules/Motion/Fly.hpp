#pragma once

class Fly : public Module
{
public:
    Fly() :
        Module("Fly", "Motion", "Allows you to fly.")
    {
        addEnum("Mode", "The type of fly.", { "Vanilla", "Flareon" }, &mode);
        addSlider("Horizontal Speed", "The horizontal speed of the fly.", &horizontalSpeed, 0, 20);
        addSlider("Vertical Speed", "The vertical speed of the fly.", &verticalSpeed, 0, 20);
        addSlider("Timer", "Internal games timer speed.", &timer, 15, 20);
        addBool("Halt", "Halts the fly on disabling.", &halt);
        addBool("Glide", "Enables controlled falling by reducing downward velocity.", &allowGlide);
        addSlider("Glide Value", "The value of up and down speed.", &glide, -0.10f, 0.f, SliderType::DoubleFloat, [this] { return allowGlide; });
        addBool("Ground Spoof", "Spoofs players pos to the ground.", &groundSpoof);
    }
private:
    enum class Mode
    {
        Vanilla,
        Flareon
    };

    int mode = 0;
    bool halt = true;
    float horizontalSpeed = 2.57f;
    float verticalSpeed = 3.f;
    float timer = 20.f;
    bool allowGlide = false;
    float glide = -0.02f;

    // Ground Spoof
    bool groundSpoof = false;
    float yLevelPos = 0;

    // Flareon
    class FlareonHandles
    {
    public:
        Vec3<float> start_position = 0;
        bool should_reset_flight = false;

        static void handleFlightMovement(Player* player, StateVectorComponent* state, Vec3<float> start_level, bool on_ground)
        {
            static float current_speed;
            static float last_speed;
            
            if (state->mPosition.y < start_level.y) {
                if (TimeUtil::hasTimeElapsed("FlyJumpDelay", 100, true)) {
                    current_speed = 0.97f;
                    last_speed = 0.97f;
                    player->jumpFromGround();
                }
            }
            else if (!on_ground) {
                {
                    Vec3<float> velocity = state->mVelocity;
                    if (abs(velocity.magnitudexz()) > last_speed) {
                        current_speed = velocity.magnitudexz();
                    }
                    last_speed = velocity.magnitudexz();
                    MotionUtil::setSpeed(current_speed * 0.9f);
                }
            }
        }
    };
    
    FlareonHandles flareon_handles;
    
public:
    void onEnable()
    {
        Instance::get<ClientInstance>()->getMinecraftSim()->setTimer(timer);

        Player* player = Instance::getLocalPlayer();
        if (!player)
            return;

        yLevelPos = player->getStateVectorComponent()->mPosition.y;

        switch (mode) {
        case 0: // Vanilla
            break;
        case 1: // Flareon
            flareon_handles.start_position = player->getRenderPosition();
            flareon_handles.should_reset_flight = false;
            break;
        }
    }

    void onEvent(BaseTickEvent* event)
    {
        if (!Instance::getLocalPlayer())
            return;

        Player* player = Instance::getLocalPlayer();
        StateVectorComponent* state = player->getStateVectorComponent();
        bool isKeyPressed = player->getMoveInputHandler()->isPressed();

        float glideValue = 0.f;
        if (allowGlide) glideValue = glide;

        Instance::get<ClientInstance>()->getMinecraftSim()->setTimer(timer);

        switch (mode) {
        case 0: // Vanilla
            MotionUtil::setSpeed(horizontalSpeed / 10);
            state->mVelocity.y = glideValue;
            MotionUtil::handleMovementVelocity(verticalSpeed / 10);
            break;
        case 1: // Flareon
            if (isKeyPressed)
            {
                player->setSprinting(true);

                flareon_handles.handleFlightMovement(player, state, flareon_handles.start_position, player->isOnGround());
            }
            break;
        }
    }

    void onEvent(PacketEvent* event)
    {
        if (event->mPacket->getID() == PacketID::PlayerAuthInput && groundSpoof)
        {
            auto* pkt = event->mPacket->tryGetPacketAs<PlayerAuthInputPacket>();

            pkt->mPosition.y = yLevelPos;
        }
    }

    void onDisable()
    {
        Instance::get<ClientInstance>()->getMinecraftSim()->setTimer(20.f);

        if (halt) {
            MotionUtil::setSpeed(0);
        }
    }
};