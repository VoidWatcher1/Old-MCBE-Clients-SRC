#pragma once

class Step : public Module
{
public:
    Step() :
        Module("Step", "Motion", "Stepping on blocks lmao.")
    {
        addEnum("Mode", "The type of step", { "Normal", "Flareon" }, &mode);
        addSlider("Height", "The maximum height which you will automatically step.", &height, 0, 5);
    }

private:
    int mode = 0;
    float height = 1.3;

    bool shouldClimb = false;
    bool shouldStop = false;
public:
    void onEvent(BaseTickEvent* event)
    {
        auto ci = Instance::get<ClientInstance>();
        auto lp = ci->getLocalPlayer();

        if (!ci or !lp or !Instance::isAllowedToUseKeys())
            return;

        auto state = lp->getStateVectorComponent();

        bool isPressed = lp->getMoveInputHandler()->isPressed();

        auto handleFlareonStep = [this, &lp]() {
            if (lp->isCollidingHorizontal() && lp->getMoveInputHandler()->mForward) {
                lp->getStateVectorComponent()->mVelocity.y = 0.0f;

                {
                    auto& lowerPos = lp->getAABBShapeComponent()->mMin;
                    auto& upperPos = lp->getAABBShapeComponent()->mMax;

                    lowerPos.y += height / 10;
                    upperPos.y += height / 10;
                }
            }
            };

        switch (mode) {
        case 0: // Normal
            lp->getComponent<MaxAutoStepComponent>()->mMaxAutoStep = height;
            break;
        case 1: // Flareon
            if (isPressed && lp->isCollidingHorizontal() && (lp->isOnGround() || shouldClimb)) 
            {
                handleFlareonStep();

                shouldStop = true;
                shouldClimb = true;
            }
            else if (shouldStop) 
            {
                shouldStop = false;
                shouldClimb = false;

                lp->getStateVectorComponent()->mVelocity.y = 0;
            }
            break;
        }
    }
};