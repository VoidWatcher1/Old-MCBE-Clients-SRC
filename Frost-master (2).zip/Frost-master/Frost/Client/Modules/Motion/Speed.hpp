#pragma once

#include "../Player/Scaffold.hpp"

class Speed : public Module
{
public:
    Speed() :
        Module("Speed", "Motion", "Hop around like a bunny!")
    {
        // Mode Enum
        addEnum("Mode", "The mode of speed.", { "Friction", "Flareon" }, &speed_mode);

        // Speed Settings
        addSlider("Friction", "How fast you will slowdown off ground.", &friction, 0, 10);

        // Damage Boost Settings
        addBool("Damage Boost", "Whether or not to boost speed when taking damage.", &enable_damageboost);
        addSlider("Damage Speed", "How fast you will go when you get damaged.", &damage_boost_speed, 0, 5, SliderType::Float, [this] { return enable_damageboost; });

        // Swiftness Settings
        addBool("Swiftness", "Whether or not to apply swiftness when space is pressed.", &enable_swiftness);
    }

private:
    enum Mode {
        Friction = 0,
        Flareon = 1
    };

    int speed_mode = 0;

    float friction  = 10.f;
    float damage_boost_speed  = 1.5f;
    
    bool enable_swiftness = false;
    bool enable_damageboost = false;

    class DamageBoostHandler
    {
    public:
        static inline bool damaged = false;
        static inline bool apply_damageboost = false;
        static inline Vec3<float> last_velocity;
    };

    DamageBoostHandler damage_boost_handler;

    std::map<MobEffect::EffectType, uint64_t> mEffectTimers = {};
public:

    void onEnable()
    {
        
    }

    void onDisable()
    {
        Instance::get<ClientInstance>()->getMinecraftSim()->setTimer(20.f);
    }

    // Swiftness later
    bool tickSwiftness()
    {
        return false;
    }

    void handleFlareon(Player* player)
    {
        bool sprint = true;
        player->setSprinting(sprint);

        auto player_state = player->getComponent<StateVectorComponent>();

        bool key_pressed = player->getMoveInputHandler()->isPressed();

        static float current_speed;
        static float last_speed;

        static bool jumped_from_ground = false;

        auto on_ground = player->isOnGround();

        if (key_pressed)
        {
            if (enable_damageboost && damage_boost_handler.damaged)
            {
                float boosted_speed = damage_boost_handler.last_velocity.magnitudexz() * damage_boost_speed;
                current_speed = boosted_speed;
                last_speed = boosted_speed;
                damage_boost_handler.apply_damageboost = true;
                TimeUtil::resetTime("speed_damageboost_time");
                damage_boost_handler.damaged = false;
            }

            if (TimeUtil::hasTimeElapsed("speed_damageboost_time", 590, false))
            {
                damage_boost_handler.apply_damageboost = false;
            }
            
            if (on_ground)
            {
                if (!jumped_from_ground)
                {
                    player->jumpFromGround();
                    jumped_from_ground = true;
                }
            }
            else
            {
                jumped_from_ground = false;
                
                Vec3<float> velocity = player_state->mVelocity;
                if (abs(velocity.magnitudexz()) > last_speed)
                {
                    current_speed = velocity.magnitudexz();
                }
                last_speed = velocity.magnitudexz();
                current_speed = current_speed * (friction / 10);

                //MotionUtil::setSpeed(0.257);
                //MotionUtil::setSpeed(0.33949999809265137);

                if (damage_boost_handler.apply_damageboost)
                {
                    MotionUtil::setSpeed(current_speed);
                }
            }
        }
    }

    void onEvent(BaseTickEvent* event) override
    {
        auto player = Instance::get<ClientInstance>()->getLocalPlayer();
        if (!player) return;

        if (player->hasComponent<RedirectCameraInputComponent>())
        {
            return;
        }

        if (enable_swiftness)
        {
            /*if (tickSwiftness()) {
                return;
            }*/
        }

        switch (speed_mode)
        {
        case 0:
            //handleFriction(mPlayer); // add handling for friction soon
            break;
        case 1: // Desync Boost
            handleFlareon(player);
            break;
        }
    }

    void onEvent(PacketReceiveEvent* event)
    {
        Player* mPlayer = Instance::get<ClientInstance>()->getLocalPlayer();
        if (!mPlayer) return;

        if (event->mPacket->getID() == PacketID::SetActorMotion)
        {
            if (event->mPacket->tryGetPacketAs<SetActorMotionPacket>()->mRuntimeId == mPlayer->getRuntimeID())
            {
                damage_boost_handler.damaged = true;
                damage_boost_handler.last_velocity = event->mPacket->tryGetPacketAs<SetActorMotionPacket>()->mMotion;
            }
        }
    }

    void onEvent(PacketEvent* event)
    {
        
    }
};
