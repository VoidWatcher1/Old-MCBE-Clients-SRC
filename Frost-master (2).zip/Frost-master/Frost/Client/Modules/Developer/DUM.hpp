#pragma once

class DUM : public Module
{
public:
    DUM() :
        Module("DUM", "Developer", "Uhhhh chatgpt pro code!!")
    {
        addEnum("Mode", "YOUR BIPAS MODE DUMMY", { "ChatGPT PRO Bypass" }, &mode);
    }
private:
    enum class Mode {
        ChatGPT
    };

    int mode = 0;

    class FlareonHandles {
    public:
        Vec3<float> lastValidGroundPos{ 0.f, 0.f, 0.f };
        bool groundPosValid = false;

        static bool isBlockNonSolid(Block* block) {
            if (!block || !block->getLegacyBlock()) return true;
            const int id = block->getLegacyBlock()->getBlockID();
            // 0 = Air, 95 = Barrier, 44 = Slab, extend as needed
            //return id == 0 || id == 95 || id == 44 || block->getLegacyBlock()->getMaterial()->isLiquid;
            return id == 0 || id == 95;
        }

        Vec3<float> traceGroundBelowPlayer(Actor* player, BlockSource* source) {
            if (!player || !source) return Vec3<float>(0.f, 0.f, 0.f);

            auto pos = player->getPos();
            if (!pos) return Vec3<float>(0.f, 0.f, 0.f);

            Vec3<int> checkPos = Vec3<int>(floorf(pos->x), floorf(pos->y - 1.62f), floorf(pos->z));
            const int maxDrop = 100; // avoid infinite loops
            for (int i = 0; i < maxDrop && checkPos.y > 0; i++, checkPos.y--) {
                Block* block = source->getBlock(checkPos);
                if (!isBlockNonSolid(block)) {
                    Vec3<float> groundPos = checkPos.toFloat();
                    groundPos.x += 0.5f;
                    groundPos.y += 1.f;
                    groundPos.z += 0.5f;
					float increasement = 1.62001f; // 1.620010f offset for normal ground, 1.120010f for slabs
					//if (BlockUtil::isSlab(block)) {
						//increasement = 1.12001f; // slab offset
					//}
                    lastValidGroundPos = groundPos;
					lastValidGroundPos.y += increasement; // Adjust Y position based on block type
                    groundPosValid = true;
                    return groundPos;
                }
            }

            groundPosValid = false;
            return Vec3<float>(0.f, 0.f, 0.f);
        }

        Vec3<float> getHandledMovementPos() {
            auto player = Instance::getLocalPlayer();
            auto source = Instance::getBlockSource();
            if (!player || !source) return Vec3<float>(0.f, 0.f, 0.f);

            return traceGroundBelowPlayer(player, source);
        }
    };

    FlareonHandles flareonHandles;

public:
    void onEvent(BaseTickEvent* baseEvent) {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        auto sv = player->getStateVectorComponent();
        if (!sv) return;

        float current_speed = 0.257f;

        auto on_ground = player->isOnGround();

        // Dynamic horizontal motion logic
        MotionUtil::setSpeed(current_speed);

        // Reset Y-velocity to keep on same vertical level
        sv->mVelocity.y = 0.f;

        // Apply assisted velocity handling
        MotionUtil::handleMovementVelocity(0.6f);

        // Update ground pos every tick for smoother interpolation
        flareonHandles.getHandledMovementPos();
    }

    void onEvent(PacketEvent* event) {
        if (event->mPacket->getID() != PacketID::PlayerAuthInput) return;

        auto* pkt = event->mPacket->tryGetPacketAs<PlayerAuthInputPacket>();
        if (!pkt) return;

        if (!flareonHandles.groundPosValid) return;

        Vec3<float> correctedPos = pkt->mPosition;
		correctedPos.y = flareonHandles.lastValidGroundPos.y; // 1.620010f offset // slab: 1.120010f

        // Prevent snapping
        if (fabs(correctedPos.y - pkt->mPosition.y) < 6.0f)
        {
            pkt->mPosition.y = correctedPos.y;
        }
        else
        {
            ChatUtil::sendMessage("WARNING: vertical level high decrease immediately to prevent flagging");
            pkt->mPosition.y = correctedPos.y;
            ChatUtil::sendMessage("Dum: vertical collision corrected");
        }
    }
};