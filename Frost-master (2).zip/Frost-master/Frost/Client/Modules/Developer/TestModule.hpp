#pragma once

class TestModule : public Module
{
public:
    TestModule() :
        Module("Test Module", "Developer", "For testin purposes")
    {
        addEnum("Mode", "", { "Normal", "Meme", "None" }, &mode);
        addSlider("Amount", "", &viewBobAmount, -1, 1);
        addSlider("Tilt Amount", "", &tiltAmount, -360, 360);
        addSlider("Mob Animations Amount", "", &mobAnimationsAmount, -50, 50);
    }

    float viewBobAmount = 0.3;
    float tiltAmount = 0.f;
    float mobAnimationsAmount = 0.f;
    int mode = 0;

    static inline Vec3<float> currentpos = Vec3<float>(0, 0, 0);
    static inline Vec3<float> packetpos = Vec3<float>(0, 0, 0);

    void onEvent(BaseTickEvent* event)
    {
        if (!Instance::getLocalPlayer())
            return;

        auto player = Instance::getLocalPlayer();
        auto mob = (Mob*)Instance::getLocalPlayer();

        //mob->getComponent<MobAnimationComponent>()->mValue = mobAnimationsAmount;

        //player->getComponent<MobHurtTimeComponent>()->mHurtTime = tiltAmount;
        //mob->mHurtDir = tiltAmount;
        //mob->mOTilt = tiltAmount;
        //mob->mTilt = tiltAmount;
        //player->setPosition(Vec3<float>(0, 0, 0));

        switch (mode)
        {
        case 0:
            break;
        case 1:
            Instance::getLocalPlayer()->setBob(viewBobAmount);
            break;
        case 2:
            Instance::getLocalPlayer()->setBob(0);
            break;
        }
    }

    void onEvent(LevelRendererEvent* event)
    {
        if (Instance::getLocalPlayer() == nullptr) return;

        Vec3<float> start(0, 0, 0);
        Vec3<float> end(0, 0, 10);

        RenderUtil::drawRing3D(FrameUtil::mTransform.mPlayerPos, 0.8, 300, 2);

        RenderUtil::setColor(255, 255, 255, 255);
        RenderUtil::drawLine3D(start, end, true);
    }

    void onEvent(ImRenderEvent* event)
    {
        if (Instance::getLocalPlayer() == nullptr) return;

        Vec2<float> mTest(100, 100);
        Vec2<float> mTest2(100, 120);
        std::string lol = std::to_string(Instance::getLocalPlayer()->getPosition().y);
        std::string lol2 = std::to_string(packetpos.y);
        ImRenderUtil::drawText(mTest, &lol, Color(255, 255, 255), 2, 1, true);
        ImRenderUtil::drawText(mTest2, &lol2, Color(255, 255, 255), 2, 1, true);

        //Vec2<float> mTest(100, 100);
        //std::string lol = std::to_string(Instance::getLocalPlayer()->getFallDistance());
        //ImRenderUtil::drawText(mTest, &lol, Color(255, 255, 255), 2, 1, true);
        //Im3DUtil::drawRing3D(FrameUtil::mTransform.mPlayerPos, 0.8, 300, 2);
        /*Vec4<float> firstBox(50, 50, 300, 300);
        Vec4<float> secondBox(100, 100, 250, 250);
        Vec4<float> thirdBox(150, 150, 200, 200);

        ImRenderUtil::fillRectangle(firstBox, Color(0, 0, 0), 1, 0);
        ImRenderUtil::fillRectangle(secondBox, Color(255, 255, 255), 1, 0);
        ImRenderUtil::fillRectangle(thirdBox, Color(0, 0, 0), 1, 0);*/
        //static ImVec4 color = ImVec4(1, 1, 1, 1);
        //Vec4<float> colorPickerPos(50, 50, 300, 150);
        //ImRenderUtil::RenderColorPicker(color, colorPickerPos);
        //ImRenderUtil::fillRectangle(colorPickerPos, Color(255, 255, 255), 1, 0);
    }

    void onEvent(PacketEvent* event)
    {
        if (event->mPacket->getID() == PacketID::PlayerAuthInput)
        {
            packetpos = event->mPacket->tryGetPacketAs<PlayerAuthInputPacket>()->mPosition;
        }
        
    }

    void onEvent(RenderContextEvent* event)
    {
        /*
        auto muirc = Instance::get<MinecraftUIRenderContext>();
        auto ci = Instance::get<ClientInstance>();
        auto lp = Instance::getLocalPlayer();

        BaseActorRenderContext barc(muirc->mScreenContext, ci,
            ci->getMinecraftGame());

        if (lp == nullptr) return;

        */
        /*auto muirc = Instance::get<MinecraftUIRenderContext>();
        auto ci = Instance::get<ClientInstance>();
        auto lp = Instance::getLocalPlayer();

        BaseActorRenderContext barc(muirc->mScreenContext, ci,
            ci->getMinecraftGame());

        if (lp == nullptr) return;

        PlayerInventory* sup = lp->getSupplies();
        Inventory* inv = sup->getInventory();

        int selectedSlot = sup->mSelectedSlot;
        ItemStack* item = inv->getItemStack(selectedSlot);

        if (item != nullptr)
        {
            barc.mItemRenderer->renderGuiItemNew(&barc, item, 0, 10, 10, 1, 10, false);
        }*/

        /*auto _this = Instance::get<ScreenView>();
        std::string mLayer = _this->mTree->mUIControl->getLayerName();

        if (mLayer != "debug_screen" && mLayer != "toast_screen")
        {
            _this->mTree->mRootUIControl->forEachControl([this](std::shared_ptr<UIControl>& control) {
                if (control->getLayerName() == "hud_player") {
                    auto pos = control->parentRelativePosition;

                    Vec2<float> setPos = Im3DUtil::scale(Vec2<float>(Instance::get<ClientInstance>()->getGuiData()->mWindowResolution.x / 2, 200));
                    control->parentRelativePosition = setPos;

                    auto component = reinterpret_cast<CustomRenderComponent*>(control->getComponents()[4].get());
                    component->getRenderer()->mState = 1.0f;

                    return true;
                }
                return false;
            });
        }*/
    }
};