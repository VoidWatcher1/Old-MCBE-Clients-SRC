#pragma once

class SwiftFly : public Module
{
public:
    SwiftFly() :
        Module("Swift Fly", "Developer", "Surf on air")
    {
	}
    /*
	addSlider("Speed", "The speed of the fly.", &mSpeed, 0.1f, 50.f, SliderType::Float);
	addSlider("Speed Min", "The minimum speed of the fly.", &mSpeedMin, 0.1f, 50.f, SliderType::Float);
	addSlider("Speed Max", "The maximum speed of the fly.", &mSpeedMax, 0.1f, 50.f, SliderType::Float);
	addSlider("Increase Horizontal Speed", "How much to increase horizontal speed.", &mIncreaseHorizontalSpeed, 0.1f, 10.f, SliderType::Float);
	addSlider("Delay Speed", "How long to wait before increasing speed.", &mDelaySpeed, 0.1f, 20.f, SliderType::Float);
	addSlider("Timer Value", "The timer value for the fly.", &mTimerValue, 0.1f, 10.f, SliderType::Float);
	addSlider("Timer Min", "The minimum timer value.", &mTimerMin, 0.1f, 10.f, SliderType::Float);
	addSlider("Timer Max", "The maximum timer value.", &mTimerMax, 0.1f, 10.f, SliderType::Float);
	addSlider("Increase Speed", "How much to increase speed over time.", &mIncreaseSpeed, 0.1f, 5.f, SliderType::Float);
	addSlider("Glide", "The glide effect when flying.", &mGlide, 0.1f, 10.f, SliderType::Float);
	addBool("Test Glide", "Enable test glide mode.", &mTestGlide);
	addBool("Full Stop", "Enable full stop mode.", &mFullStop);
	addBool("Cancel Setting", "Cancel setting when flying.", &mCancelSetting);
	addBool("Should Apply RakPeer", "Whether to apply RakPeer packets or not.", &mShouldApplyRakPeer);
	// Inbuilt stuff
	addBool("Debug Mode", "Enable debug mode for Swift Fly.", &mDebug);*/

public:
    float mSpeed = 2.921621561050415;
    float mSpeedMin = 2.378378391265869;
    float mSpeedMax = 34.378379821777344;

    float mIncreaseHorizontalSpeed = 1.5945945978164673;
    float mDelaySpeed = 7.405405521392822;

    float mTimerValue = 1.3108108043670654;
    float mTimerMin = 0.754054069519043;
    float mTimerMax = 4.764864921569824;

    float mIncreaseSpeed = 1.4324324131011963;

    float mGlide = 1.386486530303955;

    bool mTestGlide = false;
    bool mFullStop = true;
    bool mCancelSetting = true;

    bool mShouldApplyRakPeer = false;


    float height = 4;
    float netSkipMS = 500;

    bool first = true;
    bool cancel = false;

    float mDesyncDelay = 0;


    // Inbuilt stuff
    int speedIndex = 0;
    int timerIndex = 0;

    bool isSpeedIncrease = false;
    bool isTimerIncrease = false;

    bool mDebug = false;



    // For future fly
    int mCanFly = 0;
    float mTimerDuplicate = 3.f;
    bool mStopFlying = false;
public:
    void onEnable() {
        if (!Instance::getLocalPlayer()) return;

        TimeUtil::resetTime("swiftFlyMs");
        speedIndex = 0;
        timerIndex = 0;
        isSpeedIncrease = false;
        isTimerIncrease = false;
        first = true;
        cancel = false;
    }

    void onEvent(BaseTickEvent* event) {
        if (!Instance::get<ClientInstance>())
            return;

        if (!Instance::getLocalPlayer() || !Instance::getLocalPlayer()->getStateVectorComponent())
            return;

        Player* player = Instance::getLocalPlayer();
        StateVectorComponent* state = player->getStateVectorComponent();

        // Adjustment
        if (mSpeedMax < mSpeedMin) mSpeedMax = mSpeedMin;
        if (mTimerMax < mTimerMin) mTimerMax = mTimerMin;

        float deltaSpeed = mSpeedMax - mSpeedMin;
        float deltaTimer = mTimerMax - mTimerMin;
        float latestTimerValue = 0;
        float currentSpeed = 0;
        float nextSpeed = 0;
        float nextTimer = 0;

        int delayTick = (int)(mDelaySpeed);
        if (speedIndex == 0) {
            if (first) {
                currentSpeed = mSpeedMin / 10;
                first = false;
            }
            else currentSpeed = mSpeedMax / 10;
            speedIndex = delayTick;
            state->mVelocity.y = mGlide / 5;
            mShouldApplyRakPeer = true;
        }
        else {
            if (speedIndex == delayTick) //
                mShouldApplyRakPeer = false; //

            else mShouldApplyRakPeer = true; //

            currentSpeed = mSpeedMin / 10;
            speedIndex--;

            if (speedIndex == 0) //
                mShouldApplyRakPeer = false; //

            if (state->mVelocity.y > 0 && mCancelSetting) cancel = true;
            else cancel = false;
        }

        // Erm
        if (isTimerIncrease) {
            latestTimerValue = mTimerMin + (deltaTimer * timerIndex * mIncreaseSpeed / 10);
            nextTimer = mTimerMin + (deltaTimer * (timerIndex + 1) * mIncreaseSpeed / 10);
            if (nextTimer < mTimerMax) timerIndex++;
            else {
                isTimerIncrease = false;
                timerIndex = 1;
                latestTimerValue = mTimerMax;
            }
        }
        else
        {
            latestTimerValue = mTimerMax - (deltaTimer * timerIndex * mIncreaseSpeed / 10);
            nextTimer = mTimerMax - (deltaTimer * (timerIndex + 1) * mIncreaseSpeed / 10);
            if (nextTimer > mTimerMin) timerIndex++;
            else {
                isTimerIncrease = true;
                timerIndex = 1;
                latestTimerValue = mTimerMin;
            }
        }

        float currentGlide = mGlide / 100;
        if (mTestGlide) {
            currentGlide = mGlide / 100 * (1 - latestTimerValue);
        }
        else currentGlide = mGlide / 100;

        /*
        if (mDebug) {
            ChatUtil::sendCustomMessage("Current Speed:" + std::to_string(currentSpeed * 10), "Swift Fly");

            if (!mShouldApplyRakPeer) ChatUtil::sendCustomMessage(Util::combine(YELLOW, "Sending Packets...", RESET), "Fly");
            if (cancel) ChatUtil::sendCustomMessage(Utils::combine(YELLOW, "Canceling Packets...", RESET), "Fly");
        }

        if (state->mVelocity.y < 0)
            ChatUtil::sendCustomMessage(Util::combine(GREEN, "Safe to land", RESET), "Swift Fly");*/

        Instance::get<ClientInstance>()->getMinecraftSim()->setTimer(latestTimerValue);

        bool keyPressed = player->getMoveInputHandler()->isPressed();

        if (!keyPressed) return;
        player->setSprinting(true);

        MotionUtil::setSpeed(currentSpeed);
    }

    void onEvent(RunUpdateCycleEvent* event) {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        if (mShouldApplyRakPeer) {
            event->setCancelled(true);
        }
    }

    void onEvent(PacketEvent* event) {
        if (event->mPacket->getID() == PacketID::PlayerAuthInput) {
            auto* pkt = (PlayerAuthInputPacket*)event->mPacket;
            if (pkt) {
                pkt->mRotation.x = 0;
                pkt->mRotation.y = 0;
                pkt->mYHeadYaw = 0;
            }
        }

        if (cancel)
            event->setCancelled(true);
    }

    void onDisable() {
        if (!Instance::get<ClientInstance>())
            return;

        if (!Instance::getLocalPlayer() || !Instance::getLocalPlayer()->getStateVectorComponent())
            return;

        Instance::get<ClientInstance>()->getMinecraftSim()->setTimer(20);

        if (mFullStop) {
            MotionUtil::setSpeed(0);
        }
    }
};