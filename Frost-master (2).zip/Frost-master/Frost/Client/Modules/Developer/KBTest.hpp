#pragma once

class KBTest : public Module
{
public:
    KBTest() :
        Module("KB Test", "Developer", "For testin purposes")
	{
		addSlider("KB", "The amount of knockback to apply.", &knockback, 0, 10);
		addBool("Apply", "Whether to apply the knockback or not.", &apply);
    }

	float knockback = 1.f;
	bool apply = true;
};