#pragma once

class Teams : public Module
{
public:
    Teams() :
        Module("Teams", "Combat", "Automatically friends everyone on your team.")
    {

    }

    std::string getModeName() const override 
    {
        return "Color";
    }
};