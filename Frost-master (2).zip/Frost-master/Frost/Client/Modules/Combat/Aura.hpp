#pragma once

#include "../Visual/Animations.hpp"

class Aura : public Module
{
public:
    Aura() :
        Module("Aura", "Combat", "Attack players in your radius")
    {
        addEnum("Target Mode", "How many entities should be attacked.", { "Single", "Multi", "Switch" }, &switchMode);
        addEnum("Rotations", "The style of the rotations.", { "Disabled", "Normal", "Flick" }, &rotationMode);
        addEnum("Bypass", "The style of the bypassing.", { "Disabled", "Raycast" }, &bypassMode);

        addEnum("Swing", "Controls how it will send the swing action.", { "Normal", "None" }, &swing);
        addEnum("AutoSlot", "The way the players arm swing.", { "Disabled", "Switch", "Spoof", "Silent" }, &autoSlot);

        addEnum("Visual", "The visual to render on the target.", { "Disabled", "Lines" }, &visuals);

        addSlider("Range", "Controls the attacks per second.", &range, 3, 10);
        addSlider("APS", "attack per second.", &APS, 0, 20);
        addBool("Strafe", "Strafe the player towards the entity.", &strafe);
        addBool("Timed swing", "Times the swing with the attack.", &timedSwing);
        addBool("Hotbar Only", "Bypass the Invalid Packet! kick.", &hotbarOnly);
    }

private:
    int switchMode = 0;
    int rotationMode = 0;
    int bypassMode = 0;
    int swing = 0; // enum
    int autoSlot = 0; // enum
    int visuals = 0;
    float range = 5;
    float APS = 10;
    bool strafe = false;
    bool timedSwing = true;
    bool hotbarOnly = true;

    enum RotateMode {
        None = 0,
        Normal = 1,
        Flick = 2
    };

    enum SwitchMode {
        Single = 0,
        Multi = 1,
        Switch = 2
    };

    int betterSwordSlot = 0;

    Vec3<float> targeting_actor_pos;
    bool rotating = false;
public:
    void onDisable()
    {
        Animations::shouldBlock = false;
    }

    bool findSword() {
        PlayerInventory* playerInventory = Instance::getLocalPlayer()->getSupplies();
        Inventory* inventory = playerInventory->getInventory();
        auto previousSlot = playerInventory->mSelectedSlot;
        int slot = previousSlot;

        int currentSwordValue = 0;

        for (int i = 0; i < (hotbarOnly ? 9 : 36); i++) {
            ItemStack* stack = inventory->getItemStack(i);
            if (stack->mItem != nullptr) {
                int itemDamage = stack->getItem()->getItemTier() + stack->getEnchantValue(EnchantType::Sharpness);
                if (itemDamage > currentSwordValue) {
                    currentSwordValue = itemDamage;
                    betterSwordSlot = i;
                }
            }
        }

        return currentSwordValue != 0;
    }

    void AutoSlotManagement() {
        if (autoSlot == 1 && findSword()) {
            Instance::getLocalPlayer()->getSupplies()->mSelectedSlot = betterSwordSlot;
        }

        if (autoSlot == 2 && findSword()) {
            PacketUtil::spoofSwitch(betterSwordSlot);
        }

        if (autoSlot == 3 && findSword()) {
            Instance::getLocalPlayer()->getSupplies()->mSelectedSlot = betterSwordSlot;
        }
    }

    void rotate(Actor* mTarget)
    {
        if (rotationMode == RotateMode::None) return;

        auto player = Instance::getLocalPlayer();
        if (!player) return;

        targeting_actor_pos = mTarget->getPosition();
        rotating = true;
    }

    void onEvent(BaseTickEvent* event) {
        Player* mPlayer = Instance::getLocalPlayer();
        GameMode* mGameMode = mPlayer->getGameMode();

        if (!mPlayer || !mGameMode)
        {
            return;
        }

        if (!ActorUtil::getActorList(range, false).empty()) {
            Vec3<float> mLocalPos = mPlayer->getPosition();
            Vec3<float> mPlayerPos = ActorUtil::getActorList(range, false)[0]->getPosition();

            Vec2<float> angle = MathUtil::getRotations(mLocalPos, mPlayerPos);

            Animations::shouldBlock = true;

            if (TimeUtil::hasTimeElapsed("kaTimer", 1000 / APS, true)) {
                int mSelectedSlot = mPlayer->getSupplies()->mSelectedSlot;

                AutoSlotManagement();

                if (swing == 0) { mPlayer->swing(); }

                for (auto mActor : ActorUtil::getActorList(range, false)) {
                    if (switchMode == SwitchMode::Single)
                    {
                        mActor = ActorUtil::getActorList(range, false)[0];
                    }
                    else if (switchMode == SwitchMode::Multi)
                    {

                    }
                    else if (switchMode == SwitchMode::Switch)
                    {
                        mActor = ActorUtil::getActorList(range, false)[ActorUtil::getCurrentIndex(range, false)];
                    }

                    if (rotationMode == RotateMode::Normal)
                        rotate(mActor);

                    auto oldActor = mActor;
                    mActor = ActorUtil::getObstructingActor(mPlayer, mActor, range, bypassMode);

                    if (rotationMode == RotateMode::Flick)
                    {
                        rotate(mActor);
                    }

                    mGameMode->attack(*mActor);
                }

                if (autoSlot == 3) {
                    mPlayer->getSupplies()->mSelectedSlot = mSelectedSlot;
                }
            }

            if (strafe) {
                mPlayer->getComponent<ActorRotationComponent>()->mRotation = angle;
            }
        }
        else {
            rotating = false;
            Animations::shouldBlock = false;
        }
    }

    void onEvent(ImRenderEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player || !Instance::isAllowedToUseKeys()) return;

    }

    void onEvent(PacketEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player || !rotating)
        {
            return;
        }

        Vec3<float> mLocalPos = player->getPosition();

		if (event->mPacket->getID() == PacketID::PlayerAuthInput)
		{
			mLocalPos = reinterpret_cast<PlayerAuthInputPacket*>(event->mPacket)->mPosition;
		}

        if (!ActorUtil::getActorList(range, false).empty()) 
        {
            Vec2<float> mAngle = MathUtil::getRotations(mLocalPos, targeting_actor_pos);

            PacketUtil::setRotations(mAngle, event->mPacket);
        }
    }
};