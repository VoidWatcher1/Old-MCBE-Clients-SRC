#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class AntiCheat : public Module
{
public:
    AntiCheat() :
        Module("Anti Cheat", "Misc", "Aerulius Anti Cheat checks for detecting cheaters in your game.")
    {
        addEnum("Mode", "The Anti-Cheat mode to flags and detect cheaters based on shown booleans under.", { "Aerulius" }, &mode);
    }

private:
    enum Mode 
    {
        Aerulius = 0
    };

    int mode = 0;
    float range = 100.f;
public:

};