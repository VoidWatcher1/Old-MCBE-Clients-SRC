#pragma once

class NetSkip : public Module
{
public:
    

    NetSkip() :
        Module("Net Skip", "Misc", "Skips packets acts as a ping spoofer.")
    {
        addEnum("Mode", "The mode of the delay", { "Ticks", "Milliseconds" }, &mode);
        addSlider("Ticks", "Delay to wait before resending packets (ticks).", &ticks, 0.f, 100, SliderType::Int, [this] { return mode == static_cast<int>(Mode::Ticks); });
        addSlider("MS", "Delay to wait before resending packets (ms).", &delayMs, 0.f, 1000, SliderType::Int, [this] { return mode == static_cast<int>(Mode::Milliseconds); });
    }
private:
    enum class Mode {
        Ticks,
        Milliseconds
    };

    int mode = 0;

    float ticks = 12.f;
    float delayMs = 100.f;

    // Tick
    int currentTick = 0;
    int tickDelay = 0;
public:
    void onEvent(RunUpdateCycleEvent* event) 
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        if (mode == static_cast<int>(Mode::Milliseconds))
        {
            Sleep(static_cast<DWORD>(delayMs));
            event->mApplied = true;
            return;
        }

        if (currentTick < ticks)
        {
            currentTick++;
            event->cancel();
            event->mApplied = true;
            return;
        }

        currentTick = 0;
    }

    std::string getModeName() const override 
    {
        if (mode == static_cast<int>(Mode::Milliseconds))
        {
            return std::to_string(static_cast<int>(delayMs)) + "ms";
        }

        return "Ticks";
    }
};