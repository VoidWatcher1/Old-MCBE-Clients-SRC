#pragma once
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <wininet.h>
#include <filesystem>
#include <mutex>

#include "Utils/Network/NetworkUtil.hpp"
#define MINIAUDIO_IMPLEMENTATION 
#include "Libs/miniaudio/miniaudio.h"

class SpotifyFromTemu : public Module {
public:
    SpotifyFromTemu() : Module("Spotify From Temu", "Misc", "Play music and display info") {
        focused = true;
        currentSongIndex = 0;
        stopPlaybackFlag = false;
    }

    void onDisable() override {
        stopPlayback();
        joinThreads();
    }

    void onEvent(KeyboardEvent* event) override {
        if (!focused || event->mState == 1) return;

        int key = event->mKeyCode;

        if (key == VK_RETURN && !searchQuery.empty()) {
            startSearch(searchQuery);
            focused = false;
        }
        else if (key == VK_BACK && !searchQuery.empty()) {
            searchQuery.pop_back();
        }
        else if (key == VK_ESCAPE) {
            focused = false;
        }
        else if (key >= 'A' && key <= 'Z') {
            char ch = (GetKeyState(VK_SHIFT) & 0x8000) ? key : key + 32;
            if (lastKey != key) searchQuery += ch;
        }
        else if (key >= '0' && key <= '9') {
            if (lastKey != key) searchQuery += static_cast<char>(key);
        }
        else if (key == VK_SPACE) {
            searchQuery += ' ';
        }

        lastKey = key;
    }

    void onEvent(ImRenderEvent* event) override {
        auto draw = ImGui::GetBackgroundDrawList();
        float x = 100.f, y = 100.f, width = 400.f, height = 110.f;

        ImRenderUtil::fillRectangle(Vec4<float>(x, y, x + width, y + height), Color(30, 30, 30, 230), 1.0f, 8);

        // Draw search query
        draw->AddText({ x + 10, y + 10 }, IM_COL32_WHITE, searchQuery.c_str());

        // Draw current song title
        std::string currentTitle = "No song playing";
        {
            std::lock_guard<std::mutex> lock(mutexSongs);
            if (currentSongIndex >= 0 && currentSongIndex < (int)songs.size())
                currentTitle = "Now Playing: " + songs[currentSongIndex].name + " - " + songs[currentSongIndex].artist;
        }
        draw->AddText({ x + 10, y + 40 }, IM_COL32(200, 255, 200, 255), currentTitle.c_str());

        // Draw playlist (up to 5 songs)
        std::lock_guard<std::mutex> lock(mutexSongs);
        float offsetY = y + 70.f;
        int displayCount = (int)std::min((size_t)5, songs.size());
        for (int i = 0; i < displayCount; ++i) {
            Color col = (i == currentSongIndex) ? Color(100, 250, 255) : Color(180, 180, 180);
            std::string text = songs[i].name + " - " + songs[i].artist;
            ImRenderUtil::drawText(Vec2<float>(x + 10, offsetY), &text, col, 0.75f, 1.f, true);
            offsetY += 20.f;
        }
    }

private:
    struct Song {
        std::string name;
        std::string artist;
        std::string previewUrl;
        std::string artworkUrl;
    };

    std::string searchQuery;
    int lastKey = -1;
    bool focused = true;

    // Playlist and current song index
    std::vector<Song> songs;
    int currentSongIndex = 0;

    std::mutex mutexSongs;

    ma_decoder* decoder = nullptr;
    ma_device* device = nullptr;
    std::atomic<bool> isPlaying = false;
    std::atomic<bool> stopPlaybackFlag;
    std::thread audioThread;

    static std::atomic<float> masterVolume;

    // MiniAudio callback for streaming audio data
    std::atomic<bool> playbackEnded = false;

    static void dataCallback(ma_device* device, void* output, const void*, ma_uint32 frameCount) {
        auto* dec = (ma_decoder*)device->pUserData;
        ma_uint32 framesRead = ma_decoder_read_pcm_frames(dec, output, frameCount, nullptr);

        // If framesRead < frameCount, we've reached EOF
        if (framesRead < frameCount) {
            SpotifyFromTemu* instance = (SpotifyFromTemu*)device->pUserData; // You may want to pass a pointer to your class here differently
            instance->playbackEnded = true;
        }

        float vol = std::clamp(masterVolume.load(), 0.f, 1.f);
        float* buf = static_cast<float*>(output);
        for (ma_uint32 i = 0; i < framesRead * device->playback.channels; ++i)
            buf[i] *= vol;

        // Zero out remaining samples if framesRead < frameCount to avoid noise
        if (framesRead < frameCount) {
            memset((float*)buf + framesRead * device->playback.channels, 0, (frameCount - framesRead) * device->playback.channels * sizeof(float));
        }
    }

    void stopPlayback() {
        stopPlaybackFlag = true;

        if (device) {
            ma_device_stop(device);
            ma_device_uninit(device);
            delete device;
            device = nullptr;
        }
        if (decoder) {
            ma_decoder_uninit(decoder);
            delete decoder;
            decoder = nullptr;
        }
        isPlaying = false;
    }

    void joinThreads() {
        if (audioThread.joinable()) audioThread.join();
    }

    void startSearch(const std::string& query) {
        stopPlayback();
        joinThreads();

        {
            std::lock_guard<std::mutex> lock(mutexSongs);
            songs.clear();
            currentSongIndex = 0;
        }
        searchQuery = query;

        // Fetch multiple results - limit 10
        static const std::string API_BASE = "https://163api.qijieya.cn";
        std::string url = API_BASE + "/cloudsearch?keywords=" + NetworkUtils::encodeUrl(query);
        std::string json;
        if (!NetworkUtils::httpGet(url, json)) {
            //GI::DisplayClientMessage("%s[Music]%s Search failed - network error", MCTF::RED,
                //MCTF::WHITE);
            return;
        }
        //std::string json = NetworkUtils::downloadText(url);

        //if (json.empty()) return;

        // Simple JSON parsing without external libs (assumes iTunes API format)
        size_t pos = 0;
        while (true) {
            size_t trackPos = json.find("\"trackName\":\"", pos);
            if (trackPos == std::string::npos) break;
            trackPos += 13;

            size_t trackEnd = json.find("\"", trackPos);
            if (trackEnd == std::string::npos) break;
            std::string trackName = json.substr(trackPos, trackEnd - trackPos);

            size_t artistPos = json.find("\"artistName\":\"", trackEnd);
            if (artistPos == std::string::npos) break;
            artistPos += 14;

            size_t artistEnd = json.find("\"", artistPos);
            if (artistEnd == std::string::npos) break;
            std::string artistName = json.substr(artistPos, artistEnd - artistPos);

            size_t previewPos = json.find("\"previewUrl\":\"", artistEnd);
            if (previewPos == std::string::npos) break;
            previewPos += 13;

            size_t previewEnd = json.find("\"", previewPos);
            if (previewEnd == std::string::npos) break;
            std::string previewUrl = json.substr(previewPos, previewEnd - previewPos);

            size_t artworkPos = json.find("\"artworkUrl100\":\"", previewEnd);
            std::string artworkUrl;
            if (artworkPos != std::string::npos) {
                artworkPos += 17;
                size_t artworkEnd = json.find("\"", artworkPos);
                artworkUrl = json.substr(artworkPos, artworkEnd - artworkPos);
            }

            Song s;
            s.name = trackName;
            s.artist = artistName;
            s.previewUrl = previewUrl;
            s.artworkUrl = artworkUrl;

            {
                std::lock_guard<std::mutex> lock(mutexSongs);
                songs.push_back(s);
            }

            pos = artworkPos != std::string::npos ? artworkPos : previewEnd;
        }

        // Play first song automatically if any found
        {
            std::lock_guard<std::mutex> lock(mutexSongs);
            if (!songs.empty()) {
                playAudio(songs[0].previewUrl);
                currentSongIndex = 0;
            }
        }
    }

    void playAudio(const std::string& url) {
        stopPlaybackFlag = false;

        joinThreads(); // Make sure previous audio thread finished

        audioThread = std::thread([this, url]() {
            if (stopPlaybackFlag) return;

            //std::filesystem::path tmpFile = std::filesystem::temp_directory_path() / "preview_audio.mp3";
            std::string pathStr = FileUtil::getClientPath() + "preview_audio.mp3";
            std::filesystem::path tmpFile(pathStr);

            HINTERNET hSession = InternetOpenA("Mozilla", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
            if (!hSession) return;
            HINTERNET hUrl = InternetOpenUrlA(hSession, url.c_str(), NULL, 0, INTERNET_FLAG_RELOAD, 0);
            if (!hUrl) {
                InternetCloseHandle(hSession);
                return;
            }
            HANDLE hFile = CreateFileA(tmpFile.string().c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY, NULL);
            if (hFile == INVALID_HANDLE_VALUE) {
                InternetCloseHandle(hUrl);
                InternetCloseHandle(hSession);
                return;
            }

            char buf[8192];
            DWORD read = 0;
            while (!stopPlaybackFlag && InternetReadFile(hUrl, buf, sizeof(buf), &read) && read) {
                DWORD written = 0;
                WriteFile(hFile, buf, read, &written, NULL);
            }

            CloseHandle(hFile);
            InternetCloseHandle(hUrl);
            InternetCloseHandle(hSession);

            if (stopPlaybackFlag) return;

            decoder = new ma_decoder;
            if (ma_decoder_init_file(tmpFile.string().c_str(), NULL, decoder) != MA_SUCCESS) {
                delete decoder;
                decoder = nullptr;
                return;
            }

            ma_device_config config = ma_device_config_init(ma_device_type_playback);
            config.playback.format = decoder->outputFormat;
            config.playback.channels = decoder->outputChannels;
            config.sampleRate = decoder->outputSampleRate;
            config.dataCallback = dataCallback;
            config.pUserData = decoder;

            device = new ma_device;
            if (ma_device_init(NULL, &config, device) != MA_SUCCESS) {
                ma_decoder_uninit(decoder);
                delete decoder;
                decoder = nullptr;
                device = nullptr;
                return;
            }

            masterVolume.store(1.0f);

            if (ma_device_start(device) != MA_SUCCESS) {
                ma_device_uninit(device);
                ma_decoder_uninit(decoder);
                delete decoder;
                ma_device_uninit(device);
                delete device;
                decoder = nullptr;
                device = nullptr;
                return;
            }

            playbackEnded.store(false);
            isPlaying = true;

            // Wait until playback ends or stop requested
            while (!stopPlaybackFlag && !playbackEnded.load()) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }

            stopPlayback();

            if (stopPlaybackFlag) return;

            // Play next song if exists
            {
                std::lock_guard<std::mutex> lock(mutexSongs);
                currentSongIndex++;
                if (currentSongIndex < (int)songs.size()) {
                    playAudio(songs[currentSongIndex].previewUrl);
                }
            }
            });
    }
};

inline std::atomic<float> SpotifyFromTemu::masterVolume = 1.0f;
