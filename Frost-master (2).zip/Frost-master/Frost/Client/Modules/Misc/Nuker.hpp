#pragma once

class Nuker : public Module
{
public:
    Nuker() :
        Module("Nuker", "Misc", "Automatically breaks blocks.")
    {
        addEnum("Mode", "The game type", { "Normal" }, &mode);
        addBool("Zeqa", "zeqa deez nuts", &zeqa);
        addBool("Ignore Y Level", "Ignores mining underground.", &ignore_y);
        addSlider("Range", "lol", &range, 1, 10, SliderType::DoubleFloat);
    }

private:
    int mode = 0;

    bool zeqa = false;
    bool ignore_y = false;

    float range = 7.f;
public:
    void onEvent(BaseTickEvent* baseTickEvent)
    {
        auto player = Instance::getLocalPlayer();
        auto source = Instance::getBlockSource();
        if (!player || !source) return;

        auto supplies = player->getSupplies();

        Vec3<int> player_pos = player->getAABBShapeComponent()->mMin.toInt();

        for (int x = -range; x <= range; x++)
        {
            for (int z = -range; z <= range; z++) 
            {
                for (int y = -range; y <= range; y++) 
                {
                    Vec3<int> pos = Vec3<int>(x, y, z);
                    Vec3<int> block_pos = Vec3<int>(player_pos.x + pos.x, player_pos.y + pos.y, player_pos.z + pos.z);

                    if (ignore_y)
                    {
                        block_pos.y = player_pos.y;
                    }

                    if (zeqa)
                    {
                        player->getComponent<ActorGameTypeComponent>()->mGameType = GameType::Creative;
                        player->getGameMode()->destroyBlock(block_pos, BlockUtil::getExposedBlockFace(block_pos));
                        player->getComponent<ActorGameTypeComponent>()->mGameType = GameType::Survival;
                    }
                    else 
                    {
                        player->getGameMode()->destroyBlock(block_pos, BlockUtil::getExposedBlockFace(block_pos));
                    }
                }
            }
        }
    }

    void onDisable()
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        if (zeqa)
        {
            player->getComponent<ActorGameTypeComponent>()->mGameType = GameType::Survival;
        }
    }
};