#pragma once

class ForceGM : public Module
{
public:
    ForceGM() :
        Module("Force Gamemode", "Misc", "Sprint automatically.")
    {
        addEnum("GameType", "The game type", { "Survival", "Creative" }, &gamemode);
    }

private:
    int gamemode = 0;

public:
    void onEvent(BaseTickEvent* baseTickEvent)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        if (gamemode == 1)
        {
            player->getComponent<ActorGameTypeComponent>()->mGameType = GameType::Creative;
        }
        else 
        {
            player->getComponent<ActorGameTypeComponent>()->mGameType = GameType::Survival;
        }
    }
};