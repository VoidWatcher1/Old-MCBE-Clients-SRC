#pragma once

class Regen : public Module
{
public:
    Regen() :
        Module("Regen", "Misc", "Automatically heals you.")
    {
    }
};