#pragma once

class NoPacket : public Module
{
public:
    NoPacket() :
        Module("No Packet", "Misc", "Stops sending all outgoing packets.")
    {}

    void onEvent(PacketEvent* event)
    {
        event->cancel();
    }
};