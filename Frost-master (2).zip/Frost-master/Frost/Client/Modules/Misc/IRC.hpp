#pragma once

#include "Utils/IRC/IRCUtil.hpp"

class IRC : public Module {
public:
	IRC() : 
		Module("IRC", "Misc", "Internet Relay Chat communicate with others from the client.") 
	{

	}

	void onEnable() 
	{
		auto player = Instance::getLocalPlayer();
		if (!player) return;

		auto playerName = player->getNametag();
		auto playernamec = playerName->c_str();

		ChatUtil::sendIRCMessage("Attempting to join IRC Channel...");
		ChatUtil::sendIRCMessage("To respond back to the irc add '.#' to your message in chat!");

		knownUsers.clear();
		auto currentusers = IRCUtil::getIRCUsers();
		for (const auto& user : currentusers) {
			knownUsers.insert(user);
		}

		auto messages = IRCUtil::fetchIRCMessages();
		for (const auto& msg : messages) {
			ChatUtil::sendIRCMessage(msg);
		}
	}

	void onEvent(BaseTickEvent* event) 
	{
		if (tickCounter++ >= 100) 
		{
			tickCounter = 0;
			auto messages = IRCUtil::fetchIRCMessages();
			for (auto& msg : messages) {
				ChatUtil::sendIRCMessage(msg);
			}

			auto currentUsers = IRCUtil::getIRCUsers();
			for (const auto& user : currentUsers) {
				if (knownUsers.find(user) == knownUsers.end()) {
					knownUsers.insert(user);
					notifyOnJoinedUsers(user);
				}
			}
			for (auto it = knownUsers.begin(); it != knownUsers.end(); ) {
				if (std::find(currentUsers.begin(), currentUsers.end(), *it) == currentUsers.end()) {
					it = knownUsers.erase(it);
					// notify on leave user
				}
				else {
					++it;
				}
			}
		}
	}

private:
	int tickCounter = 0;
	std::set<std::string> knownUsers;

	void notifyOnJoinedUsers(const std::string& user) 
	{
		std::string joinMsg = user + " has joined the IRC!";
		ChatUtil::sendIRCMessage(joinMsg);
	}
};