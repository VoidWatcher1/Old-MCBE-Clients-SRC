#pragma once

class Disabler : public Module
{
public:
    Disabler() :
        Module("Disabler", "Misc", "Disables Anti Cheat checks by manipulating packets and immediate sending.")
    {
        addEnum("Mode", "The Anti-Cheat mode to disable flags based on shown booleans under.", { "Flareon", "Lifeboat" }, &mode);
    }

private:
    int mode = 0;

    enum class Mode {
        Flareon = 0,
        Lifeboat = 1
    };
public:

    void onEvent(BaseTickEvent* baseTick)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        switch (mode)
        {
        case 0: // Flareon
            break;
        case 1: // Lifeboat
            {
                
            }
            break;
        }
    }

    void onEvent(PacketEvent* packetEvent)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        Packet* pkt = packetEvent->mPacket;
        
        if (mode == static_cast<int>(Mode::Flareon))
        {
            if (pkt->getID() == PacketID::PlayerAuthInput)
            {
                auto paip = pkt->tryGetPacketAs<PlayerAuthInputPacket>();

                static bool has_auth_input_action_started_sprinting = false;

                const bool has_started_sprinting = paip->hasInputData(AuthInputAction::START_SPRINTING);
                const bool has_stopped_sprinting  = paip->hasInputData(AuthInputAction::STOP_SPRINTING);

                // Update sprinting state
                if (has_started_sprinting)
                {
                    has_auth_input_action_started_sprinting = true;
                }
                else if (has_stopped_sprinting)
                {
                    has_auth_input_action_started_sprinting = false;
                }
                
                auto movement_vector = paip->mMove;
                auto pos_delta_x = paip->mPosDelta.x;
                auto pos_delta_z = paip->mPosDelta.z;

                auto yaw = paip->mRotation.y;
                yaw = -yaw;

                if (movement_vector.x == 0 && movement_vector.y == 0 && pos_delta_x == 0 && pos_delta_z == 0) return;

                float movement_vector_yaw = atan2(movement_vector.x, movement_vector.y);
                movement_vector_yaw = glm::degrees(movement_vector_yaw);

                float movement_yaw = atan2(pos_delta_x, pos_delta_z);
                float movement_yaw_degrees = movement_yaw * (180.0f / PI);

                float yaw_difference = movement_yaw_degrees - yaw;
                
                auto new_movement_vector = Vec2<float>(sin(glm::radians(yaw_difference)), cos(glm::radians(yaw_difference)));

                if (abs(new_movement_vector.x) < 0.001) new_movement_vector.x = 0;
                if (abs(new_movement_vector.y) < 0.001) new_movement_vector.y = 0;
                if (new_movement_vector.x == 0 && new_movement_vector.y == 0) new_movement_vector = Vec2<float>(0, 0);
                
                // Directional movement flags
                const bool moving_forward  = new_movement_vector.y > 0;
                const bool moving_backward = new_movement_vector.y < 0;
                const bool moving_left     = new_movement_vector.x > 0;
                const bool moving_right    = new_movement_vector.x < 0;

                bool sprint_override_handled = false;

                if (!moving_forward && (moving_backward || moving_left || moving_right) && has_auth_input_action_started_sprinting)
                {
                    static bool sprint_toggle_state = false;

                    const bool isOnGround = player->hasComponent<OnGroundFlagComponent>() || 
                                            player->hasComponent<WasOnGroundFlagComponent>();

                    if (isOnGround && sprint_toggle_state)
                    {
                        paip->mInputData |= AuthInputAction::SPRINT_DOWN | 
                                            AuthInputAction::SPRINTING | 
                                            AuthInputAction::START_SPRINTING;

                        paip->mInputData &= ~AuthInputAction::STOP_SPRINTING;
                        sprint_override_handled = true;
                    }
                    else
                    {
                        paip->mInputData |= AuthInputAction::STOP_SPRINTING;

                        paip->mInputData &= ~AuthInputAction::SPRINT_DOWN;
                        paip->mInputData &= ~AuthInputAction::SPRINTING;
                        paip->mInputData &= ~AuthInputAction::START_SPRINTING;
                    }

                    sprint_toggle_state = !sprint_toggle_state;
                }
                else if (moving_forward && has_auth_input_action_started_sprinting)
                {
                    paip->mInputData |= AuthInputAction::SPRINT_DOWN | 
                        AuthInputAction::SPRINTING | 
                        AuthInputAction::START_SPRINTING;

                    paip->mInputData &= ~AuthInputAction::STOP_SPRINTING;
                }

                // Handle direction inputs and movement vector
                if (!sprint_override_handled) {
                    paip->mInputData &= ~(AuthInputAction::UP | 
                                          AuthInputAction::DOWN | 
                                          AuthInputAction::LEFT | 
                                          AuthInputAction::RIGHT);

                    if (moving_forward)  paip->mInputData |= AuthInputAction::UP;
                    if (moving_backward) paip->mInputData |= AuthInputAction::DOWN;
                    if (moving_left)     paip->mInputData |= AuthInputAction::LEFT;
                    if (moving_right)    paip->mInputData |= AuthInputAction::RIGHT;

                    paip->mMove = new_movement_vector;
                    paip->mVehicleRotation = new_movement_vector; // this is mojang's logic - preserves alignment
                }
            }
        }

        if (mode == static_cast<int>(Mode::Lifeboat))
        {
            if (pkt->getID() == PacketID::MovePlayer)
            {
                auto mpp = pkt->tryGetPacketAs<MovePlayerPacket>();
                mpp->mOnGround = true;
            }
        }
    }
};