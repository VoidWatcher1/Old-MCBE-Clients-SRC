#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class SessionInfo : public Module
{
private:
	float mBlurStrenght = 5;

	class SessionInfoStatus
	{
	public:
		int min = 0;
		int sec = 0;
		int hours = 0;

		int kills_count = 0;
	};
	SessionInfoStatus session_info_status;

	Vec2<float> session_info_pos = Vec2<float>(10, 250);
public:
	SessionInfo() : Module("Session Info", "Visual", "Display the info")
	{
		addSlider("mPos.x", "You should not be able to see this", &session_info_pos.x, 0, 0, SliderType::Int, [this] { return false; });
		addSlider("mPos.y", "You should not be able to see this", &session_info_pos.y, 0, 0, SliderType::Int, [this] { return false; });
		mCallEventsWhenDisabled = true;
	}

	void calculateTime() {
		if (TimeUtil::hasTimeElapsed("SessionInfoPlayTime", 1000, true)) {
			session_info_status.sec += 1;
		}

		if (session_info_status.sec == 60) {
			session_info_status.min += 1;
			session_info_status.sec = 0;
		}

		if (session_info_status.min == 60) {
			session_info_status.hours += 1;
			session_info_status.min = 0;
		}
	}

	void onEvent(ImRenderEvent* event)
	{
		calculateTime();

		static EasingUtil in_ease;

		bool should_render = this->isEnabled() && !MainClient::getModuleByType<ClickGUI>()->isEnabled() && Instance::isAllowedToUseKeys();

		if (MainClient::getModuleByType<HudEditor>()->isEnabled())
			should_render = true;

		should_render ? in_ease.increment(ImRenderUtil::getDeltaTime() * 15.5f / 10)
			: in_ease.decrement(ImRenderUtil::getDeltaTime() * 2 * 15.5f / 10);

		float in_scale = in_ease.easeOutExpo();

		if (in_ease.isMax())
			in_scale = 1;

		ImScaleUtil::ImScaleStart();

		std::string mTitle = "Session Info";
		std::string mPlayTime = "Play time";
		std::string mKills = "Kills";
		std::string mPlayTimeStat = Util::combine(session_info_status.hours, "h ", session_info_status.min, "m ", session_info_status.sec, "s");
		std::string mKillsStat = Util::combine(session_info_status.kills_count);

		float mTitleLenght = ImRenderUtil::getTextWidth(&mTitle, 1.2);
		float mPlayTimeStatLenght = ImRenderUtil::getTextWidth(&mPlayTimeStat, 1.2);
		float mKillsStatLenght = ImRenderUtil::getTextWidth(&mKillsStat, 1.2);

		Vec2<float> mPos = session_info_pos;

		Vec4<float> mRectPos = Vec4<float>(mPos.x, mPos.y, mPos.x + 250, mPos.y + 100);
		Vec4<float> mBarPos = Vec4<float>(mRectPos.x + 15, mRectPos.y + 37, mRectPos.z - 15, mRectPos.y + 40);

		float mTitleMiddle = (mPos.x + 125) - (mTitleLenght / 2);

		Vec2<float> mTitlePos = Vec2<float>(mTitleMiddle, mRectPos.y + 10);

		Vec2<float> mPlayTimePos = Vec2<float>(mRectPos.x + 20, mRectPos.y + 45);
		Vec2<float> mPlayTimeStatPos = Vec2<float>((mRectPos.z - 20) - mPlayTimeStatLenght, mRectPos.y + 45);

		Vec2<float> mKillsPos = Vec2<float>(mRectPos.x + 20, mRectPos.y + 65);
		Vec2<float> mKillsStatPos = Vec2<float>((mRectPos.z - 20) - mKillsStatLenght, mRectPos.y + 65);

		Color mColor = ColorUtil::getClientColor(1, 2);
		Color mSecondaryColor = ColorUtil::getClientColor(400, 2);

		ImRenderUtil::fillRectangle<float>(mRectPos, Color(0, 0, 0), 0.22 * in_scale, 17.f);
		ImRenderUtil::fillShadowRectangle(mRectPos, Color(0, 0, 0), 0.22f * in_scale, 150, 0, 17.f);

		if (in_scale == 1.f)
		{
			//ImRenderUtil::addBlur<float>(mRectPos, mBlurStrenght, 17.f);
		}

		ImRenderUtil::fillGradientRectangle(mBarPos, mColor, mSecondaryColor, 0.9 * in_scale, 0.9 * in_scale, 20.f);
		//ImRenderUtil::fillShadowRectangle(mBarPos, mColor, 0.8f * in_scale, 80, 0, 27.f);

		ImRenderUtil::drawText(mTitlePos, &mTitle, Color(255, 255, 255), 1.2f, in_scale, false);
		ImRenderUtil::drawText(mPlayTimePos, &mPlayTime, Color(255, 255, 255), 1.2f, in_scale, false);
		ImRenderUtil::drawText(mPlayTimeStatPos, &mPlayTimeStat, Color(255, 255, 255), 1.2f, in_scale, false);
		ImRenderUtil::drawText(mKillsPos, &mKills, Color(255, 255, 255), 1.2f, in_scale, false);
		ImRenderUtil::drawText(mKillsStatPos, &mKillsStat, Color(255, 255, 255), 1.2f, in_scale, false);

		if (ImRenderUtil::isMouseOver(mRectPos) && MainClient::getModuleByType<HudEditor>()->isEnabled()) 
		{
			Vec2<float> mMousePos = ImRenderUtil::getMousePos();

			static Vec2<float> mDifference = Vec2<float>(mMousePos.x - session_info_pos.x, mMousePos.y - session_info_pos.y);

			if (Util::mLeftClick) 
			{
				session_info_pos.x = mMousePos.x - mDifference.x;
				session_info_pos.y = mMousePos.y - mDifference.y;
			}
			else 
			{
				mDifference = Vec2<float>(mMousePos.x - session_info_pos.x, mMousePos.y - session_info_pos.y);
			}
		}

		ImScaleUtil::ImScaleEnd(in_scale, in_scale);
	}
};