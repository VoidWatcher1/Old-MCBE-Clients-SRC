#pragma once

class ArrayList : public Module {
public:
    ArrayList() 
        :
        Module("Array List", "Visual", "Displays active modules on-screen.", Keys::NONE, true) 
    {
        addEnum("Style", "Choose the visual style of the ArrayList.", { "Frost" }, &style);
        addEnum("Sort", "Choose the sorting mode.", { "Length", "Alphabetical"}, &sortMode);
        addEnum("Animation", "Choose how modules animate in and out.", { "Lerp", "Expo", "Bounce", "Elastic", "Smooth" }, &animationMode);
        addEnum("Text Zoom Type", "Type of animation when text zooms.", { "Lerp", "Bounce" }, &textZoomMode);
        addSlider("Offset", "Vertical and horizontal offset from the top of the screen.", &offset, 0, 50);
        addSlider("Text Size", "Adjust the size of the module text.", &textSize, 0.8f, 1.5f, SliderType::DoubleFloat);
        addBool("Text Shadow", "Render shadow behind text.", &textShadow);
        addBool("Fill Shadow", "Render a filled shadow rectangle behind modules.", &shadowFill);
        addSlider("Shadow Strength", "Controls the intensity of shadows.", &shadowStrength, 0, 200);
        addSlider("Shadow Opacity", "Transparency level of the shadow.", &shadowOpacity, 0, 100);
        addSlider("Bar Opacity", "Transparency of the colored bar.", &barOpacity, 0, 100);
        addSlider("Opacity", "Controls the overall opacity of module background.", &backgroundOpacity, 0, 100);
        addBool("Display Modes", "Show active modes next to module names.", &displayModeText);
    }

private:
    int style = 0;
    int animationMode = 1;
    int textZoomMode = 0;
    float textSize = 1.2f;
    float backgroundOpacity = 50;
    float offset = 8;
    bool textShadow = true;
    bool shadowFill = true;
    float shadowStrength = 100;
    float shadowOpacity = 50;
    float barOpacity = 50;
    bool displayModeText = true;
    int sortMode = 0;

    enum Style { Frost = 0 };
    enum SortType { Length = 0, Alphabetical = 1 };
    enum AnimationMode { Lerp = 0, Expo = 1, Bounce = 2, Elastic = 3, Smooth = 4 };
    enum TextZoomMode { ZoomLerp = 0, ZoomBounce = 1 };

public:
    void onEvent(ImRenderEvent* event) 
    {
        if (!ImGui::GetBackgroundDrawList()) return;

        std::vector<std::shared_ptr<Module>> activeModules;

        for (const auto& mod : MainClient::mModules) {
            if ((!mod->isEnabled() && mod->mAnimationPercentage <= 0.01f) || !mod->isVisible()) continue;
            activeModules.push_back(mod);
        }

        sortModules(activeModules);

        const float baseTextHeight = ImRenderUtil::getTextHeight(textSize) + 2.5f;
        const float padding = 1.5f * textSize;
        float yPos = -1 + offset;

        float bgOpacity = backgroundOpacity / 100.0f;
        float shOpacity = shadowOpacity / 100.0f;
        float bOpacity = barOpacity / 100.0f;

        std::vector<std::tuple<Vec4<float>, std::string, std::string, Vec2<float>, float, float, float, float>> renderList;

        int index = 0;
        for (auto& mod : activeModules) {
            float target = mod->isEnabled() ? 1.f : 0.f;
            mod->mAnimationPercentage = MathUtil::animate(target, mod->mAnimationPercentage, ImRenderUtil::getDeltaTime() * 10);
            mod->mAnimationPercentage = MathUtil::clamp(mod->mAnimationPercentage, 0.f, 1.f);

            float ease = getEase(mod->mAnimationPercentage, animationMode);

            if (animationMode == Smooth) {
                float target = mod->isEnabled() ? 1.f : 0.f;
                mod->mSmoothAnimationPercentage = MathUtil::animate(target, mod->mSmoothAnimationPercentage, ImRenderUtil::getDeltaTime() * 3); // Slower than 10
                mod->mSmoothAnimationPercentage = MathUtil::clamp(mod->mSmoothAnimationPercentage, 0.f, 1.f);
            }

            float textAnim = (animationMode == Smooth) ? getTextZoom(mod->mSmoothAnimationPercentage) : ease;

            std::string name = mod->getName();
            std::string mode = mod->getModeName() == "" ? "" : " " + mod->getModeName();

            float nameWidth = ImRenderUtil::getTextWidth(&name, textSize);
            float modeWidth = displayModeText ? ImRenderUtil::getTextWidth(&mode, textSize) : 0.f;

            float posX = ImGui::GetIO().DisplaySize.x - nameWidth - modeWidth - padding - 3.f - offset;
            mod->mArrayListPos.x = MathUtil::lerp(ImGui::GetIO().DisplaySize.x + 5.f, posX, ease);
            mod->mArrayListPos.y = yPos;

            Color modColor = ColorUtil::getClientColor(index * 40, 1.5f);

            Vec4<float> box(mod->mArrayListPos.x - padding - 2.f, yPos, mod->mArrayListPos.x + nameWidth + modeWidth + 3.f, yPos + baseTextHeight);
            Vec4<float> bar(box.z, box.y, box.z + 3.f, box.w);

            Color color = ColorUtil::getClientColor(index * 40, 1.5f);

            ImRenderUtil::fillShadowRectangle(box, color, shOpacity * ease, shadowStrength, shadowFill ? ImDrawFlags_None : ImDrawFlags_ShadowCutOutShapeBackground, 0);

            //ImRenderUtil::addBlur(box);

            ImRenderUtil::fillRectangle(bar, color, ease, 0);
            ImRenderUtil::fillShadowRectangle(bar, color, bOpacity * ease, shadowStrength, shadowFill ? ImDrawFlags_None : ImDrawFlags_ShadowCutOutShapeBackground, 0);

            renderList.push_back({ box, name, mode, mod->mArrayListPos, nameWidth, modeWidth, ease, textAnim });

            yPos += baseTextHeight * ease;
            ++index;
        }

        index = 0;
        for (const auto& item : renderList) {
            auto [box, name, mode, pos, nameW, modeW, anim, textAnim] = item;

            Color color = ColorUtil::getClientColor(index * 40, 1.5f);
            
            ImRenderUtil::fillRectangle(box, Color(0, 0, 0), bgOpacity * anim, 0);

            //ImRenderUtil::fillShadowRectangle(box, Color(0, 0, 0), shOpacity * anim, shadowStrength, shadowFill ? ImDrawFlags_None : ImDrawFlags_ShadowCutOutShapeBackground, 0);

            float scale = MathUtil::lerp(0.8f, textSize, textAnim);

            ImRenderUtil::drawText(pos, &name, color, scale, anim, textShadow);

            if (displayModeText)
                ImRenderUtil::drawText(Vec2<float>(pos.x + nameW, pos.y), &mode, Color(170, 170, 170), scale, anim, textShadow);

            ++index;
        }
    }

private:
    void sortModules(std::vector<std::shared_ptr<Module>>& mods) {
        if (sortMode == static_cast<int>(SortType::Length)) {
            std::sort(mods.begin(), mods.end(), [](const auto& a, const auto& b) {
                std::string mAStr = a->getName() + a->getModeName();
                std::string mBStr = b->getName() + b->getModeName();
                return ImRenderUtil::getTextWidth(&mAStr, 1.f) >
                    ImRenderUtil::getTextWidth(&mBStr, 1.f);
                });
        }
        else if (sortMode == static_cast<int>(SortType::Alphabetical)) {
            std::sort(mods.begin(), mods.end(), [](const auto& a, const auto& b) {
                return (a->getName() + a->getModeName()) < (b->getName() + b->getModeName());
                });
        }
    }

    inline float getEase(float x, int mode) {
        switch (mode) {
        case Lerp: return x;
        case Expo:
            return x == 0 ? 0 : x == 1 ? 1 : x < 0.5f ? pow(2, 20 * x - 10) / 2 : (2 - pow(2, -20 * x + 10)) / 2;
        case Bounce:
            return x < 0.5f ? 8 * pow(2, 8 * (x - 1)) * fabs(sin(x * PI * 7)) : 1 - 8 * pow(2, -8 * x) * fabs(sin(x * PI * 7));
        case Elastic: {
            if (x < 0.45f) return 8 * x * x * x * x * sin(x * PI * 9);
            if (x < 0.55f) return 0.5f + 0.75f * sin(x * PI * 4);
            float t = x - 1;
            return 1 - 8 * t * t * t * t * sin(x * PI * 9);
        }
        case Smooth:
            return x; // Use linear for positioning, handled separately for zoom
        default: return x;
        }
    }

    inline float getTextZoom(float x) {
        switch (textZoomMode) {
        case ZoomBounce:
            return x < 0.5f ? 8 * pow(2, 8 * (x - 1)) * fabs(sin(x * PI * 7)) : 1 - 8 * pow(2, -8 * x) * fabs(sin(x * PI * 7));
        case ZoomLerp:
        default:
            return x;
        }
    }
};
