#pragma once
#include <vector>
#include <regex>

class TargetHUD : public Module {
public:
	TargetHUD() : Module("TargetHUD", "Visual", "Display Target")
	{
		addBool("Track", "Changes the targethud position to the targets", &track_pos);
		addBool("Allow HudEditor", "Allows hud editor to edit the pos", &allow_hud_editor);

		addSlider("mPos.x", "You should not be able to see this", &targetinfo_pos.x, 0, 0, SliderType::Int, [this] { return false; });
		addSlider("mPos.y", "You should not be able to see this", &targetinfo_pos.y, 0, 0, SliderType::Int, [this] { return false; });
	}

private:
	bool track_pos = false;
	bool allow_hud_editor = false;
	float blur_strength = 5;

	struct ActorInfo {
		std::string nametag = "minecraft:player";
		Vec3<float> render_pos = Vec3<float>(0, 0, 0);
		float health = 20;
		float max_health = 20;
		float absorption = 0;
		int hurt_time = 0;
		Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> skin_texture;
	};

	std::map<Actor*, ActorInfo> actor_info;

	static inline Actor* target_actor;

	ActorInfo* getTargetInfo() {
		if (!actor_info.empty() && target_actor != nullptr) {
			auto it = actor_info.find(target_actor);
			if (it != actor_info.end()) return &it->second;
		}
		return nullptr;
	}

	Vec2<float> targetinfo_pos = Vec2<float>(0, 0);
public:
	// Skin 
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> getActorSkinTex(Actor* actor) {
		if (actor) {
			Player* player = static_cast<Player*>(actor);
			auto skin = player->getSkin();

			if (skin) {
				// Calculate head dimensions and offsets based on skin width
				int headSize = skin->mSkinImpl->mObject.getSkinWidth() / 8; // 64x64 -> 8, 128x128 -> 16
				int headOffsetX = skin->mSkinImpl->mObject.getSkinWidth() / 8; // Offset starts at 1/8th of the skin width
				int headOffsetY = skin->mSkinImpl->mObject.getSkinHeight() / 8; // Offset starts at 1/8th of the skin height

				// Create a new buffer for the head portion
				std::vector<uint8_t> headData(headSize * headSize * 4); // Assuming 4 bytes per pixel (RGBA)

				// Copy the head part from skinData
				for (int y = 0; y < headSize; y++) {
					for (int x = 0; x < headSize; x++) {
						int srcIndex = ((y + headOffsetY) * skin->mSkinImpl->mObject.getSkinWidth() + (x + headOffsetX)) * 4;
						int dstIndex = (y * headSize + x) * 4;
						std::copy_n(skin->mSkinImpl->mObject.getSkinData() + srcIndex, 4, headData.data() + dstIndex);
					}
				}

				int scalingFactor = 8;
				std::vector<uint8_t> scaledHeadData(headSize * scalingFactor * headSize * scalingFactor * 4);

				for (int y = 0; y < headSize * scalingFactor; y++) {
					for (int x = 0; x < headSize * scalingFactor; x++) {
						int srcX = x / scalingFactor;
						int srcY = y / scalingFactor;
						int srcIndex = (srcY * headSize + srcX) * 4;
						int dstIndex = (y * headSize * scalingFactor + x) * 4;
						std::copy_n(headData.data() + srcIndex, 4, scaledHeadData.data() + dstIndex);
					}
				}

				headSize *= scalingFactor;

				headData = std::move(scaledHeadData);
				ID3D11ShaderResourceView* texture = nullptr;
				CreateTextureFromData(headData.data(), headSize, headSize, &texture);
				return texture;
			}
		}
	}

	void onEvent(BaseTickEvent* event) {
		auto player = Instance::get<ClientInstance>()->getLocalPlayer();
		if (player == nullptr) return;

		actor_info.clear();

		for (auto actors : ActorUtil::getActorList(7.f, false))
		{
			target_actor = &actors[0];

			auto nametag = actors->getNametag();
			auto render_pos = actors->getRenderPosition();
			auto health = actors->getHealth();
			auto max_health = actors->getMaxHealth();
			auto absorption = actors->getAbsorption();
			auto hurt_time = actors->getComponent<MobHurtTimeComponent>()->mHurtTime;

			actor_info[actors] = ActorInfo{
				.nametag = nametag ? *nametag : "minecraft:player",
				.render_pos = render_pos,
				.health = health,
				.max_health = max_health,
				.absorption = absorption,
				.hurt_time = hurt_time
			};
		}
	};

	void onEvent(ImRenderEvent* event) {
		auto player = Instance::getLocalPlayer();

		static EasingUtil zoom_ease;

		static float distance = 0.f;

		if (player != nullptr && target_actor != nullptr && player && target_actor)
		{
			auto player_state_component = player->getStateVectorComponent();
			auto target_state_component = target_actor->getStateVectorComponent();

			if (player_state_component && target_state_component)
			{
				distance = player->getPosition().distance(target_actor->getPosition());
			}
		}

		bool should_render = player && this->isEnabled() && !MainClient::getModuleByType<ClickGUI>()->isEnabled() && Instance::isAllowedToUseKeys() && (distance <= 7.f);

		if (MainClient::getModuleByType<HudEditor>()->isEnabled())
			should_render = true;

		should_render ? zoom_ease.increment(ImRenderUtil::getDeltaTime() * 15.5f / 10)
			: zoom_ease.decrement(ImRenderUtil::getDeltaTime() * 2 * 15.5f / 10);

		float scale = zoom_ease.easeOutExpo();

		if (zoom_ease.isMax())
			scale = 1;

		ImScaleUtil::ImScaleStart();

		Vec2<float> targethud_pos = Vec2<float>(ImRenderUtil::getScreenSize().x / 2 + 10, ImRenderUtil::getScreenSize().y / 2 + 10);

		if (allow_hud_editor)
		{
			targethud_pos = targetinfo_pos;
		}

		static std::string target_name = "minecraft:player";
		static Vec3<float> render_pos = Vec3<float>(0, 0, 0);
		static float target_health = 20.f;
		static float max_target_health = 20.f;
		static float target_absorption = 0.f;
		static int hurt_time = 0;

		static Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> skin_texture;

		if (target_actor != nullptr && Instance::isAllowedToUseKeys() && player && !MainClient::getModuleByType<ClickGUI>()->isEnabled() && (distance <= 7.f))
		{
			if (auto* info = getTargetInfo()) {
				target_name = info->nametag;
				render_pos = info->render_pos;
				target_health = info->health;
				max_target_health = info->max_health;
				target_absorption = info->absorption;
				hurt_time = info->hurt_time;
				//skin_texture = info->skin_texture;
				skin_texture = getActorSkinTex(target_actor);
			}
		}

		target_name = Util::sanitize(target_name);
		target_name = target_name.substr(0, target_name.find('\n'));

		if (track_pos) 
		{
			Vec2<float> output;
			if (!Instance::get<ClientInstance>()->WorldToScreen(render_pos, output, Frame::mFov, Frame::mOrigin, Frame::mMatrix))
				return;

			targethud_pos.x = output.x;
			targethud_pos.y = output.y;
		}

		auto rect = Vec4<float>(targethud_pos.x, targethud_pos.y, targethud_pos.x + 250, targethud_pos.y + 80);

		static auto damage_animation = hurt_time * 1.35; // The hurttime for the head effect
		damage_animation = MathUtil::animate(hurt_time * 1.35, damage_animation, ImRenderUtil::getDeltaTime() * 20.f);

		auto skin_texture_pos = Vec4<float>(rect.x + 8, rect.y + 12, rect.x + 65, rect.y + 69);

		skin_texture_pos.x += damage_animation;
		skin_texture_pos.y += damage_animation;
		skin_texture_pos.z -= damage_animation;
		skin_texture_pos.w -= damage_animation;

		auto skin_texture_color = Color(255, 255, 255);

		if (hurt_time >= 1 && hurt_time < 11)
		{
			//skin_texture_color.lerp(Color(255, 114, 118), ((damage_animation / 1.35f) / 10.f));
			skin_texture_color = Color(255, 114, 118);
		}

		auto text_pos = Vec2<float>(targethud_pos.x + 75, targethud_pos.y + 18.5f);

		ImRenderUtil::fillRectangle<float>(rect, Color(0, 0, 0), 0.25f, 20.f);

		// The target name text
		ImRenderUtil::drawText(text_pos, &target_name, ColorUtil::getClientColor(1, 1.5f), 1.f, 1.f, false);

		auto target_health_as_percentage = target_health / max_target_health;
		static auto health_ease = target_health_as_percentage;
		health_ease = MathUtil::animate(target_health_as_percentage, health_ease, ImRenderUtil::getDeltaTime() * 15.f);

		auto health_bar_length = 165.f;

		auto target_health_rect_start = Vec2<float>(rect.x + 75, rect.y + 43);
		auto target_health_rect_end = Vec2<float>(target_health_rect_start.x + (health_bar_length * health_ease), target_health_rect_start.y + 15);

		auto full_health_bar_rect = Vec4<float>(target_health_rect_start.x, target_health_rect_start.y, target_health_rect_start.x + health_bar_length, target_health_rect_start.y + 12.f);
		auto health_bar_rect = Vec4<float>(target_health_rect_start.x, target_health_rect_start.y, target_health_rect_end.x, target_health_rect_end.y);

		ImRenderUtil::fillRectangle<float>(full_health_bar_rect, Color(19, 19, 19), 0.55f, 15.f);

		ImClippingUtil::beginClipping(Vec4<float>(health_bar_rect.x - 1.f, health_bar_rect.y, health_bar_rect.z + 1.f, health_bar_rect.w));
		ImRenderUtil::fillGradientRectangle(full_health_bar_rect, ColorUtil::getClientColor(0, 1.5f), ColorUtil::getClientColor(300, 1.5f), 1.f, 1.f, 12.f);
		ImClippingUtil::restoreClipping();

		if (skin_texture && skin_texture != nullptr)
		{
			ImGui::GetBackgroundDrawList()->AddImageRounded(skin_texture.Get(), ImVec2(skin_texture_pos.x, skin_texture_pos.y), ImVec2(skin_texture_pos.z, skin_texture_pos.w), ImVec2(0.f, 0.f), ImVec2(1.f, 1.f), ImColor(skin_texture_color.r, skin_texture_color.g, skin_texture_color.b, skin_texture_color.a), 14.f);
		}

		//ImRenderUtil::drawRoundedGradientRectangleOutline(Vec4<float>(mRect.x - 2.f, mRect.y - 2.f, mRect.z + 2.f, mRect.w + 2.f), ColorUtil::getClientColor(1.5f, 0.6f, 1, 1), ColorUtil::getClientColor(1.5f, 0.6f, 1, 400), 14, 1, 1, 1.752f);

		if (ImRenderUtil::isMouseOver(rect) && MainClient::getModuleByType<HudEditor>()->isEnabled() && allow_hud_editor) {
			Vec2<float> mMousePos = ImRenderUtil::getMousePos();

			static Vec2<float> mDifference = Vec2<float>(mMousePos.x - targetinfo_pos.x, mMousePos.y - targetinfo_pos.y);

			if (Util::mLeftClick) 
			{
				targetinfo_pos.x = mMousePos.x - mDifference.x;
				targetinfo_pos.y = mMousePos.y - mDifference.y;
			}
			else 
			{
				mDifference = Vec2<float>(mMousePos.x - targetinfo_pos.x, mMousePos.y - targetinfo_pos.y);
			}
		}

		ImScaleUtil::ImScaleEnd(scale, scale);
	}
};