#pragma once

class Gui : public Module
{
public:
    Gui() : Module("Gui", "Visual", "Fully customize the visual interface with advanced configuration options.", Keys::NONE, true)
    {
        mVisible = false;
    }

    std::string const getModeName()
    {
        return "";
    }

    void onDisable()
    {
        this->toggle();
    }
};