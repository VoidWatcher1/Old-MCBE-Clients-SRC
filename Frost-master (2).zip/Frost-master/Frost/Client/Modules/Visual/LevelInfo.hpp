#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class LevelInfo : public Module
{
public:
    LevelInfo() : Module("Level Info", "Visual", "Displays information about level.")
    {

    }

private:
    std::string mBpsCount = "BPS: 0";

    float mBps = 0.f;
    float mAveragedBps = 0.f;
    std::map<uint64_t, float> mBpsHistory;

    void calculateBlocksPerSecond() {
        auto* client = Instance::get<ClientInstance>();
        if (!client) return;

        auto* player = client->getLocalPlayer();
        if (!player) return;

        const auto& sim = *client->getMinecraftSim();
        const float timerSpeed = sim.mGameSimulation->mTicksPerSecond;

        // Current and previous positions
        const Vec3<float>& currentPos = player->getPosition();
        const Vec3<float>& previousPos = player->getStateVectorComponent()->mPrevPosition;

        // Horizontal velocity (X and Z only)
        const float dx = currentPos.x - previousPos.x;
        const float dz = currentPos.z - previousPos.z;
        const float horizontalVelocity = std::sqrt(dx * dx + dz * dz);

        mBps = horizontalVelocity * timerSpeed;

        std::ostringstream stream;
        stream.precision(2);
        stream << std::fixed << (mBps > 0.f ? mBps : 0.0f);

        mBpsCount = "bps: " + stream.str();
    }
public:
    void onEvent(RenderContextEvent* baseTickEvent)
    {
        calculateBlocksPerSecond();
    }
    
    void onEvent(ImRenderEvent* imguiEvent) 
    {
        Player* mPlayer = Instance::get<ClientInstance>()->getLocalPlayer();
        if (mPlayer == nullptr) return;

        renderLevelInfo(mBpsCount, 0, 0);
        renderLevelInfo(std::string("Testing 12345"), 1, 0);
        renderLevelInfo(std::string("Testing 12345"), 1, 1);
    }

    void renderLevelInfo(std::string tileDescr, int index, int alignment = 0) {
        auto* clientInstance = Instance::get<ClientInstance>();
        if (!clientInstance || !clientInstance->getGuiData()) return;

        const auto& resolution = clientInstance->getGuiData()->mWindowResolution;

        constexpr float fontScale = 1.1f;
        constexpr float yOffsetPerLine = 19.0f;
        constexpr float baseY = 25.0f;
        constexpr float paddingX = 5.0f;

        float textWidth = ImRenderUtil::getTextWidth(&tileDescr, fontScale);

        float x = (alignment == 0)
            ? paddingX
            : resolution.x - textWidth - paddingX;

        float y = resolution.y - baseY - (index * yOffsetPerLine);

        Vec2<float> tilePos(x, y);

        ImRenderUtil::drawText(tilePos, &tileDescr, Color(255, 255, 255), fontScale, 1.f, false);
    }
};