#pragma once

DEFINE_NOP_PATCH_FUNC(patchFluxSwing, (uintptr_t)SigManager::FluxSwing, 0x5);

class Animations : public Module
{
public:
    enum class SwingType
    {
        None,
        Flux,
    };

    enum class BlockType
    {
        None,
        Java,
        Exhibition,
        Dagger,
    };

    Animations() :
        Module("Animations", "Visual", "Modifies how your first person viewmodel moves.")
    {
        addEnum("Block", "The block animation type.", { "None", "Java", "Exhibition", "Dagger"}, &blockType);
        addEnum("Swing", "The swing type.", { "None", "Flux" }, &swingType);
        addBool("No Slot Slide", "Disables switch animations.", &noSlotSlide);
        addSlider("Swing Speed", "Custom swing speed value.", &swing_speed, 1, 90, SliderType::Int);
        addBool("Swing Angle", "Enable swing angle customization.", &customSwingAngle);
        addBool("Change on Block", "Changes angle only on block.", &onBlockCustomSwing, [this] { return customSwingAngle; });
        addSlider("Angle", "Custom swing angle value.", &swingAngleSet, -360, 360, SliderType::Float, [this] { return customSwingAngle; });
    }

private:
    int swingType = 0;
    int blockType = 1;

    float swing_speed = 20;

    bool noSlotSlide = true;
    bool customSwingAngle = true;
    bool onBlockCustomSwing = true;
    float swingAngleSet = 12;

    float* swingAngle = nullptr;

public:
    static inline bool shouldBlock = false;

public:
    void onEnable() 
    {
        if (!swingAngle) 
        {
            swingAngle = reinterpret_cast<float*>(SigManager::TapSwingAnim);
            Memory::setProtection(reinterpret_cast<uintptr_t>(swingAngle), sizeof(float), PAGE_READWRITE);
        }

        patchFluxSwing(swingType == static_cast<int>(SwingType::Flux));
    }

    void onDisable() 
    {
        patchFluxSwing(false);

        if (swingAngle) *swingAngle = glm::radians(-80.f);
    }

    void onEvent(SwingDurationEvent* swingDurationEvent)
    {
        swingDurationEvent->mSwingDuration = static_cast<int>(swing_speed);
    }

    void onEvent(BaseTickEvent* event) 
    {
        //patchFluxSwing(swingType == static_cast<int>(SwingType::Flux));

        bool isRightClicking = Keys::Keymap[VK_RBUTTON] && Instance::isAllowedToUseKeys();
        bool isBlocking = isRightClicking || shouldBlock;

        if (isBlocking)
        {
            patchFluxSwing(swingType == static_cast<int>(SwingType::Flux));
        }
        else
        {
            patchFluxSwing(false);
        }

        if (blockType == static_cast<int>(BlockType::Java) || blockType == static_cast<int>(BlockType::Exhibition)) {
            if (onBlockCustomSwing) 
            {
                *swingAngle = glm::radians(isBlocking ? (customSwingAngle ? swingAngleSet : -80.f) : -80.f);
            }
            else 
            {
                *swingAngle = glm::radians(customSwingAngle ? swingAngleSet : -80.f);
            }
        }
        else if (blockType == static_cast<int>(BlockType::Dagger)) 
        {
            *swingAngle = glm::radians(isBlocking ? 12.f : -80.f);
        }
        else {
            *swingAngle = glm::radians(-80.f);
        }
    }

    void onEvent(BobHurtEvent* event)
    {
        glm::mat4& matrix = *event->mMatrix;

        if (Keys::Keymap[VK_RBUTTON] && Instance::isAllowedToUseKeys() || shouldBlock)
        {
            if (blockType == static_cast<int>(BlockType::Java))
            {
                matrix = glm::translate<float>(matrix, glm::vec3(0.42222223281, 0.0, -0.16666666269302368));
                matrix = glm::translate<float>(matrix, glm::vec3(-0.1f, 0.15f, -0.2f));

                matrix = glm::translate<float>(matrix, glm::vec3(-0.24F, 0.25f, -0.20F));
                matrix = glm::rotate<float>(matrix, -1.98F, glm::vec3(0.0F, 1.0F, 0.0F));
                matrix = glm::rotate<float>(matrix, 1.30F, glm::vec3(4.0F, 0.0F, 0.0F));
                matrix = glm::rotate<float>(matrix, 60.0F, glm::vec3(0.0F, 1.0F, 0.0F));
            }

            if (blockType == static_cast<int>(BlockType::Exhibition))
            {
                matrix = glm::translate<float>(matrix, glm::vec3(0.72222223281, -0.2, -0.66666666269302368));
                matrix = glm::translate<float>(matrix, glm::vec3(-0.0f, 0.45f, -0.4f));

                matrix = glm::translate<float>(matrix, glm::vec3(-0.24F, 0.2f, -0.20F));
                matrix = glm::rotate<float>(matrix, -1.69F, glm::vec3(0.0F, 1.0F, 0.0F));
                matrix = glm::rotate<float>(matrix, 1.30F, glm::vec3(4.0F, 0.0F, 2.0F));
                matrix = glm::rotate<float>(matrix, 60.0F, glm::vec3(0.0F, 1.0F, 0.0F));
            }

            if (blockType == static_cast<int>(BlockType::Dagger))
            {
                matrix = glm::translate<float>(matrix, glm::vec3(0.72222223281, -0.2, -0.66666666269302368));
                matrix = glm::translate<float>(matrix, glm::vec3(-0.0f, 0.45f, -0.4f));

                matrix = glm::translate<float>(matrix, glm::vec3(-0.24F, 0.2f, -0.20F));
                matrix = glm::rotate<float>(matrix, -1.69F, glm::vec3(0.0F, 1.0F, 0.0F));
                matrix = glm::rotate<float>(matrix, 1.30F, glm::vec3(4.0F, 0.0F, 2.0F));
                matrix = glm::rotate<float>(matrix, 60.0F, glm::vec3(0.0F, 1.0F, 0.0F));
            }
        }
    }
};