#pragma once

class Trails : public Module {
public:
    Trails()
        : Module("Trail", "Visual", "Renders persistent visual trails (circles or lines) behind the player to illustrate movement history and enhance spatial awareness.")
    {
        addEnum("Mode", "Select the trail rendering style:\n- Circles: Emits circular pulses at each step.\n- Lines: Draws a continuous path between positions.", { "Circles", "Lines" }, &mode);
        addSlider("Time", "The lifetime of each trail segment in seconds before it fades out", &trail_duration, 1, 15);
        addSlider("Delay", "The interval (in ticks) between each recorded trail point", &trail_delay, 1, 30);
    }
    int mode = 0; // 0 = circle, 1 = line
    float trail_duration = 1;
    float trail_delay = 3;
    int delay_count = 0;

private:
    long long time_offset = 0;
    Vec3<float> old_pos;

    struct TrailEntry {
        int spawn_time = 0;
        Vec3<float> position{};
    };

    std::vector<TrailEntry> circle_trails;
    std::vector<TrailEntry> line_trails;

    void logTrail(const Vec3<float>& position, int time) {
        TrailEntry entry;
        entry.spawn_time = time;
        entry.position = position;

        if (mode == 0) {
            circle_trails.push_back(entry);
        }
        else if (mode == 1) {
            line_trails.push_back(entry);
        }
    }

    void cleanTrails(std::vector<TrailEntry>& list, int current_time) {
        list.erase(
            std::remove_if(list.begin(), list.end(),
                [this, current_time](const TrailEntry& e) {
                    return current_time - e.spawn_time > trail_duration * 1000;
                }),
            list.end()
        );
    }

public:
    void onEnable() override {
        time_offset = TimeUtil::getCurrentMs();
        old_pos = Vec3<float>();
        circle_trails.clear();
        line_trails.clear();
    }

    void onDisable() override {
        circle_trails.clear();
        line_trails.clear();
    }

    void onEvent(RenderContextEvent* event) override {
        if (Instance::getLocalPlayer() == nullptr) return;
        Player* player = Instance::getLocalPlayer();

        delay_count--;
        if (time_offset == 0) time_offset = TimeUtil::getCurrentMs();

        const int current_time = TimeUtil::getCurrentMs() - time_offset;

        Vec3<float> position = player->getRenderPosition();
        position.y = position.floor().y - 1.5f;

        if (MotionUtil::isMoving() && delay_count <= 0) {
            logTrail(position, current_time);
            delay_count = static_cast<int>(trail_delay);
        }

        cleanTrails(circle_trails, current_time);
        cleanTrails(line_trails, current_time);
    }

    void onEvent(ImRenderEvent* event) override {
        if (!Instance::isAllowedToUseKeys()) return;
        if (Instance::getLocalPlayer() == nullptr) return;

        const int current_time = TimeUtil::getCurrentMs() - time_offset;

        if (mode == 0) {
            renderCircleTrails(current_time);
        }
        else if (mode == 1) {
            renderLineTrails(current_time);
        }
    }

private:
    void renderCircleTrails(int current_time) {
        for (const auto& trail : circle_trails) {
            const int delta = current_time - trail.spawn_time;
            const int time_left = (trail_duration * 1000) - delta;

            Vec2<float> screen, screen2;
            Vec3<float> pos = trail.position;

            if (!Instance::get<ClientInstance>()->WorldToScreen(pos, screen, Frame::mFov, Frame::mOrigin, Frame::mMatrix)) continue;
            if (!Instance::get<ClientInstance>()->WorldToScreen(pos + Vec3<float>(0.1f, 0.1f, 0.1f), screen2, Frame::mFov, Frame::mOrigin, Frame::mMatrix)) continue;

            float circle_size = std::fmin(std::fmax(std::abs(screen.x - screen2.x), std::abs(screen.y - screen2.y)), 8.0f);
            float opacity = time_left < 300 ? time_left / 300.f : 1.0f;
            float growth = delta < 100 ? delta / 100.f : 1.0f;

            circle_size *= growth * opacity;

            ImRenderUtil::fillCircle(screen, circle_size, Color(255, 255, 255), opacity, 12.f);
            if (circle_size > 2)
                ImRenderUtil::fillShadowCircle(screen, circle_size, Color(255, 255, 255), opacity, 40.f, 0);
        }
    }

    void renderLineTrails(int current_time) {
        if (line_trails.size() < 2) return;

        for (size_t i = 1; i < line_trails.size(); i++) {
            auto& p1 = line_trails[i - 1];
            auto& p2 = line_trails[i];

            Vec2<float> screen1, screen2;
            if (!Instance::get<ClientInstance>()->WorldToScreen(p1.position, screen1, Frame::mFov, Frame::mOrigin, Frame::mMatrix)) continue;
            if (!Instance::get<ClientInstance>()->WorldToScreen(p2.position, screen2, Frame::mFov, Frame::mOrigin, Frame::mMatrix)) continue;

            int time_delta = current_time - p2.spawn_time;
            float alpha = time_delta < 300 ? time_delta / 300.f : 1.0f;
            alpha = std::clamp(1.0f - (time_delta / (trail_duration * 1000.f)), 0.f, 1.f);

            Im3DUtil::drawLine(screen1, screen2, Color(255, 0, 0, static_cast<int>(alpha * 255)), 1.5f);
        }
    }
};
