#pragma once

#include "Client/Menus/ClickGUI/FrostGUI.hpp"

class ClickGUI : public Module
{
public:
    float animation = 0;
    int scroll_direction = 0;

    bool rotate = false;
    bool blur = true;

    std::string search_query;

	bool selected_all = false;

    ClickGUI()
        : Module("ClickGUI", "Visual", "Manage your modules.", Keys::TAB, false)
    {
        addBool("Blur", "Blurs the clickgui's background", &blur);
        addBool("Rotate", "Adds rotation to the clickgui's animations", &rotate);

        mToggleInGameOnly = false;
        mCallEventsWhenDisabled = true;
    }

    void onEnable()
    {
        Instance::get<ClientInstance>()->releaseMouse();

        search_query = "";
    }

    void onDisable()
    {
        if (Instance::isAllowedToUseKeys())
        {
            Instance::get<ClientInstance>()->grabMouse();
        }

        search_query = "";
    }

    void onEvent(ImRenderEvent* event)
    {
        static EasingUtil zoom_ease;
        static EasingUtil rotate_ease;

        static FrostGUI clickGui;

        this->isEnabled() ? zoom_ease.increment(ImRenderUtil::getDeltaTime() * 15.5f / 10)
            : zoom_ease.decrement(ImRenderUtil::getDeltaTime() * 2 * 15.5f / 10);
        
        this->isEnabled() ? rotate_ease.decrement(ImRenderUtil::getDeltaTime() * 2 * 15.5f / 10)
            : rotate_ease.increment(ImRenderUtil::getDeltaTime() * 15.5f / 10);

        float scale = this->isEnabled() ? zoom_ease.easeOutElastic() : zoom_ease.easeOutBack();

        float rotate_scale = rotate_ease.easeOutExpo();

        if (zoom_ease.isMax())
            scale = 1;
        
        if (rotate_ease.isMax())
            rotate_scale = 1;

        animation = MathUtil::lerp(0, 1, zoom_ease.easeOutExpo());

        if (animation < 0.0001f)
        {
            return;
        }

        ImScaleUtil::ImScaleStart();

        if (rotate)
        {
            ImRotateUtil::startRotation();
        }

        clickGui.render(animation, scroll_direction, search_query, blur);

        if (rotate)
        {
            ImRotateUtil::endRotation(rotate_scale);
        }

        ImScaleUtil::ImScaleEnd(scale, scale);
    }

    void onEvent(RenderContextEvent* event)
    {
        if (!mEnabled)
            return;

        Instance::get<ClientInstance>()->releaseMouse();
    }

    void onEvent(KeyboardEvent* event)
    {
        if (!mEnabled)
            return;

        if (event->mKeyCode == Keys::ESC && event->mState) 
        {
            this->setEnabled(false);

            if (Instance::isAllowedToUseKeys())
            {
                Instance::get<ClientInstance>()->grabMouse();
            }

            event->cancel();
        }

        if (event->mKeyCode == Keys::BACKSPACE) 
        {
            if (event->mState == 0) // released
            {
                if (!search_query.empty())
                {
                    search_query.pop_back();
                }

                if (!animated_chars.empty()) 
                {
                    animated_chars.back().entering = false; // switch to exit animation
                }
            }

            event->cancel();
        }
        else if (event->mKeyCode >= 65 && event->mKeyCode <= 90 && event->mState == 0)
        {
            char key_char = static_cast<char>(event->mKeyCode);

            if (event->mKeyCode == Keys::SHIFT)
            {
                key_char = std::toupper(key_char);
            }
            else
            {
				key_char = std::tolower(key_char);
            }

            search_query += key_char;

            SearchCharAnim newAnim{ key_char };
            newAnim.animation.set(0);
            newAnim.entering = true;
            animated_chars.push_back(newAnim); // Add animated character

            event->cancel();
        }
        else if (event->mKeyCode == Keys::A && event->mKeyCode == Keys::CTRL && event->mState == 0)
        {
            selected_all = true;

            event->cancel();
        }
    }

    void onEvent(MouseEvent* event)
    {
        if (!mEnabled) return;
        event->cancel();
    }

    void onEvent(MouseScrollEvent* event)
    {
        if (!mEnabled) return;
        bool direction = event->mMouseDirection;

        if (!direction)
        {
            scroll_direction++;
        }
        else
        {
            scroll_direction--;
        }
    }
};