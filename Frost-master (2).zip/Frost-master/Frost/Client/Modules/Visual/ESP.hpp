#pragma once

class ESP : public Module
{
public:
    ESP() :
        Module("ESP", "Visual", "Draw basic boxes around entities.")
    {

    }
private:
    /*void renderCornerESP(Actor* entity)
    {
        auto player = Instance::getLocalPlayer();

        Vec3<float> renderPos(entity->getRenderPosition());

        if (entity == player)
        {
            renderPos = FrameUtil::mTransform.mPlayerPos;
        }

        Vec3<float> position = renderPos;
        Vec3<float> entLower = position.add(Vec3<float>(-0.35f, -1.62f, -0.35f));
        Vec3<float> entUpper = position.add(Vec3<float>(0.35f, 0.2f, 0.35f));

        Im3DUtil::drawCorners(entLower, entUpper, ColorUtil::getClientColor(), 1.f, true);
    }

    void renderESPTest()
    {
		for (auto* actor : ActorUtil::getActorList(100, false, true))
		{
			AABBShapeComponent* shape = actor->getAABBShapeComponent();

			Vec3<float> entPos = actor->getRenderPosition();

			Vec3<float> entLower = shape->mMin;
			Vec3<float> entUpper = shape->mMax;

			Vec3<float> origin = Frame::mOrigin;
			float dist = origin.distance(entPos);

			Vec2<float> output1, output2;
			if (!Instance::get<ClientInstance>()->WorldToScreen(entLower, output1, Frame::mFov, Frame::mOrigin, FrameUtil::mTransform.mMatrix) || !Instance::get<ClientInstance>()->WorldToScreen(entUpper, output2, Frame::mFov, Frame::mOrigin, FrameUtil::mTransform.mMatrix)) return;

			std::vector<Vec3<float>> aabbArr;
			for (float x : { entLower.x, entUpper.x })
			{
				for (float y : { entLower.y, entUpper.y })
				{
					for (float z : { entLower.z, entUpper.z })
					{
						aabbArr.push_back({ x, y, z });
					}
				}
			}

			std::vector<Vec2<float>> scrPoints;
			for (int i = 0; i < aabbArr.size(); i++)
			{
				Vec2<float> scrPoint;
				if (Instance::get<ClientInstance>()->WorldToScreen(aabbArr[i], scrPoint, Frame::mFov, Frame::mOrigin, FrameUtil::mTransform.mMatrix))
					scrPoints.push_back(scrPoint);
			}

			if (scrPoints.empty())
				return;

			Vec4<float> boundingRect = { scrPoints[0].x, scrPoints[0].y, scrPoints[0].x, scrPoints[0].y };
			for (const auto& point : scrPoints)
			{
				boundingRect.x = std::fmin(boundingRect.x, point.x);
				boundingRect.y = std::fmin(boundingRect.y, point.y);
				boundingRect.z = std::fmax(boundingRect.z, point.x);
				boundingRect.w = std::fmax(boundingRect.w, point.y);
			}

			float thickness = fmax(0.6f, 1.15f / std::fmax(1.f, origin.distance(entPos)));
			//thickness *= 1.5f; // Here is the thickness level

			RenderUtil::drawRectangle(Im3DUtil::scale(boundingRect), Color(0, 0, 0), 1.f, thickness + 2.f);
			RenderUtil::drawRectangle(Im3DUtil::scale(boundingRect), ColorUtil::getClientColor(1, 1.5f), 1.f, thickness);
		}
    }*/

	void render2DESP(Actor* ent, Color color, float alpha, ClientInstance* ci, Vec3<float> origin, Vec2<float> fov, Actor* localPlayer)
	{
		Vec3 render = ent->getRenderPosition();
		AABB box = AABB(Vec3(render - Vec3(0.3f, 1.62f, 0.3f)), render + Vec3(0.3f, 0.18f, 0.3f));

		Vec3<float> worldPoints[8];
		worldPoints[0] = Vec3(box.mMin.x, box.mMin.y, box.mMin.z);
		worldPoints[1] = Vec3(box.mMin.x, box.mMin.y, box.mMax.z);
		worldPoints[2] = Vec3(box.mMax.x, box.mMin.y, box.mMin.z);
		worldPoints[3] = Vec3(box.mMax.x, box.mMin.y, box.mMax.z);
		worldPoints[4] = Vec3(box.mMin.x, box.mMax.y, box.mMin.z);
		worldPoints[5] = Vec3(box.mMin.x, box.mMax.y, box.mMax.z);
		worldPoints[6] = Vec3(box.mMax.x, box.mMax.y, box.mMin.z);
		worldPoints[7] = Vec3(box.mMax.x, box.mMax.y, box.mMax.z);

		std::vector<Vec2<float>> points;
		for (int i = 0; i < 8; i++) {
			Vec2<float> result;
			if (ci->WorldToScreen(worldPoints[i], result, fov, origin, ci->getGLMatrix()))
				points.emplace_back(result);
		}
		if (points.size() < 1) return;

		Vec4<float> resultRect = { points[0].x, points[0].y, points[0].x, points[0].y };
		for (const auto& point : points) {
			if (point.x < resultRect.x) resultRect.x = point.x;
			if (point.y < resultRect.y) resultRect.y = point.y;
			if (point.x > resultRect.z) resultRect.z = point.x;
			if (point.y > resultRect.w) resultRect.w = point.y;
		}

		float lineWidth = (float)fmax(0.5f, 1 / (float)fmax(1, (float)localPlayer->getRenderPosition().distance(render)));
		resultRect = Im3DUtil::scale(resultRect);
		Vec2<float> startRect(resultRect.x, resultRect.y);
		Vec2<float> endRect(resultRect.z, resultRect.w);
		RenderUtil::drawRectangle(startRect, endRect, Color(0, 0, 0), alpha, lineWidth + 1.5f);
		RenderUtil::drawRectangle(startRect, endRect, color, alpha, lineWidth + 0.5);

		//RenderUtil::drawRectangle(startRect, endRect, Color(255, 255, 255), alpha, lineWidth + 0.5);
		//Vec4<float> toCenter(resultRect.x, resultRect.y, (resultRect.x + resultRect.z) / 2.0f, resultRect.w);
		//RenderUtil::setClipRect(Vec4<float>{ toCenter.x, toCenter.y, toCenter.z, toCenter.w });
		//RenderUtil::drawRectangle(startRect, endRect, color, alpha, lineWidth + 0.5);
		//RenderUtil::resetClipRect();
	}
public:
    void onEvent(ImRenderEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        
		for (auto actor : player->getLevel()->getRuntimeActorList())
		{
			//renderCornerESP(actor);
		}
    }

	void onEvent(RenderContextEvent* event)
	{
		if (UILayer::Is(Instance::get<ScreenView>(), UILayer::Ingame_CanMoveScreen))
		{
			auto ci = Instance::get<ClientInstance>();
			auto lp = ci->getLocalPlayer();
			if (!lp || !lp->getLevel()) return;
			auto lp_lvl = lp->getLevel();

			Vec3<float> originPos = ci->getLevelRenderer()->getOrigin();
			Vec2<float> fov = ci->getFov();

			//Color espColor(255, 255, 255);
			Color espColor = ColorUtil::getClientColor();
			float espAlpha = 1.f;

			for (Actor* target : ActorUtil::getActorList(100.f, false))
			{
				render2DESP(target, espColor, espAlpha, ci, originPos, fov, lp);
			}
		}
	}
};