#pragma once

class BodyYaw
{
public:
    static inline float bodyYaw = 0.f;
    static inline Vec3<float> posOld = Vec3<float>(0, 0, 0);
    static inline Vec3<float> pos = Vec3<float>(0, 0, 0);

    static inline void updateRenderAngles(Actor* plr, float headYaw)
    {
        posOld = pos;
        pos = *plr->getPos();

        float diffX = pos.x - posOld.x;
        float diffZ = pos.z - posOld.z;
        float diff = diffX * diffX + diffZ * diffZ;

        float body = bodyYaw;
        if (diff > 0.0025000002F)
        {
            float anglePosDiff = atan2f(diffZ, diffX) * 180.f / 3.14159265358979323846f - 90.f;
            float degrees = abs(wrapAngleTo180_float(headYaw) - anglePosDiff);
            if (95.f < degrees && degrees < 265.f)
            {
                body = anglePosDiff - 180.f;
            }
            else
            {
                body = anglePosDiff;
            }
        }

        turnBody(body, headYaw);
    };

    static inline void turnBody(float bodyRot, float headYaw)
    {
        float amazingDegreeDiff = wrapAngleTo180_float(bodyRot - bodyYaw);
        bodyYaw += amazingDegreeDiff * 0.3f;
        float bodyDiff = wrapAngleTo180_float(headYaw - bodyYaw);
        if (bodyDiff < -75.f)
            bodyDiff = -75.f;

        if (bodyDiff >= 75.f)
            bodyDiff = 75.f;

        bodyYaw = headYaw - bodyDiff;
        if (bodyDiff * bodyDiff > 2500.f)
        {
            bodyYaw += bodyDiff * 0.2f;
        }
    };

    static inline float wrapAngleTo180_float(float value)
    {
        value = fmodf(value, 360.f);

        if (value >= 180.0F)
        {
            value -= 360.0F;
        }

        if (value < -180.0F)
        {
            value += 360.0F;
        }

        return value;
    };
};

class ServerRotations : public Module
{
public:
    ServerRotations() :
        Module("Server Rotations", "Visual", "Shows your serversided player state.", Keys::NONE, true)
    {
        //addBool("Rotate on first person", "Enable for rotation transitions on first person.", &rotateOnFirstPerson);
        addSlider("Ease", "Adjusts the rate of transition smoothing, controlling the interpolation velocity for rotations.", &ease, 1, 20, SliderType::Float);
    }

    enum Mode {
        Normal = 0,
        Synced = 1
    };

    int bodyYawState = 0;

    float headYaw = 0.f;
    float bodyYaw = 0.f;
    float pitch = 0.f;

    static inline float lerpedPitch = 0;
    static inline float lerpedBodyYaw = 0;
    static inline float lerpedHeadRot = 0;

    float pYaw;
    float pOldYaw;

    float pHeadYaw;
    float pOldHeadYaw;

    float pPitch;
    float pOldPitch;

    float pBodyYaw;
    float pOldBodyYaw;

    float pLerpedYaw;
    float pLerpedHeadYaw;
    float pLerpedPitch;
    float pLerpedBodyYaw;

    float ease = 5.f;

    void rotate(Packet* packet)
    {
        PacketID mID = packet->getID();

        if (mID == PacketID::PlayerAuthInput)
        {
            auto* pkt = reinterpret_cast<PlayerAuthInputPacket*>(packet);
            if (pkt)
            {
                pOldYaw = pYaw;
                pOldPitch = pPitch;
                pOldBodyYaw = pBodyYaw;
                pYaw = pkt->mRotation.y;
                pPitch = pkt->mRotation.x;
                pHeadYaw = pkt->mYHeadYaw;
            }
        }

        if (mID == PacketID::MovePlayer)
        {
            auto* pkt = reinterpret_cast<MovePlayerPacket*>(packet);
            if (pkt)
            {
                pOldYaw = pYaw;
                pOldPitch = pPitch;
                pOldBodyYaw = pBodyYaw;
                pYaw = pkt->mRotation.y;
                pPitch = pkt->mRotation.x;
                pHeadYaw = pkt->mYHeadRot;
            }
        }
    }

    void onEvent(ImRenderEvent* event)
    {
        //static constexpr float LERP_SPEED = 5.f;
        float LERP_SPEED = ease;
        float deltaTime = ImGui::GetIO().DeltaTime;

        float yaw = MathUtil::wrap(pLerpedYaw, pYaw - 180, pYaw + 180);
        float headYaw = MathUtil::wrap(pLerpedHeadYaw, pHeadYaw - 180, pHeadYaw + 180);
        float pitch = pLerpedPitch;
        float bodyYaw = MathUtil::wrap(pLerpedBodyYaw, pBodyYaw - 180, pBodyYaw + 180);

        float preLerpedYaw = MathUtil::lerp(yaw, pYaw, deltaTime * LERP_SPEED);
        float preLerpedHeadYaw = MathUtil::lerp(headYaw, pHeadYaw, deltaTime * LERP_SPEED);
        float preLerpedPitch = MathUtil::lerp(pitch, pPitch, deltaTime * LERP_SPEED);
        float preLerpedBodyYaw = MathUtil::lerp(bodyYaw, pBodyYaw, deltaTime * LERP_SPEED);

        pLerpedYaw = MathUtil::wrap(pLerpedYaw, preLerpedYaw - 180, preLerpedYaw + 180);
        pLerpedHeadYaw = MathUtil::wrap(pLerpedHeadYaw, preLerpedHeadYaw - 180, preLerpedHeadYaw + 180);
        pLerpedBodyYaw = MathUtil::wrap(pLerpedBodyYaw, preLerpedBodyYaw - 180, preLerpedBodyYaw + 180);

        pLerpedYaw = MathUtil::lerp(preLerpedYaw, pLerpedYaw, deltaTime * LERP_SPEED);
        pLerpedHeadYaw = MathUtil::lerp(preLerpedHeadYaw, pLerpedHeadYaw, deltaTime * LERP_SPEED);
        pLerpedPitch = MathUtil::lerp(preLerpedPitch, pLerpedPitch, deltaTime * LERP_SPEED);
        pLerpedBodyYaw = MathUtil::lerp(preLerpedBodyYaw, pLerpedBodyYaw, deltaTime * LERP_SPEED);

        lerpedPitch = pLerpedPitch;
        lerpedHeadRot = pLerpedHeadYaw;
        lerpedBodyYaw = pLerpedBodyYaw;
    }

    void onEvent(BaseTickEvent* event)
    {
        auto player = Instance::get<ClientInstance>()->getLocalPlayer();
        if (!player) return;

        BodyYaw::updateRenderAngles(player, pYaw);
        pOldBodyYaw = pBodyYaw;
        pBodyYaw = BodyYaw::bodyYaw;
    }

    void onEvent(ActorModelEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        auto entity = event->mRenderParams->mActor;

        if (entity == player)
        {
            if (event->mBoneType == BoneType::Head)
            {
                // homeless
                //event->mActorPartModel->mRot.x = lerpedPitch * 0.5f;
            }
        }
    }

    void onEvent(InterpolatedHeadYawEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        if (event->mActor == player)
        {
            event->mHeadYaw = lerpedHeadRot;
        }
    }

    void onEvent(InterpolatedBodyYawEvent* event)
    {
        auto player = Instance::getLocalPlayer();
        if (!player) return;

        if (event->mActor == player)
        {
            event->mBodyYaw = lerpedBodyYaw;
        }
    }
};