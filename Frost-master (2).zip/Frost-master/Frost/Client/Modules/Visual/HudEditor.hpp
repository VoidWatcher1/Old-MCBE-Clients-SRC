#pragma once

/*
*            ______ _____  _    _ _      _____ _    _  _____
*      /\   |  ____|  __ \| |  | | |    |_   _| |  | |/ ____|
*     /  \  | |__  | |__) | |  | | |      | | | |  | | (___
*    / /\ \ |  __| |  _  /| |  | | |      | | | |  | |\___ \
*   / ____ \| |____| | \ \| |__| | |____ _| |_| |__| |____) |
*  /_/    \_\______|_|  \_\\____/|______|_____|\____/|_____/

* Aerulius License
*
*	- Copyright (c) 2022 Tozic Routh, All Rights Reserved.
*  This file is part of AERELIUS. Redistribution and unlicensed use is prohibited.
*/

class HudEditor : public Module
{
public:
    HudEditor() : Module("Hud Editor", "Visual", "Provides an interface for customizing and repositioning various visual modules.")
    {

    }

private:

    bool mLastMouseState = false;

public:
    void onEnable()
    {
        MainClient::getModuleByType<ClickGUI>()->setEnabled(false);

        mLastMouseState = !Instance::get<ClientInstance>()->isMouseGrabbed();
        Instance::get<ClientInstance>()->releaseMouse();
    }

    void onEvent(RenderContextEvent* event) 
    {
        Instance::get<ClientInstance>()->releaseMouse();
    }

    void onEvent(KeyboardEvent* event) {
        if (ImGui::GetIO().WantCaptureKeyboard)
        {
            return;
        }

        if (event->mKeyCode == Keys::ESC && event->mState)
        {
            this->setEnabled(false);
            event->cancel();

            return;
        }

        event->cancel();
    }
    
    void onEvent(MouseEvent* event)
    {
        if (!mEnabled) return;
        event->cancel();
    }

    void onDisable() {
        if (mLastMouseState)
        {
            Instance::get<ClientInstance>()->grabMouse();
        }
        else
        {
            Instance::get<ClientInstance>()->releaseMouse();
        }
    }
};