#pragma once

class Chams : public Module
{
public:
	Chams() :
		Module("Chams", "Visual", "Esp but outline.")
	{
		
	}

private:
	std::unordered_map<Actor*, ActorModel> entity_model_map;

	void draw_outline_esp(std::pair<Actor* const, ActorModel>& pair)
	{
		Actor* entity = pair.first;
		ActorModel& model = pair.second;

		if (entity == nullptr) return;

		Vec3<float> eye_pos(0, 0, 0);
		float yaw = 0.f;
		bool is_sneaking = false;

		auto render_pos_component = entity->getComponent<RenderPositionComponent>();
		auto mob_body_rotation_component = entity->getComponent<MobBodyRotationComponent>();
		auto move_input_handler_component = entity->getComponent<MoveInputComponent>();

		if (render_pos_component != nullptr)
		{
			eye_pos = render_pos_component->mRenderPos;
		}

		if (mob_body_rotation_component != nullptr)
		{
			yaw = mob_body_rotation_component->mBodyRot;
		}

		if (move_input_handler_component != nullptr)
		{
			is_sneaking = move_input_handler_component->mSprinting;
		}

		float rotation_y = -yaw + 180.f;

		// Optional sneaking logic (currently unused)

		struct BodyPart {
			int model_index;
			Vec3<float> box_min;
			Vec3<float> box_max;
			Vec3<float> rotation_center;
			Vec3<float> rotation_offset;
			Vec3<float> translate_offset;
		};

		std::array<BodyPart, 6> parts = {
			BodyPart{ 0, {-0.28f, -0.225f, -0.28f}, {0.28f, 0.3f, 0.28f}, {0.f, -0.205f, 0.f}, {0.f, 0.f, 0.f}, {0.f, -0.225f, -0.061f} }, // Head
			BodyPart{ 1, {-0.47f, -0.99f, -0.131f}, {-0.215f, -0.2f, 0.131f}, {-0.3f, -0.33f, 0.f}, {28.f, 0.f, 0.f}, {0.f, -0.15795f, -0.03705f} }, // Left Arm
			BodyPart{ 2, {0.215f, -0.99f, -0.131f}, {0.47f, -0.2f, 0.131f}, {0.3f, -0.33f, 0.f}, {28.f, 0.f, 0.f}, {0.f, -0.15795f, -0.03705f} }, // Right Arm
			BodyPart{ 3, {-0.24f, -1.67f, -0.136f}, {0.f, -0.92f, 0.136f}, {0.f, -0.92f, 0.f}, {28.f, 0.f, 0.f}, {0.f, 0.f, 0.2f} }, // Left Leg
			BodyPart{ 4, {0.f, -1.67f, -0.136f}, {0.24f, -0.92f, 0.136f}, {0.f, -0.92f, 0.f}, {28.f, 0.f, 0.f}, {0.f, 0.f, 0.2f} }, // Right Leg
			BodyPart{ 5, {-0.25f, -0.92f, -0.125f}, {0.25f, -0.205f, 0.125f}, {0.f, -0.92f, 0.f}, {28.f, 0.f, 0.f}, {0.f, -0.10f, 0.25f} } // Body
		};

		for (const auto& part : parts)
		{
			ActorPartModel* part_model = model.mModels[part.model_index];
			if (!part_model) continue;

			std::vector<Vec3<float>> corners = Im3DUtil::getBoxCorners3D(
				eye_pos.add(part.box_min),
				eye_pos.add(part.box_max)
			);

			Vec3<float> rot = Vec3<float>(
				-part_model->mRot.x - (is_sneaking ? part.rotation_offset.x : 0.f),
				-part_model->mRot.y - (is_sneaking ? part.rotation_offset.y : 0.f),
				part_model->mRot.z + (is_sneaking ? part.rotation_offset.z : 0.f)
			);

			Vec3<float> rot_center = eye_pos.add(part.rotation_center);
			Im3DUtil::rotateBoxCorners3D(corners, rot_center, rot);

			if (is_sneaking)
				Im3DUtil::translateBox3D(corners, part.translate_offset);

			Im3DUtil::rotateBoxCorners3D(corners, eye_pos, Vec3<float>(0.f, rotation_y, 0.f));
			Im3DUtil::drawRawBox3D(corners);
		}
	}
public:
	void onEvent(ActorModelEvent* event)
	{
		auto player = Instance::getLocalPlayer();
		if (!player) return;

		auto entity = event->mRenderParams->mActor;

		if (entity == player) return; // skip local player

		auto part = event->mActorPartModel;
		auto bone = event->mBoneType;

		// Access or create the ActorModel for this entity
		auto& model = entity_model_map[entity];

		// Assign part to correct bone slot
		switch (bone) {
			case BoneType::Head:      model.mModels[0] = part; break;
			case BoneType::LeftArm:   model.mModels[1] = part; break;
			case BoneType::RightArm:  model.mModels[2] = part; break;
			case BoneType::LeftLeg:   model.mModels[3] = part; break;
			case BoneType::RightLeg:  model.mModels[4] = part; break;
			case BoneType::Body:      model.mModels[5] = part; break;
			default: break; // unknown or unsupported bone
		}
	}

	void onEvent(ImRenderEvent* event)
	{
		auto player = Instance::getLocalPlayer();
		if (!player) return;

		if (!Instance::isAllowedToUseKeys()) return;

		for (auto& pair : entity_model_map)
		{
			Actor* entity = pair.first;
			ActorModel& model = pair.second;

			// Skip null, local player, or invalid model
			if (!entity || entity == player) continue;
			if (!model.isValid()) continue;

			draw_outline_esp(pair); // or drawChams(pair);
		}

		for (auto it = entity_model_map.begin(); it != entity_model_map.end(); )
		{
			Actor* entity = it->first;
			if (entity == nullptr || !entity->isAlive())
				it = entity_model_map.erase(it);
			else
				++it;
		}
	};
};