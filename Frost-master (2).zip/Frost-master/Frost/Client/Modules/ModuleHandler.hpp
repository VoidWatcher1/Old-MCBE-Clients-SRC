#pragma once

// Combat
#include "Combat/Aura.hpp"
#include "Combat/Teams.hpp"

// Miscellaneous
#include "Misc/AntiCheat.hpp"
#include "Misc/Disabler.hpp"
#include "Misc/ForceGM.hpp"
#include "Misc/IRC.hpp"
#include "Misc/NetSkip.hpp"
#include "Misc/NoPacket.hpp"
#include "Misc/Nuker.hpp"
#include "Misc/Regen.hpp"
#include "Misc/SpotifyFromTemu.hpp"

// Motion
#include "Motion/AirJump.hpp"
#include "Motion/Fly.hpp"
#include "Motion/Speed.hpp"
#include "Motion/Sprint.hpp"
#include "Motion/Step.hpp"
#include "Motion/Velocity.hpp"

// Player
#include "Player/AutoTotem.hpp"
#include "Player/ChestStealer.hpp"
#include "Player/Scaffold.hpp"

// Visual
#include "Visual/Animations.hpp"
#include "Visual/ArrayList.hpp"
#include "Visual/Chams.hpp"
#include "Visual/ClickGUI.hpp"
#include "Visual/ESP.hpp"
#include "Visual/Gui.hpp"
#include "Visual/HudEditor.hpp"
#include "Visual/LevelInfo.hpp"
#include "Visual/ServerRotations.hpp"
#include "Visual/SessionInfo.hpp"
#include "Visual/TargetHUD.hpp"
#include "Visual/Trails.hpp"

// Developer Modules
#include "Developer/DUM.hpp"
#include "Developer/KBTest.hpp"
#include "Developer/TestModule.hpp"
#include "Developer/SwiftFly.hpp"

class ModuleHandler {
public:
    static ModuleHandler& getInstance() {
        static ModuleHandler instance;
        return instance;
    }

    void initializeModules() {
        loadModules();
        sortCategories();

        MainClient::mModules = mModules;
        MainClient::mCategories = mCategories;
    }

    void unloadAllModules() {
        for (const auto& mod : mModules) {
            if (mod->isEnabled())
                mod->toggle();
        }
        mModules.clear();
        mCategories.clear();
    }

    [[nodiscard]] const std::vector<std::shared_ptr<Module>>& getModules() const noexcept {
        return mModules;
    }

    [[nodiscard]] const std::vector<std::string>& getCategories() const noexcept {
        return mCategories;
    }

    template<typename T>
    T* getModuleByType() {
        for (const auto& module : mModules)
        {
            if (dynamic_cast<T*>(module.get()))
            {
                return static_cast<T*>(module.get());
            }
        }
        return nullptr;
    }

    std::shared_ptr<Module> getModuleByName(const std::string& name)
    {
        std::string nameLower(name);
        std::transform(nameLower.begin(), nameLower.end(), nameLower.begin(), ::tolower);

        auto it = std::find_if(mModules.begin(), mModules.end(), [&](const std::shared_ptr<Module>& m) {
            std::string moduleNameLower = m->getName();
            std::transform(moduleNameLower.begin(), moduleNameLower.end(), moduleNameLower.begin(), ::tolower);
            moduleNameLower.erase(std::remove(moduleNameLower.begin(), moduleNameLower.end(), ' '), moduleNameLower.end());
            return nameLower == moduleNameLower;
            });

        return it != mModules.end() ? *it : nullptr;
    }

    std::vector<std::shared_ptr<Module>> getModulesByCategory(const std::string& category) const {
        std::vector<std::shared_ptr<Module>> filtered;
        for (const auto& mod : mModules) {
            if (mod->getCategory() == category)
                filtered.emplace_back(mod);
        }
        return filtered;
    }

    void registerModule(std::shared_ptr<Module> mod) {
        mModules.emplace_back(std::move(mod));
    }

private:
    std::vector<std::shared_ptr<Module>> mModules;
    std::vector<std::string> mCategories;

    void loadModules() {
        // Dev Build
        registerModule(std::make_shared<DUM>());
        registerModule(std::make_shared<KBTest>());
        registerModule(std::make_shared<SwiftFly>());
        registerModule(std::make_shared<TestModule>());

        // Combat
        registerModule(std::make_shared<Aura>());
        registerModule(std::make_shared<Teams>());
        
        // Misc
        registerModule(std::make_shared<AntiCheat>());
        registerModule(std::make_shared<Disabler>());
        registerModule(std::make_shared<ForceGM>());
        registerModule(std::make_shared<IRC>());
        registerModule(std::make_shared<NetSkip>());
        registerModule(std::make_shared<NoPacket>());
        registerModule(std::make_shared<Nuker>());
        registerModule(std::make_shared<Regen>());
        registerModule(std::make_shared<SpotifyFromTemu>());

        // Motion
        registerModule(std::make_shared<AirJump>());
        registerModule(std::make_shared<Fly>());
        registerModule(std::make_shared<Speed>());
        registerModule(std::make_shared<Sprint>());
        registerModule(std::make_shared<Step>());
        registerModule(std::make_shared<Velocity>());

        // Player
        registerModule(std::make_shared<AutoTotem>());
        registerModule(std::make_shared<ChestStealer>());
        registerModule(std::make_shared<Scaffold>());

        // Visual
        registerModule(std::make_shared<Animations>());
        registerModule(std::make_shared<ArrayList>());
        registerModule(std::make_shared<Chams>());
        registerModule(std::make_shared<ClickGUI>());
        registerModule(std::make_shared<ESP>());
        registerModule(std::make_shared<Gui>());
        registerModule(std::make_shared<HudEditor>());
        registerModule(std::make_shared<LevelInfo>());
        registerModule(std::make_shared<ServerRotations>());
        registerModule(std::make_shared<SessionInfo>());
        registerModule(std::make_shared<TargetHUD>());
        registerModule(std::make_shared<Trails>());
    }

    void sortCategories() {
        std::unordered_set<std::string> unique;
        mCategories.clear();

        for (const auto& mod : mModules) {
            const auto& cat = mod->getCategory();
            if (unique.insert(cat).second)
                mCategories.emplace_back(cat);
        }

        std::sort(mCategories.begin(), mCategories.end());
    }

    ModuleHandler() = default;
    ~ModuleHandler() = default;

    ModuleHandler(const ModuleHandler&) = delete;
    ModuleHandler& operator=(const ModuleHandler&) = delete;
};