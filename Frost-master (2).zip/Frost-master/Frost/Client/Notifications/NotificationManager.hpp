#pragma once

class NotificationsManager {
public:
	static inline int mStyle = 0;
	static inline bool mShowOnToggle = true; // Show a notification when a module is toggled
	static inline bool mShowOnJoin = false; // Show a notification when you join a server/world
	static inline bool mLimitNotifications = false; // Limit the number of notifications shown at one time
	static inline float mMaxNotifications = 6; // The maximum number of notifications shown at one time

	enum Style {
		Solaris = 0
	};

	static inline std::vector<NotificationsUtil::Notification> mNotifications;

	static bool CalcSize(ImVec2& boxSize, float& yOff, float& x, ImVec2 screenSize, NotificationsUtil::Notification* notification)
	{
		// skidding, i don't even care i just want this to work :sob:
		float beginX = screenSize.x - boxSize.x - 10.f;
		float endX = screenSize.x + boxSize.x;

		x = MathUtil::lerp(endX, beginX, notification->mCurrentDuration);
		yOff = MathUtil::lerp(yOff, yOff - boxSize.y, notification->mCurrentDuration);

		if (x > screenSize.x + boxSize.x && yOff > screenSize.y + boxSize.y) return true;

		return false;
	}

	static void renderNotifications()
	{
        ImVec2 mDisplaySize = ImGui::GetIO().DisplaySize;
        auto mDrawList = ImGui::GetBackgroundDrawList();
        float y = mDisplaySize.y - 10.0f;
        float x;
        float mDelta = ImGui::GetIO().DeltaTime;

        // First, remove any notifications that have expired (only if 10 seconds have passed since the notification was shown)
        std::erase_if(mNotifications, [](const NotificationsUtil::Notification& notification) {
            return notification.mIsTimeUp && notification.mTimeShown > notification.mDuration + 3.0f;
            });

        int mColorIndex = mNotifications.size() - 1;
        int i = 0;

        for (auto& notification : mNotifications) {
            if (i > mMaxNotifications && mLimitNotifications) break;
            notification.mTimeShown += mDelta;
            notification.mIsTimeUp = notification.mTimeShown >= notification.mDuration;
            notification.mCurrentDuration = MathUtil::lerp(notification.mCurrentDuration, notification.mIsTimeUp ? 0.0f : 1.0f, mDelta * 5.0f);

            ImRotateUtil::startRotation();


            float mPercentDone = notification.mTimeShown / notification.mDuration;
            mPercentDone = std::clamp(mPercentDone, 0.0f, 1.0f);

            // Calculate rotation angle here
            //float rotationAngle = (1.0f - notification.mCurrentDuration) * 25.0f; // rotates from -25� to 0�
            float rotationAngle = (1.0f - notification.mCurrentDuration) * 2.5f; // rotates from -25� to 0�

            if (mStyle == Style::Solaris) {
                constexpr float mFontSize = 20.0f;

                const auto mSize = ImGui::GetFont()->CalcTextSizeA(mFontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).x;
                float mSizeY = ImGui::GetFont()->CalcTextSizeA(mFontSize, FLT_MAX, 0.0f, notification.mMessage.c_str()).y;

                auto mBoxSize = ImVec2(fmax(200.0f, 50 + mSize), mSizeY + 30.0f);

                if (CalcSize(mBoxSize, y, x, mDisplaySize, &notification)) continue;

                Color themeColor = ColorUtil::getClientColor(y * 2, 1.f);
                if (notification.mType == NotificationsUtil::Notification::Type::Warning)
                    themeColor = Color(255, 204, 0);
                else if (notification.mType == NotificationsUtil::Notification::Type::Error)
                    themeColor = Color(255, 0, 0);

                themeColor.a = 178;
                float max = x + mBoxSize.x;
                ImVec2 progMax = ImVec2(x + (mBoxSize.x * mPercentDone + 6.f), y + (mBoxSize.y - 10.f));
                progMax.x = std::clamp(progMax.x, x, max);
                ImVec2 bgMin = ImVec2(x + mBoxSize.x * mPercentDone, y);
                ImVec2 bgMax = ImVec2(x + mBoxSize.x, y + (mBoxSize.y - 10.f));

                mDrawList->AddRectFilled(ImVec2(x, y), bgMax, ImColor(0.f, 0.f, 0.f, 0.7f), 5.0f);

                mDrawList->AddShadowRect(ImVec2(x, y), progMax, ImColor(themeColor.r, themeColor.g, themeColor.b, 1.f), 50.f, ImVec2(), 0, 5.0f);

                mDrawList->AddRectFilled(ImVec2(x, y), progMax, ImColor(themeColor.r, themeColor.g, themeColor.b, themeColor.a), 5.0f);

                //mDrawList->PopClipRect();

                //mDrawList->PushClipRect(bgMin, bgMax);

                

                //mDrawList->PopClipRect();

                // Draw each character with rotation animation
                float letterOffsetX = x + 10;
                float baseY = y + 10;
                float charIndex = 0.0f;

                for (char c : notification.mMessage) {
                    std::string ch_str(1, c);
                    float rotateEase = EasingUtil::easeOutExpo(notification.mCurrentDuration) * 1.5f;
                    ImVec2 pos = ImVec2(letterOffsetX, baseY);

                    ImRotateUtil::applyRotation(pos, rotationAngle); // 10 degrees max rotation
                    mDrawList->AddText(ImGui::GetFont(), mFontSize, pos, ImColor(255, 255, 255, 255), ch_str.c_str());

                    letterOffsetX += ImGui::GetFont()->CalcTextSizeA(mFontSize, FLT_MAX, 0.0f, ch_str.c_str()).x + 1.5f;
                    charIndex += 1.0f;
                }

                mColorIndex--;
                if (!notification.mIsTimeUp) i++;
            }

            ImRotateUtil::endRotation(rotationAngle);
        }
	}
};